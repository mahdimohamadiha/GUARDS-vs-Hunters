module GUARDS.vs.Hunters {

    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;

    opens sample;
}