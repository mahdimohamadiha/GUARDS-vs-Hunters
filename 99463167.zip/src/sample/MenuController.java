package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;
import java.io.IOException;

public class MenuController {
    public Button start_game_button;
    public Button view_records_button;
    public Button exit_button;

    public void OnClickStartGame(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("game_level.fxml"));
        Stage primaryStage = (Stage) start_game_button.getScene().getWindow();
        primaryStage.setTitle("GUARDS vs Hunters");
        primaryStage.setScene(new Scene(root, 1533, 797));
        primaryStage.show();
    }

    public void OnClickViewRecords(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("records.fxml"));
        Stage primaryStage = (Stage) view_records_button.getScene().getWindow();
        primaryStage.setTitle("GUARDS vs Hunters");
        primaryStage.setScene(new Scene(root, 1533, 797));
        primaryStage.show();
    }

    public void OnClickExit(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) exit_button.getScene().getWindow();
        stage.close();
    }

    public void OnClickEnteredStartGameButton(MouseEvent mouseEvent) {
        start_game_button.setStyle("-fx-background-radius : 30 ; -fx-background-color : #E8B1F7");
    }

    public void OnClickExitedStartGameButton(MouseEvent mouseEvent) {
        start_game_button.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #F2D7F9");
    }

    public void OnClickPressedStartGameButton(MouseEvent mouseEvent) {
        start_game_button.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #DD84F4");
    }

    public void OnClickEnteredViewRecordsButton(MouseEvent mouseEvent) {
        view_records_button.setStyle("-fx-background-radius : 30 ; -fx-background-color : #E8B1F7");
    }

    public void OnClickExitedViewRecordsButton(MouseEvent mouseEvent) {
        view_records_button.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #F2D7F9");
    }

    public void OnClickPressedViewRecordsButton(MouseEvent mouseEvent) {
        view_records_button.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #DD84F4");
    }

    public void OnClickEnteredExitButton(MouseEvent mouseEvent) {
        exit_button.setStyle("-fx-background-radius : 30 ; -fx-background-color : #E8B1F7");
    }

    public void OnClickExitedExitButton(MouseEvent mouseEvent) {
        exit_button.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #F2D7F9");
    }

    public void OnClickPressedExitButton(MouseEvent mouseEvent) {
        exit_button.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #DD84F4");
    }
}
