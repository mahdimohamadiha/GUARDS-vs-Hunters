package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import java.io.*;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;

public class GamePageHard implements Initializable {

    public AnchorPane background , anchor_pane1 , anchor_pane2 , anchor_pane3 , anchor_pane4 , anchor_pane5 , anchor_pane6 , anchor_pane7 , anchor_pane8 , anchor_pane9 ,
            anchor_pane10 , anchor_pane11 , anchor_pane12 , anchor_pane13 , anchor_pane14 , anchor_pane15 , anchor_pane16 , anchor_pane17 , anchor_pane18 ,
            anchor_pane19 , anchor_pane20 , anchor_pane21 , anchor_pane22 , anchor_pane23 , anchor_pane24 , anchor_pane25 , anchor_pane26 , anchor_pane27 ,
            anchor_pane28 , anchor_pane29 , anchor_pane30 , anchor_pane31 , anchor_pane32 , anchor_pane33 , anchor_pane34 , anchor_pane35 , anchor_pane36;

    public Rectangle simple_guard1 , simple_guard2 , simple_guard3 , simple_guard4 , simple_guard5 , simple_guard6 , simple_guard7 , simple_guard8 , simple_guard9 ,
            simple_guard10 , simple_guard11 , simple_guard12 , simple_guard13 , simple_guard14 , simple_guard15 , simple_guard16 , simple_guard17 , simple_guard18 ,
            simple_guard19 , simple_guard20 , simple_guard21 , simple_guard22 , simple_guard23 , simple_guard24 , simple_guard25 , simple_guard26 , simple_guard27 ,
            simple_guard28 , simple_guard29 , simple_guard30 , simple_guard31 , simple_guard32 , simple_guard33 , simple_guard34 , simple_guard35 , simple_guard36;

    public Rectangle arrow1 , arrow2 , arrow3 , arrow4 , arrow5 , arrow6 , arrow7 , arrow8 , arrow9 ,
            arrow10 , arrow11 , arrow12 , arrow13 , arrow14 , arrow15 , arrow16 , arrow17 , arrow18 ,
            arrow19 , arrow20 , arrow21 , arrow22 , arrow23 , arrow24 , arrow25 , arrow26 , arrow27 ,
            arrow28 , arrow29 , arrow30 , arrow31 , arrow32 , arrow33 , arrow34 , arrow35 , arrow36;

    public Rectangle Maine1 , Maine2 , Maine3 , Maine4 , Maine5 , Maine6 , Maine7 , Maine8 , Maine9 ,
            Maine10 , Maine11 , Maine12 , Maine13 , Maine14 , Maine15 , Maine16 , Maine17 , Maine18 ,
            Maine19 , Maine20 , Maine21 , Maine22 , Maine23 , Maine24 , Maine25 , Maine26 , Maine27 ,
            Maine28 , Maine29 , Maine30 , Maine31 , Maine32 , Maine33 , Maine34 , Maine35 , Maine36;

    public Rectangle knight_guard1 , knight_guard2 , knight_guard3 , knight_guard4 , knight_guard5 , knight_guard6 , knight_guard7 , knight_guard8 , knight_guard9 ,
            knight_guard10 , knight_guard11 , knight_guard12 , knight_guard13 , knight_guard14 , knight_guard15 , knight_guard16 , knight_guard17 , knight_guard18 ,
            knight_guard19 , knight_guard20 , knight_guard21 , knight_guard22 , knight_guard23 , knight_guard24 , knight_guard25 , knight_guard26 , knight_guard27 ,
            knight_guard28 , knight_guard29 , knight_guard30 , knight_guard31 , knight_guard32 , knight_guard33 , knight_guard34 , knight_guard35 , knight_guard36;

    public Rectangle knight_arrow1 , knight_arrow2 , knight_arrow3 , knight_arrow4 , knight_arrow5 , knight_arrow6 , knight_arrow7 , knight_arrow8 , knight_arrow9 ,
            knight_arrow10 , knight_arrow11 , knight_arrow12 , knight_arrow13 , knight_arrow14 , knight_arrow15 , knight_arrow16 , knight_arrow17 , knight_arrow18 ,
            knight_arrow19 , knight_arrow20 , knight_arrow21 , knight_arrow22 , knight_arrow23 , knight_arrow24 , knight_arrow25 , knight_arrow26 , knight_arrow27 ,
            knight_arrow28 , knight_arrow29 , knight_arrow30 , knight_arrow31 , knight_arrow32 , knight_arrow33 , knight_arrow34  , knight_arrow35 , knight_arrow36;

    public Polygon money_pocket1 , money_pocket2 , money_pocket3 , money_pocket4 , money_pocket5 , money_pocket6 , money_pocket7 , money_pocket8 , money_pocket9 ,
            money_pocket10 , money_pocket11 , money_pocket12 , money_pocket13 , money_pocket14 , money_pocket15 , money_pocket16 , money_pocket17 , money_pocket18 ,
            money_pocket19 , money_pocket20 , money_pocket21 , money_pocket22 , money_pocket23 , money_pocket24 , money_pocket25 , money_pocket26 , money_pocket27 ,
            money_pocket28 , money_pocket29 , money_pocket30 , money_pocket31 , money_pocket32 , money_pocket33 , money_pocket34 , money_pocket35 , money_pocket36;

    public Rectangle mother_guard1 , mother_guard2 , mother_guard3 , mother_guard4 , mother_guard5 , mother_guard6 , mother_guard7 , mother_guard8 , mother_guard9 ,
            mother_guard10 , mother_guard11 , mother_guard12 , mother_guard13 , mother_guard14 , mother_guard15 , mother_guard16 , mother_guard17 , mother_guard18 ,
            mother_guard19 , mother_guard20 , mother_guard21 , mother_guard22 , mother_guard23 , mother_guard24 , mother_guard25 , mother_guard26 , mother_guard27 ,
            mother_guard28 , mother_guard29 , mother_guard30 , mother_guard31 , mother_guard32 , mother_guard33 , mother_guard34 , mother_guard35 , mother_guard36;

    public Polygon money_pocket_guard1 , money_pocket_guard2 , money_pocket_guard3 , money_pocket_guard4 , money_pocket_guard5 , money_pocket_guard6 , money_pocket_guard7 ,
            money_pocket_guard8 , money_pocket_guard9 , money_pocket_guard10 , money_pocket_guard11 , money_pocket_guard12 , money_pocket_guard13 , money_pocket_guard14 ,
            money_pocket_guard15 , money_pocket_guard16 , money_pocket_guard17 , money_pocket_guard18 , money_pocket_guard19 , money_pocket_guard20 , money_pocket_guard21 ,
            money_pocket_guard22 , money_pocket_guard23 , money_pocket_guard24 , money_pocket_guard25 , money_pocket_guard26 , money_pocket_guard27 , money_pocket_guard28 ,
            money_pocket_guard29 , money_pocket_guard30 , money_pocket_guard31 , money_pocket_guard32 , money_pocket_guard33 , money_pocket_guard34 , money_pocket_guard35 , money_pocket_guard36;

    public Circle normal_hunter1 , normal_hunter2 , normal_hunter3 , normal_hunter4 , normal_hunter5 , normal_hunter6 , normal_hunter7 ,
            normal_hunter8 , normal_hunter9 , normal_hunter10 , normal_hunter11 , normal_hunter12;

    public Circle suicide_hunter1 , suicide_hunter2 , suicide_hunter3;

    public Circle knight_hunter1 , knight_hunter2 , knight_hunter3;

    public Rectangle box;

    public Rectangle normal_guard , maine , knight_guard , mother_guard;

    public Rectangle select_normal_guard , select_maine , select_knight_guard , select_mother_guard;

    public Line delete_line1 , delete_line2 , delete_line3 , delete_line4 , delete_line5 , delete_line6 , line ,
            line1 , line2 , line3 , line4 , line5 , line6 , line7 , line8 , line9 , line10 , line11 , line12;

    public TextField money_text , score_text;

    public ProgressBar progress_bar_normal_guard , progress_bar_Maine , progress_bar_knight_guard , progress_bar_mother_guard;

    public GridPane grid_pane;

    public Button start , pause;

    public Label Score;

    int guardNum , rowCoefficient , arrowEffectRange , suicideHunter , normalHunterNum , anchorPaneNum , normalHunterAroundNum , knightHunter ,
            suicideHunterAroundNum , suicideHunterNum , normalHunter , stopAnchorPaneNum , pastScores , decelerationNum = 0 , knightHunterNum ,
            reproductionMoneyPocket = 0 , speedAndDestructionNum = 0 , deleteRowNum = 0 , select = 0 , Y , X , knightHunterAroundNum ,
            money = 60 , score = 0 , stop = 0 , speed = 100 , music = 10000;

    double destruction = 0.005 , opacity = 60;

    Boolean highScore = true , darkMode = false;

    int[] reproductionNormalHunter = {300 , 100 , -100 , -300 , -500 , -700 , -900 , -1100 , -1300 , -1500 , -1700 , -1900};
    int[] reproductionSuicideHunter = {-100 , -900 , -1700};
    int[] reproductionKnightHunter = {-300 , -700 , -1100};
    int[] collisionNormalHunterNum = {0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0};
    int[] collisionSuicideHunterNum = {0 , 0 , 0};
    int[] collisionKnightHunterNum = {0 , 0 , 0};
    int[] shootAgain = {0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0};
    int[] shootAgainKnightArrow = {0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0};
    int[] reproductionMoneyPocketGuard = {0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0};
    double[] opacityNormalHunter = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};
    double[] opacitySuicideHunter = {1 , 1 , 1};
    double[] opacityKnightHunterArmor = {1 , 1 , 1};
    double[] opacityKnightHunter = {1 , 1 , 1};
    double[] opacitySimpleGuard = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};
    double[] opacityKnightGuard = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};
    double[] opacityMotherGuard = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};
    Boolean[] selectSimpleGuard = {false ,false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false ,
            false , false , false , false , false , false ,false , false , false , false ,false , false , false , false , false , false ,false , false , false , false};
    Boolean[] selectMaine = {false ,false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false ,
            false , false , false , false , false , false ,false , false , false , false ,false , false , false , false , false , false ,false , false , false , false};
    Boolean[] selectKnightGuard = {false ,false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false ,
            false , false , false , false , false , false ,false , false , false , false ,false , false , false , false , false , false ,false , false , false , false};
    Boolean[] selectMotherGuard = {false ,false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false ,
            false ,false , false , false , false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false , false};
    Boolean[] visibleArrow = {true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true ,
            true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true};
    Boolean[] visibleKnightArrow = {true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true ,
            true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true};
    Boolean[] hideArrow = {true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true ,
            true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true};
    Boolean[] hideKnightArrow = {true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true ,
            true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true};
    Boolean[] deleteRow = {false , false , false , false , false , false};

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        progress_bar_Maine.setStyle("-fx-accent: #1dea28");
        progress_bar_knight_guard.setStyle("-fx-accent: #541ee8");
        progress_bar_mother_guard.setStyle("-fx-accent: #1ff7ff");

        AudioClip note = new AudioClip(this.getClass().getResource("music.wav").toString());
        note.play();

        Thread thread = new Thread(new Runnable() {
            Circle[] normal_hunter = {normal_hunter1 , normal_hunter2 , normal_hunter3 , normal_hunter4 , normal_hunter5 , normal_hunter6 , normal_hunter7 , normal_hunter8 ,
                    normal_hunter9 , normal_hunter10 , normal_hunter11 , normal_hunter12};
            Circle[] suicide_hunter = {suicide_hunter1 , suicide_hunter2 , suicide_hunter3};
            Circle[] knight_hunter = {knight_hunter1 , knight_hunter2 , knight_hunter3};
            @Override
            public void run() {
                try {
                    Thread.sleep(20000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                normal_hunter[0].setLayoutY(RandHunterY());
                normal_hunter[1].setLayoutY(RandHunterY());
                normal_hunter[2].setLayoutY(RandHunterY());
                normal_hunter[3].setLayoutY(RandHunterY());
                normal_hunter[4].setLayoutY(RandHunterY());
                normal_hunter[5].setLayoutY(RandHunterY());
                normal_hunter[6].setLayoutY(RandHunterY());
                normal_hunter[7].setLayoutY(RandHunterY());
                normal_hunter[8].setLayoutY(RandHunterY());
                normal_hunter[9].setLayoutY(RandHunterY());
                normal_hunter[10].setLayoutY(RandHunterY());
                normal_hunter[11].setLayoutY(RandHunterY());
                suicide_hunter[0].setLayoutY(RandHunterY());
                suicide_hunter[1].setLayoutY(RandHunterY());
                suicide_hunter[2].setLayoutY(RandHunterY());
                knight_hunter[0].setLayoutY(RandHunterY());
                knight_hunter[1].setLayoutY(RandHunterY());
                knight_hunter[2].setLayoutY(RandHunterY());
                while (true) {
                    music += speed;
                    if (music >= 77000){
                        note.play();
                        music = 0;
                    }
                    while (stop == 1) {
                        try {
                            music+=21;
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    speedAndDestructionNum++;
                    if (speedAndDestructionNum == 500 && decelerationNum < 5) {
                        speed -= 10;
                        destruction += 0.002;
                        speedAndDestructionNum = 0;
                        decelerationNum++;
                    }
                    reproductionNormalHunter[0]++;
                    reproductionNormalHunter[1]++;
                    reproductionNormalHunter[2]++;
                    reproductionNormalHunter[3]++;
                    reproductionNormalHunter[4]++;
                    reproductionNormalHunter[5]++;
                    reproductionNormalHunter[6]++;
                    reproductionNormalHunter[7]++;
                    reproductionNormalHunter[8]++;
                    reproductionNormalHunter[9]++;
                    reproductionNormalHunter[10]++;
                    reproductionNormalHunter[11]++;
                    reproductionSuicideHunter[0]++;
                    reproductionSuicideHunter[1]++;
                    reproductionSuicideHunter[2]++;
                    reproductionKnightHunter[0]++;
                    reproductionKnightHunter[1]++;
                    reproductionKnightHunter[2]++;
                    try {
                        Thread.sleep(speed);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {

                            //  Move normal hunter and delete row

                            for (normalHunter = 0; normalHunter < 12; normalHunter++) {
                                if (reproductionNormalHunter[normalHunter] >= 300) {
                                    if (normal_hunter[normalHunter].getLayoutX() <= 30) {
                                        reproductionNormalHunter[normalHunter] = RandHunter();
                                        normal_hunter[normalHunter].setLayoutX(1700);
                                        normal_hunter[normalHunter].setOpacity(1);
                                        opacityNormalHunter[normalHunter] = 1;
                                        collisionNormalHunterNum[normalHunter] = 0;
                                        switch ((int) normal_hunter[normalHunter].getLayoutY()){
                                            case 189:
                                                if (deleteRow[0] == false){
                                                    deleteRowNum++;
                                                    line1.setVisible(true);
                                                    line2.setVisible(true);
                                                    delete_line1.setVisible(true);
                                                    deleteRow[0] = true;
                                                }
                                                break;
                                            case 297:
                                                if (deleteRow[1] == false){
                                                    deleteRowNum++;
                                                    line3.setVisible(true);
                                                    line4.setVisible(true);
                                                    delete_line2.setVisible(true);
                                                    deleteRow[1] = true;
                                                }
                                                break;
                                            case 405:
                                                if (deleteRow[2] == false){
                                                    deleteRowNum++;
                                                    line5.setVisible(true);
                                                    line6.setVisible(true);
                                                    delete_line3.setVisible(true);
                                                    deleteRow[2] = true;
                                                }
                                                break;
                                            case 513:
                                                if (deleteRow[3] == false){
                                                    deleteRowNum++;
                                                    line7.setVisible(true);
                                                    line8.setVisible(true);
                                                    delete_line4.setVisible(true);
                                                    deleteRow[3] = true;
                                                }
                                                break;
                                            case 621:
                                                if (deleteRow[4] == false){
                                                    deleteRowNum++;
                                                    line9.setVisible(true);
                                                    line10.setVisible(true);
                                                    delete_line5.setVisible(true);
                                                    deleteRow[4] = true;
                                                }
                                                break;
                                            case 729:
                                                if (deleteRow[5] == false){
                                                    deleteRowNum++;
                                                    line11.setVisible(true);
                                                    line12.setVisible(true);
                                                    delete_line6.setVisible(true);
                                                    deleteRow[5] = true;
                                                }
                                                break;
                                        }
                                        if (deleteRowNum == 6){
                                            try {
                                                File myObj = new File("RecordHard.txt");
                                                Scanner myReader = new Scanner(myObj);
                                                while (myReader.hasNextLine()) {
                                                    pastScores = Integer.parseInt(myReader.nextLine());
                                                    if (pastScores >= score) {
                                                        highScore = false;
                                                    }
                                                }
                                                myReader.close();
                                            } catch (FileNotFoundException e) {
                                                System.out.println("An error occurred.");
                                                e.printStackTrace();
                                            }
                                            if (highScore == true) {
                                                try {
                                                    FileWriter myWriter = new FileWriter("RecordHard.txt", true);
                                                    PrintWriter pw = new PrintWriter(myWriter);
                                                    pw.println(score);
                                                    myWriter.close();
                                                } catch (IOException e) {
                                                    System.out.println("An error occurred.");
                                                    e.printStackTrace();
                                                }
                                            }
                                            Stage primaryStage = (Stage) score_text.getScene().getWindow();
                                            FXMLLoader loader = new FXMLLoader(getClass().getResource("end_game.fxml"));
                                            Parent root = null;
                                            try {
                                                root = loader.load();
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                            if (darkMode == true){
                                                EndGameController endGameController = loader.getController();
                                                endGameController.darkMode();
                                            }
                                            EndGameController controller = loader.getController();
                                            controller.setScore(score);
                                            primaryStage.setTitle("GUARDS vs Hunters");
                                            primaryStage.setScene(new Scene(root, 1533, 797));
                                            primaryStage.show();
                                        }
                                        normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                    }
                                    switch ((int) normal_hunter[normalHunter].getLayoutY()){
                                        case 189:
                                            if (deleteRow[0] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                        case 297:
                                            if (deleteRow[1] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                        case 405:
                                            if (deleteRow[2] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                        case 513:
                                            if (deleteRow[3] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                        case 621:
                                            if (deleteRow[4] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                        case 729:
                                            if (deleteRow[5] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                    }
                                    normal_hunter[normalHunter].setLayoutX(normal_hunter[normalHunter].getLayoutX() - 2);
                                }
                            }

                            //  Move suicide hunter and delete row

                            for (suicideHunter = 0; suicideHunter < 3; suicideHunter++) {
                                if (reproductionSuicideHunter[suicideHunter] >= 700) {
                                    if (suicide_hunter[suicideHunter].getLayoutX() <= 30) {
                                        reproductionSuicideHunter[suicideHunter] = RandHunter();
                                        suicide_hunter[suicideHunter].setLayoutX(1700);
                                        suicide_hunter[suicideHunter].setOpacity(1);
                                        opacitySuicideHunter[suicideHunter] = 1;
                                        collisionSuicideHunterNum[suicideHunter] = 0;
                                        switch ((int) suicide_hunter[suicideHunter].getLayoutY()){
                                            case 189:
                                                if (deleteRow[0] == false){
                                                    deleteRowNum++;
                                                    line1.setVisible(true);
                                                    line2.setVisible(true);
                                                    delete_line1.setVisible(true);
                                                    deleteRow[0] = true;
                                                }
                                                break;
                                            case 297:
                                                if (deleteRow[1] == false){
                                                    deleteRowNum++;
                                                    line3.setVisible(true);
                                                    line4.setVisible(true);
                                                    delete_line2.setVisible(true);
                                                    deleteRow[1] = true;
                                                }
                                                break;
                                            case 405:
                                                if (deleteRow[2] == false){
                                                    deleteRowNum++;
                                                    line5.setVisible(true);
                                                    line6.setVisible(true);
                                                    delete_line3.setVisible(true);
                                                    deleteRow[2] = true;
                                                }
                                                break;
                                            case 513:
                                                if (deleteRow[3] == false){
                                                    deleteRowNum++;
                                                    line7.setVisible(true);
                                                    line8.setVisible(true);
                                                    delete_line4.setVisible(true);
                                                    deleteRow[3] = true;
                                                }
                                                break;
                                            case 621:
                                                if (deleteRow[4] == false){
                                                    deleteRowNum++;
                                                    line9.setVisible(true);
                                                    line10.setVisible(true);
                                                    delete_line5.setVisible(true);
                                                    deleteRow[4] = true;
                                                }
                                                break;
                                            case 729:
                                                if (deleteRow[5] == false){
                                                    deleteRowNum++;
                                                    line11.setVisible(true);
                                                    line12.setVisible(true);
                                                    delete_line6.setVisible(true);
                                                    deleteRow[5] = true;
                                                }
                                                break;
                                        }
                                        if (deleteRowNum == 6){
                                            try {
                                                File myObj = new File("RecordHard.txt");
                                                Scanner myReader = new Scanner(myObj);
                                                while (myReader.hasNextLine()) {
                                                    pastScores = Integer.parseInt(myReader.nextLine());
                                                    if (pastScores >= score) {
                                                        highScore = false;
                                                    }
                                                }
                                                myReader.close();
                                            } catch (FileNotFoundException e) {
                                                System.out.println("An error occurred.");
                                                e.printStackTrace();
                                            }
                                            if (highScore == true) {
                                                try {
                                                    FileWriter myWriter = new FileWriter("RecordHard.txt", true);
                                                    PrintWriter pw = new PrintWriter(myWriter);
                                                    pw.println(score);
                                                    myWriter.close();
                                                } catch (IOException e) {
                                                    System.out.println("An error occurred.");
                                                    e.printStackTrace();
                                                }
                                            }
                                            Stage primaryStage = (Stage) score_text.getScene().getWindow();
                                            FXMLLoader loader = new FXMLLoader(getClass().getResource("end_game.fxml"));
                                            Parent root = null;
                                            try {
                                                root = loader.load();
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                            if (darkMode == true){
                                                EndGameController endGameController = loader.getController();
                                                endGameController.darkMode();
                                            }
                                            EndGameController controller = loader.getController();
                                            controller.setScore(score);
                                            primaryStage.setTitle("GUARDS vs Hunters");
                                            primaryStage.setScene(new Scene(root, 1533, 797));
                                            primaryStage.show();
                                        }
                                        suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                    }
                                    switch ((int) suicide_hunter[suicideHunter].getLayoutY()){
                                        case 189:
                                            if (deleteRow[0] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                        case 297:
                                            if (deleteRow[1] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                        case 405:
                                            if (deleteRow[2] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                        case 513:
                                            if (deleteRow[3] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                        case 621:
                                            if (deleteRow[4] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                        case 729:
                                            if (deleteRow[5] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                    }
                                    suicide_hunter[suicideHunter].setLayoutX(suicide_hunter[suicideHunter].getLayoutX() - 5);
                                }
                            }

                            //  Move knight hunter and delete row

                            for (knightHunter = 0; knightHunter < 2; knightHunter++) {
                                if (reproductionKnightHunter[knightHunter] >= 400) {
                                    if (knight_hunter[knightHunter].getLayoutX() <= 30) {
                                        reproductionKnightHunter[knightHunter] = RandHunter();
                                        knight_hunter[knightHunter].setLayoutX(1700);
                                        knight_hunter[knightHunter].setOpacity(1);
                                        opacityKnightHunter[knightHunter] = 1;
                                        collisionKnightHunterNum[knightHunter] = 0;
                                        switch ((int) knight_hunter[knightHunter].getLayoutY()){
                                            case 189:
                                                if (deleteRow[0] == false){
                                                    deleteRowNum++;
                                                    line1.setVisible(true);
                                                    line2.setVisible(true);
                                                    delete_line1.setVisible(true);
                                                    deleteRow[0] = true;
                                                }
                                                break;
                                            case 297:
                                                if (deleteRow[1] == false){
                                                    deleteRowNum++;
                                                    line3.setVisible(true);
                                                    line4.setVisible(true);
                                                    delete_line2.setVisible(true);
                                                    deleteRow[1] = true;
                                                }
                                                break;
                                            case 405:
                                                if (deleteRow[2] == false){
                                                    deleteRowNum++;
                                                    line5.setVisible(true);
                                                    line6.setVisible(true);
                                                    delete_line3.setVisible(true);
                                                    deleteRow[2] = true;
                                                }
                                                break;
                                            case 513:
                                                if (deleteRow[3] == false){
                                                    deleteRowNum++;
                                                    line7.setVisible(true);
                                                    line8.setVisible(true);
                                                    delete_line4.setVisible(true);
                                                    deleteRow[3] = true;
                                                }
                                                break;
                                            case 621:
                                                if (deleteRow[4] == false){
                                                    deleteRowNum++;
                                                    line9.setVisible(true);
                                                    line10.setVisible(true);
                                                    delete_line5.setVisible(true);
                                                    deleteRow[4] = true;
                                                }
                                                break;
                                            case 729:
                                                if (deleteRow[5] == false){
                                                    deleteRowNum++;
                                                    line11.setVisible(true);
                                                    line12.setVisible(true);
                                                    delete_line6.setVisible(true);
                                                    deleteRow[5] = true;
                                                }
                                                break;
                                        }
                                        if (deleteRowNum == 6){
                                            try {
                                                File myObj = new File("RecordEasy.txt");
                                                Scanner myReader = new Scanner(myObj);
                                                while (myReader.hasNextLine()) {
                                                    pastScores = Integer.parseInt(myReader.nextLine());
                                                    if (pastScores >= score) {
                                                        highScore = false;
                                                    }
                                                }
                                                myReader.close();
                                            } catch (FileNotFoundException e) {
                                                System.out.println("An error occurred.");
                                                e.printStackTrace();
                                            }
                                            if (highScore == true) {
                                                try {
                                                    FileWriter myWriter = new FileWriter("RecordEasy.txt", true);
                                                    PrintWriter pw = new PrintWriter(myWriter);
                                                    pw.println(score);
                                                    myWriter.close();
                                                } catch (IOException e) {
                                                    System.out.println("An error occurred.");
                                                    e.printStackTrace();
                                                }
                                            }
                                            Stage primaryStage = (Stage) score_text.getScene().getWindow();
                                            FXMLLoader loader = new FXMLLoader(getClass().getResource("end_game.fxml"));
                                            Parent root = null;
                                            try {
                                                root = loader.load();
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                            if (darkMode == true){
                                                EndGameController endGameController = loader.getController();
                                                endGameController.darkMode();
                                            }
                                            EndGameController controller = loader.getController();
                                            controller.setScore(score);
                                            primaryStage.setTitle("GUARDS vs Hunters");
                                            primaryStage.setScene(new Scene(root, 1533, 797));
                                            primaryStage.show();
                                        }
                                        knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                    }
                                    switch ((int) knight_hunter[knightHunter].getLayoutY()){
                                        case 189:
                                            if (deleteRow[0] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                        case 297:
                                            if (deleteRow[1] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                        case 405:
                                            if (deleteRow[2] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                        case 513:
                                            if (deleteRow[3] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                        case 621:
                                            if (deleteRow[4] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                        case 729:
                                            if (deleteRow[5] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                    }
                                    knight_hunter[knightHunter].setLayoutX(knight_hunter[knightHunter].getLayoutX() - 2);
                                }
                            }
                        }
                    });
                }
            }
        });
        thread.start();

        Thread thread2 = new Thread(new Runnable() {

            AnchorPane[] anchor_pane = {anchor_pane1 , anchor_pane2 , anchor_pane3 , anchor_pane4 , anchor_pane5 , anchor_pane6 , anchor_pane7 , anchor_pane8 , anchor_pane9 ,
                    anchor_pane10 , anchor_pane11 , anchor_pane12 , anchor_pane13 , anchor_pane14 , anchor_pane15 , anchor_pane16 , anchor_pane17 , anchor_pane18 ,
                    anchor_pane19 , anchor_pane20 , anchor_pane21 , anchor_pane22 , anchor_pane23 , anchor_pane24 , anchor_pane25 , anchor_pane26 , anchor_pane27 ,
                    anchor_pane28 , anchor_pane29 , anchor_pane30 , anchor_pane31 , anchor_pane32 , anchor_pane33 , anchor_pane34 , anchor_pane35 , anchor_pane36};

            Rectangle[] simple_guard = {simple_guard1 , simple_guard2 , simple_guard3 , simple_guard4 , simple_guard5 , simple_guard6 , simple_guard7 , simple_guard8 , simple_guard9 ,
                    simple_guard10 , simple_guard11 , simple_guard12 , simple_guard13 , simple_guard14 , simple_guard15 , simple_guard16 , simple_guard17 , simple_guard18 ,
                    simple_guard19 , simple_guard20 , simple_guard21 , simple_guard22 , simple_guard23 , simple_guard24 , simple_guard25 , simple_guard26 , simple_guard27 ,
                    simple_guard28 , simple_guard29 , simple_guard30 , simple_guard31 , simple_guard32 , simple_guard33 , simple_guard34 , simple_guard35 , simple_guard36};

            Rectangle[] arrow = {arrow1 , arrow2 , arrow3 , arrow4 , arrow5 , arrow6 , arrow7 , arrow8 , arrow9 ,
                    arrow10 , arrow11 , arrow12 , arrow13 , arrow14 , arrow15 , arrow16 , arrow17 , arrow18 ,
                    arrow19 , arrow20 , arrow21 , arrow22 , arrow23 , arrow24 , arrow25 , arrow26 , arrow27 ,
                    arrow28 , arrow29 , arrow30 , arrow31 , arrow32 , arrow33 , arrow34 , arrow35 , arrow36};

            Rectangle[] Maine = {Maine1 , Maine2 , Maine3 , Maine4 , Maine5 , Maine6 , Maine7 , Maine8 , Maine9 ,
                    Maine10 , Maine11 , Maine12 , Maine13 , Maine14 , Maine15 , Maine16 , Maine17 , Maine18 ,
                    Maine19 , Maine20 , Maine21 , Maine22 , Maine23 , Maine24 , Maine25 , Maine26 , Maine27 ,
                    Maine28 , Maine29 , Maine30 , Maine31 , Maine32 , Maine33 , Maine34 , Maine35 , Maine36};

            Rectangle[] knight_guard = {knight_guard1 , knight_guard2 , knight_guard3 , knight_guard4 , knight_guard5 , knight_guard6 , knight_guard7 , knight_guard8 , knight_guard9 ,
                    knight_guard10 , knight_guard11 , knight_guard12 , knight_guard13 , knight_guard14 , knight_guard15 , knight_guard16 , knight_guard17 , knight_guard18 ,
                    knight_guard19 , knight_guard20 , knight_guard21 , knight_guard22 , knight_guard23 , knight_guard24 , knight_guard25 , knight_guard26 , knight_guard27 ,
                    knight_guard28 , knight_guard29 , knight_guard30 , knight_guard31 , knight_guard32 , knight_guard33 , knight_guard34 , knight_guard35 , knight_guard36};

            Rectangle[] knight_arrow = {knight_arrow1 , knight_arrow2 , knight_arrow3 , knight_arrow4 , knight_arrow5 , knight_arrow6 , knight_arrow7 , knight_arrow8 , knight_arrow9 ,
                    knight_arrow10 , knight_arrow11 , knight_arrow12 , knight_arrow13 , knight_arrow14 , knight_arrow15 , knight_arrow16 , knight_arrow17 , knight_arrow18 ,
                    knight_arrow19 , knight_arrow20 , knight_arrow21 , knight_arrow22 , knight_arrow23 , knight_arrow24 , knight_arrow25 , knight_arrow26 , knight_arrow27 ,
                    knight_arrow28 , knight_arrow29 , knight_arrow30 , knight_arrow31 , knight_arrow32 , knight_arrow33 , knight_arrow34  , knight_arrow35 , knight_arrow36};

            Rectangle[] mother_guard = {mother_guard1 , mother_guard2 , mother_guard3 , mother_guard4 , mother_guard5 , mother_guard6 , mother_guard7 , mother_guard8 , mother_guard9 ,
                    mother_guard10 , mother_guard11 , mother_guard12 , mother_guard13 , mother_guard14 , mother_guard15 , mother_guard16 , mother_guard17 , mother_guard18 ,
                    mother_guard19 , mother_guard20 , mother_guard21 , mother_guard22 , mother_guard23 , mother_guard24 , mother_guard25 , mother_guard26 , mother_guard27 ,
                    mother_guard28 , mother_guard29 , mother_guard30 , mother_guard31 , mother_guard32 , mother_guard33 , mother_guard34 , mother_guard35 , mother_guard36};

            Polygon[] money_pocket_guard = {money_pocket_guard1 , money_pocket_guard2 , money_pocket_guard3 , money_pocket_guard4 , money_pocket_guard5 , money_pocket_guard6 , money_pocket_guard7 ,
                    money_pocket_guard8 , money_pocket_guard9 , money_pocket_guard10 , money_pocket_guard11 , money_pocket_guard12 , money_pocket_guard13 , money_pocket_guard14 ,
                    money_pocket_guard15 , money_pocket_guard16 , money_pocket_guard17 , money_pocket_guard18 , money_pocket_guard19 , money_pocket_guard20 , money_pocket_guard21 ,
                    money_pocket_guard22 , money_pocket_guard23 , money_pocket_guard24 , money_pocket_guard25 , money_pocket_guard26 , money_pocket_guard27 , money_pocket_guard28 ,
                    money_pocket_guard29 , money_pocket_guard30 , money_pocket_guard31 , money_pocket_guard32 , money_pocket_guard33 , money_pocket_guard34 , money_pocket_guard35 , money_pocket_guard36};

            Circle[] normal_hunter = {normal_hunter1 , normal_hunter2 , normal_hunter3 , normal_hunter4 , normal_hunter5 , normal_hunter6 , normal_hunter7 ,
                    normal_hunter8 , normal_hunter9 , normal_hunter10 , normal_hunter11 , normal_hunter12};

            Circle[] suicide_hunter = {suicide_hunter1 , suicide_hunter2 , suicide_hunter3};

            Circle[] knight_hunter = {knight_hunter1 , knight_hunter2 , knight_hunter3};

            @Override
            public void run() {
                while (true) {
                    while (stop == 1) {
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            for (guardNum = 0 ; guardNum < 36 ; guardNum++) {
                                for (rowCoefficient = 0 ; rowCoefficient < 6 ; rowCoefficient++) {
                                    if (6 * rowCoefficient == guardNum){
                                        Y = 139;
                                    }
                                    if (6 * rowCoefficient + 1 == guardNum){
                                        Y = 247;
                                    }
                                    if (6 * rowCoefficient + 2 == guardNum){
                                        Y = 355;
                                    }
                                    if (6 * rowCoefficient + 3 == guardNum){
                                        Y = 463;
                                    }
                                    if (6 * rowCoefficient + 4 == guardNum){
                                        Y = 571;
                                    }
                                    if (6 * rowCoefficient + 5 == guardNum){
                                        Y = 679;
                                    }
                                }
                                if (0 <= guardNum && guardNum < 6) {
                                    arrowEffectRange = 1367;
                                    X = 150;
                                }
                                if (6 <= guardNum && guardNum < 12) {
                                    arrowEffectRange = 1132;
                                    X = 385;
                                }
                                if (12 <= guardNum && guardNum < 18) {
                                    arrowEffectRange = 897;
                                    X = 620;
                                }
                                if (18 <= guardNum && guardNum < 24) {
                                    arrowEffectRange = 662;
                                    X = 855;
                                }
                                if (24 <= guardNum && guardNum < 30) {
                                    arrowEffectRange = 427;
                                    X = 1090;
                                }
                                if (30 <= guardNum && guardNum < 36) {
                                    arrowEffectRange = 192;
                                    X = 1325;
                                }

                                //  Simple guard section

                                if (selectSimpleGuard[guardNum] == true) {
                                    simple_guard[guardNum].setVisible(true);
                                    if (visibleArrow[guardNum] == true){
                                        arrow[guardNum].setVisible(true);
                                        visibleArrow[guardNum] = false;
                                    }

                                    //  Arrow move

                                    arrow[guardNum].setLayoutX(arrow[guardNum].getLayoutX() + 5);

                                    //  Shoot again

                                    shootAgain[guardNum]++;
                                    if (shootAgain[guardNum] == 260){
                                        arrow[guardNum].setVisible(true);
                                        shootAgain[guardNum] = 0;
                                        arrow[guardNum].setLayoutX(77);
                                        hideArrow[guardNum] = true;
                                    }

                                    //  Normal Hunter section in the simple guard

                                    for (normalHunterNum = 0 ; normalHunterNum < 12 ; normalHunterNum++) {

                                        //  Collision of the simple guard arrow with normal hunter

                                        if (arrow[guardNum].getLayoutY() + Y + 3 == normal_hunter[normalHunterNum].getLayoutY() && (arrow[guardNum].getLayoutX() + X <= normal_hunter[normalHunterNum].getLayoutX() && arrow[guardNum].getLayoutX() + X + 50 >= normal_hunter[normalHunterNum].getLayoutX()) && hideArrow[guardNum] == true && arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionNormalHunterNum[normalHunterNum]++;
                                            opacityNormalHunter[normalHunterNum] -= 0.1;
                                            if (opacityNormalHunter[normalHunterNum] > 0){
                                                normal_hunter[normalHunterNum].setOpacity(opacityNormalHunter[normalHunterNum]);
                                            }
                                            if (collisionNormalHunterNum[normalHunterNum] == 10){
                                                score += 5;
                                                score_text.setText(String.valueOf(score));
                                                reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                normal_hunter[normalHunterNum].setLayoutX(1700);
                                                normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                collisionNormalHunterNum[normalHunterNum] = 0;
                                                opacityNormalHunter[normalHunterNum] = 1;
                                                normal_hunter[normalHunterNum].setOpacity(1);
                                            }
                                            arrow[guardNum].setVisible(false);
                                            hideArrow[guardNum] = false;
                                        }

                                        //  Collision of the simple guard with normal hunter

                                        if (simple_guard[guardNum].getLayoutY() + Y + 33 == normal_hunter[normalHunterNum].getLayoutY() && (simple_guard[guardNum].getLayoutX() + X + 60 <= normal_hunter[normalHunterNum].getLayoutX() && simple_guard[guardNum].getLayoutX() + X + 110 >= normal_hunter[normalHunterNum].getLayoutX())){
                                            if (opacitySimpleGuard[guardNum] >= 0){
                                                normal_hunter[normalHunterNum].setLayoutX(normal_hunter[normalHunterNum].getLayoutX() + 2);
                                                opacitySimpleGuard[guardNum] -= destruction;
                                                simple_guard[guardNum].setOpacity(opacitySimpleGuard[guardNum]);
                                            }
                                            else {
                                                selectSimpleGuard[guardNum] = false;
                                                simple_guard[guardNum].setOpacity(1);
                                                arrow[guardNum].setLayoutX(77);
                                                simple_guard[guardNum].setVisible(false);
                                                opacitySimpleGuard[guardNum] = 1;
                                            }
                                        }
                                    }

                                    //  Suicide Hunter section in the simple guard

                                    for (suicideHunterNum = 0 ; suicideHunterNum < 3 ; suicideHunterNum++){

                                        //  Collision of the simple guard arrow with suicide hunter

                                        if (arrow[guardNum].getLayoutY() + Y + 3 == suicide_hunter[suicideHunterNum].getLayoutY() && (arrow[guardNum].getLayoutX() + X <= suicide_hunter[suicideHunterNum].getLayoutX() && arrow[guardNum].getLayoutX() + X + 50 >= suicide_hunter[suicideHunterNum].getLayoutX()) && hideArrow[guardNum] == true && arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionSuicideHunterNum[suicideHunterNum]++;
                                            opacitySuicideHunter[suicideHunterNum] -= 0.25;
                                            if (opacitySuicideHunter[suicideHunterNum] > 0){
                                                suicide_hunter[suicideHunterNum].setOpacity(opacitySuicideHunter[suicideHunterNum]);
                                            }
                                            if (collisionSuicideHunterNum[suicideHunterNum] == 4){
                                                score += 15;
                                                score_text.setText(String.valueOf(score));
                                                reproductionSuicideHunter[suicideHunterNum] = RandHunter();
                                                suicide_hunter[suicideHunterNum].setLayoutX(1700);
                                                suicide_hunter[suicideHunterNum].setLayoutY(RandHunterY());
                                                collisionSuicideHunterNum[suicideHunterNum] = 0;
                                                opacitySuicideHunter[suicideHunterNum] = 1;
                                                suicide_hunter[suicideHunterNum].setOpacity(1);
                                            }
                                            arrow[guardNum].setVisible(false);
                                            hideArrow[guardNum] = false;
                                        }

                                        //  Collision of the simple guard with suicide hunter

                                        if (simple_guard[guardNum].getLayoutY() + Y + 33 == suicide_hunter[suicideHunterNum].getLayoutY() && (simple_guard[guardNum].getLayoutX() + X + 60 <= suicide_hunter[suicideHunterNum].getLayoutX() && simple_guard[guardNum].getLayoutX() + X + 110 >= suicide_hunter[suicideHunterNum].getLayoutX())){

                                            //  Remove simple guard , maine , knight guard and mother guard around

                                            for (anchorPaneNum = 0 ; anchorPaneNum < 36 ; anchorPaneNum++){
                                                if ((anchor_pane[anchorPaneNum].getLayoutY() - 200 + 185 <= suicide_hunter[suicideHunterNum].getLayoutY() && anchor_pane[anchorPaneNum].getLayoutY() + 200 + 185 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (anchor_pane[anchorPaneNum].getLayoutX() - 200 + 161 <= suicide_hunter[suicideHunterNum].getLayoutX() && anchor_pane[anchorPaneNum].getLayoutX() + 200 + 161 >= suicide_hunter[suicideHunterNum].getLayoutX())){
                                                    selectSimpleGuard[anchorPaneNum] = false;
                                                    simple_guard[anchorPaneNum].setOpacity(1);
                                                    arrow[anchorPaneNum].setLayoutX(77);
                                                    simple_guard[anchorPaneNum].setVisible(false);
                                                    opacitySimpleGuard[anchorPaneNum] = 1;
                                                    arrow[anchorPaneNum].setVisible(false);
                                                    selectMaine[anchorPaneNum] = false;
                                                    Maine[anchorPaneNum].setVisible(false);
                                                    selectKnightGuard[anchorPaneNum] = false;
                                                    knight_guard[anchorPaneNum].setOpacity(1);
                                                    knight_arrow[anchorPaneNum].setLayoutX(77);
                                                    knight_guard[anchorPaneNum].setVisible(false);
                                                    opacityKnightGuard[anchorPaneNum] = 1;
                                                    knight_arrow[anchorPaneNum].setVisible(false);
                                                    selectMotherGuard[anchorPaneNum] = false;
                                                    mother_guard[anchorPaneNum].setOpacity(1);
                                                    mother_guard[anchorPaneNum].setVisible(false);
                                                    opacityMotherGuard[anchorPaneNum] = 1;
                                                    reproductionMoneyPocketGuard[anchorPaneNum] = 0;
                                                }
                                            }

                                            //  Remove normal hunter around

                                            for (normalHunterNum = 0 ; normalHunterNum < 12 ; normalHunterNum++){
                                                if ((normal_hunter[normalHunterNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && normal_hunter[normalHunterNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (normal_hunter[normalHunterNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && normal_hunter[normalHunterNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())){
                                                    reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                    normal_hunter[normalHunterNum].setLayoutX(1700);
                                                    normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                    normal_hunter[normalHunterNum].setOpacity(1);
                                                    opacityNormalHunter[normalHunterNum] = 1;
                                                }
                                            }

                                            //  Remove suicide hunter

                                            for (suicideHunterAroundNum = 0 ; suicideHunterAroundNum < 3 ; suicideHunterAroundNum++){
                                                if ((suicide_hunter[suicideHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && suicide_hunter[suicideHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (suicide_hunter[suicideHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && suicide_hunter[suicideHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())){
                                                    reproductionSuicideHunter[suicideHunterAroundNum] = RandHunter();
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutX(1700);
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutY(RandHunterY());
                                                    suicide_hunter[suicideHunterAroundNum].setOpacity(1);
                                                    opacitySuicideHunter[suicideHunterAroundNum] = 1;
                                                }
                                            }

                                            //  Remove knight hunter

                                            for (knightHunterAroundNum = 0 ; knightHunterAroundNum < 3 ; knightHunterAroundNum++){
                                                if ((knight_hunter[knightHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && knight_hunter[knightHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (knight_hunter[knightHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_hunter[knightHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())){
                                                    reproductionKnightHunter[knightHunterAroundNum] = RandHunter();
                                                    knight_hunter[knightHunterAroundNum].setLayoutX(1700);
                                                    knight_hunter[knightHunterAroundNum].setLayoutY(RandHunterY());
                                                    knight_hunter[knightHunterAroundNum].setOpacity(1);
                                                    opacityKnightHunter[knightHunterAroundNum] = 1;
                                                    opacityKnightHunterArmor[knightHunterNum] = 1;
                                                    knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                                }
                                            }
                                        }
                                    }

                                    //  Knight Hunter section in the simple guard

                                    for (knightHunterNum = 0 ; knightHunterNum < 3 ; knightHunterNum++) {

                                        //  Collision of the simple guard arrow with knight hunter

                                        if (arrow[guardNum].getLayoutY() + Y + 3 == knight_hunter[knightHunterNum].getLayoutY() && (arrow[guardNum].getLayoutX() + X <= knight_hunter[knightHunterNum].getLayoutX() && arrow[guardNum].getLayoutX() + X + 50 >= knight_hunter[knightHunterNum].getLayoutX()) && hideArrow[guardNum] == true && arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionKnightHunterNum[knightHunterNum]++;
                                            if (collisionKnightHunterNum[knightHunterNum] <= 4){
                                                opacityKnightHunterArmor[knightHunterNum] -= 0.2;
                                                if (opacityKnightHunterArmor[knightHunterNum] > 0){
                                                    knight_hunter[knightHunterNum].setOpacity(opacityKnightHunterArmor[knightHunterNum]);
                                                }
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] == 5){
                                                knight_hunter[knightHunterNum].setOpacity(opacityKnightHunter[knightHunterNum]);
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#e2ff1f"));
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] >= 6){
                                                opacityKnightHunter[knightHunterNum] -= 0.1;
                                                if (opacityKnightHunter[knightHunterNum] > 0){
                                                    knight_hunter[knightHunterNum].setOpacity(opacityKnightHunter[knightHunterNum]);
                                                }
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] == 15){
                                                score += 25;
                                                score_text.setText(String.valueOf(score));
                                                reproductionKnightHunter[knightHunterNum] = RandHunter();
                                                knight_hunter[knightHunterNum].setLayoutX(1700);
                                                knight_hunter[knightHunterNum].setLayoutY(RandHunterY());
                                                collisionKnightHunterNum[knightHunterNum] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                opacityKnightHunter[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setOpacity(1);
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            arrow[guardNum].setVisible(false);
                                            hideArrow[guardNum] = false;
                                        }

                                        //  Collision of the simple guard with knight hunter

                                        if (simple_guard[guardNum].getLayoutY() + Y + 33 == knight_hunter[knightHunterNum].getLayoutY() && (simple_guard[guardNum].getLayoutX() + X + 60 <= knight_hunter[knightHunterNum].getLayoutX() && simple_guard[guardNum].getLayoutX() + X + 110 >= knight_hunter[knightHunterNum].getLayoutX())){
                                            if (opacitySimpleGuard[guardNum] >= 0){
                                                knight_hunter[knightHunterNum].setLayoutX(knight_hunter[knightHunterNum].getLayoutX() + 2);
                                                opacitySimpleGuard[guardNum] -= destruction;
                                                simple_guard[guardNum].setOpacity(opacitySimpleGuard[guardNum]);
                                            }
                                            else {
                                                selectSimpleGuard[guardNum] = false;
                                                simple_guard[guardNum].setOpacity(1);
                                                arrow[guardNum].setLayoutX(77);
                                                simple_guard[guardNum].setVisible(false);
                                                opacitySimpleGuard[guardNum] = 1;
                                            }
                                        }
                                    }
                                }

                                //  Maine section

                                if (selectMaine[guardNum] == true){
                                    Maine[guardNum].setVisible(true);

                                    //  Normal Hunter , suicide hunter and knight hunter section in the Maine

                                    for (normalHunterNum = 0 ; normalHunterNum < 12 ; normalHunterNum++){
                                        for (suicideHunterNum = 0 ; suicideHunterNum < 3 ; suicideHunterNum++){
                                            for (knightHunterNum = 0 ; knightHunterNum < 3 ; knightHunterNum++){

                                                //  Collision of the maine with normal hunter , suicide hunter and knight hunter

                                                if (Maine[guardNum].getLayoutY() + Y + 33 == normal_hunter[normalHunterNum].getLayoutY() && (Maine[guardNum].getLayoutX() + X + 60 <= normal_hunter[normalHunterNum].getLayoutX() && Maine[guardNum].getLayoutX() + X + 110 >= normal_hunter[normalHunterNum].getLayoutX()) || Maine[guardNum].getLayoutY() + Y + 33 == suicide_hunter[suicideHunterNum].getLayoutY() && (Maine[guardNum].getLayoutX() + X + 60 <= suicide_hunter[suicideHunterNum].getLayoutX() && Maine[guardNum].getLayoutX() + X + 110 >= suicide_hunter[suicideHunterNum].getLayoutX()) || Maine[guardNum].getLayoutY() + Y + 33 == knight_hunter[knightHunterNum].getLayoutY() && (Maine[guardNum].getLayoutX() + X + 60 <= knight_hunter[knightHunterNum].getLayoutX() && Maine[guardNum].getLayoutX() + X + 110 >= knight_hunter[knightHunterNum].getLayoutX())){

                                                    //  Remove simple guard , maine , knight guard and mother guard around

                                                    for (anchorPaneNum = 0 ; anchorPaneNum < 36 ; anchorPaneNum++){
                                                        if ((anchor_pane[anchorPaneNum].getLayoutY() - 200 + 152 - Y  <= Maine[guardNum].getLayoutY() && anchor_pane[anchorPaneNum].getLayoutY() + 200 + 152 - Y >= Maine[guardNum].getLayoutY()) && (anchor_pane[anchorPaneNum].getLayoutX() - 200 + 51 - X <= Maine[guardNum].getLayoutX() && anchor_pane[anchorPaneNum].getLayoutX() + 200 + 51 - X >= Maine[guardNum].getLayoutX())){
                                                            selectSimpleGuard[anchorPaneNum] = false;
                                                            simple_guard[anchorPaneNum].setOpacity(1);
                                                            arrow[anchorPaneNum].setLayoutX(77);
                                                            simple_guard[anchorPaneNum].setVisible(false);
                                                            opacitySimpleGuard[anchorPaneNum] = 1;
                                                            arrow[anchorPaneNum].setVisible(false);
                                                            selectMaine[anchorPaneNum] = false;
                                                            Maine[anchorPaneNum].setVisible(false);
                                                            selectKnightGuard[anchorPaneNum] = false;
                                                            knight_guard[anchorPaneNum].setOpacity(1);
                                                            knight_arrow[anchorPaneNum].setLayoutX(77);
                                                            knight_guard[anchorPaneNum].setVisible(false);
                                                            opacityKnightGuard[anchorPaneNum] = 1;
                                                            knight_arrow[anchorPaneNum].setVisible(false);
                                                            selectMotherGuard[anchorPaneNum] = false;
                                                            mother_guard[anchorPaneNum].setOpacity(1);
                                                            mother_guard[anchorPaneNum].setVisible(false);
                                                            opacityMotherGuard[anchorPaneNum] = 1;
                                                            reproductionMoneyPocketGuard[anchorPaneNum] = 0;
                                                        }
                                                    }

                                                    //  Remove normal hunter around

                                                    for (normalHunterAroundNum = 0 ; normalHunterAroundNum < 12 ; normalHunterAroundNum++){
                                                        if ((normal_hunter[normalHunterAroundNum].getLayoutY() - 200 - Y - 33 <= Maine[guardNum].getLayoutY() && normal_hunter[normalHunterAroundNum].getLayoutY() + 200 - Y - 33 >= Maine[guardNum].getLayoutY()) && (normal_hunter[normalHunterAroundNum].getLayoutX() - 200 - X - 110 <= Maine[guardNum].getLayoutX() && normal_hunter[normalHunterAroundNum].getLayoutX() + 200 - X - 110 >= Maine[guardNum].getLayoutX())){
                                                            score += 5;
                                                            score_text.setText(String.valueOf(score));
                                                            reproductionNormalHunter[normalHunterAroundNum] = RandHunter();
                                                            normal_hunter[normalHunterAroundNum].setLayoutX(1700);
                                                            normal_hunter[normalHunterAroundNum].setLayoutY(RandHunterY());
                                                            normal_hunter[normalHunterAroundNum].setOpacity(1);
                                                            opacityNormalHunter[normalHunterAroundNum] = 1;
                                                        }
                                                    }

                                                    //  Remove suicide hunter around

                                                    for (suicideHunterAroundNum = 0 ; suicideHunterAroundNum < 3 ; suicideHunterAroundNum++){
                                                        if ((suicide_hunter[suicideHunterAroundNum].getLayoutY() - 200 - Y - 33 <= Maine[guardNum].getLayoutY() && suicide_hunter[suicideHunterAroundNum].getLayoutY() + 200 - Y - 33 >= Maine[guardNum].getLayoutY()) && (suicide_hunter[suicideHunterAroundNum].getLayoutX() - 200 - X - 110 <= Maine[guardNum].getLayoutX() && suicide_hunter[suicideHunterAroundNum].getLayoutX() + 200 - X - 110 >= Maine[guardNum].getLayoutX())){
                                                            score += 15;
                                                            score_text.setText(String.valueOf(score));
                                                            reproductionSuicideHunter[suicideHunterAroundNum] = RandHunter();
                                                            suicide_hunter[suicideHunterAroundNum].setLayoutX(1700);
                                                            suicide_hunter[suicideHunterAroundNum].setLayoutY(RandHunterY());
                                                            suicide_hunter[suicideHunterAroundNum].setOpacity(1);
                                                            opacitySuicideHunter[suicideHunterAroundNum] = 1;
                                                        }
                                                    }

                                                    //  Remove knight hunter around

                                                    for (knightHunterAroundNum = 0 ; knightHunterAroundNum < 3 ; knightHunterAroundNum++){
                                                        if ((knight_hunter[knightHunterAroundNum].getLayoutY() - 200 - Y - 33 <= Maine[guardNum].getLayoutY() && knight_hunter[knightHunterAroundNum].getLayoutY() + 200 - Y - 33 >= Maine[guardNum].getLayoutY()) && (knight_hunter[knightHunterAroundNum].getLayoutX() - 200 - X - 110 <= Maine[guardNum].getLayoutX() && knight_hunter[knightHunterAroundNum].getLayoutX() + 200 - X - 110 >= Maine[guardNum].getLayoutX())){
                                                            score += 25;
                                                            score_text.setText(String.valueOf(score));
                                                            reproductionKnightHunter[knightHunterAroundNum] = RandHunter();
                                                            knight_hunter[knightHunterAroundNum].setLayoutX(1700);
                                                            knight_hunter[knightHunterAroundNum].setLayoutY(RandHunterY());
                                                            knight_hunter[knightHunterAroundNum].setOpacity(1);
                                                            opacityKnightHunter[knightHunterAroundNum] = 1;
                                                            opacityKnightHunterArmor[knightHunterAroundNum] = 1;
                                                            knight_hunter[knightHunterAroundNum].setFill(Paint.valueOf("#f27913"));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                //  Knight guard section

                                if (selectKnightGuard[guardNum] == true) {
                                    knight_guard[guardNum].setVisible(true);
                                    if (visibleKnightArrow[guardNum] == true){
                                        knight_arrow[guardNum].setVisible(true);
                                        visibleKnightArrow[guardNum] = false;
                                    }

                                    //  Arrow move

                                    knight_arrow[guardNum].setLayoutX(knight_arrow[guardNum].getLayoutX() + 10);


                                    //  Shoot again

                                    shootAgainKnightArrow[guardNum]++;
                                    if (shootAgainKnightArrow[guardNum] == 130){
                                        knight_arrow[guardNum].setVisible(true);
                                        shootAgainKnightArrow[guardNum] = 0;
                                        knight_arrow[guardNum].setLayoutX(77);
                                        hideKnightArrow[guardNum] = true;
                                    }

                                    //  Normal Hunter section in the Knight guard

                                    for (normalHunterNum = 0 ; normalHunterNum < 12 ; normalHunterNum++) {

                                        //  Collision of the knight guard arrow with normal hunter

                                        if (knight_arrow[guardNum].getLayoutY() + Y + 3 == normal_hunter[normalHunterNum].getLayoutY() && (knight_arrow[guardNum].getLayoutX() + X <= normal_hunter[normalHunterNum].getLayoutX() && knight_arrow[guardNum].getLayoutX() + X + 50 >= normal_hunter[normalHunterNum].getLayoutX()) && hideKnightArrow[guardNum] == true && knight_arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionNormalHunterNum[normalHunterNum]++;
                                            opacityNormalHunter[normalHunterNum] -= 0.1;
                                            if (opacityNormalHunter[normalHunterNum] > 0){
                                                normal_hunter[normalHunterNum].setOpacity(opacityNormalHunter[normalHunterNum]);
                                            }
                                            if (collisionNormalHunterNum[normalHunterNum] == 10){
                                                score += 5;
                                                score_text.setText(String.valueOf(score));
                                                reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                normal_hunter[normalHunterNum].setLayoutX(1700);
                                                normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                collisionNormalHunterNum[normalHunterNum] = 0;
                                                opacityNormalHunter[normalHunterNum] = 1;
                                                normal_hunter[normalHunterNum].setOpacity(1);
                                            }
                                            knight_arrow[guardNum].setVisible(false);
                                            hideKnightArrow[guardNum] = false;
                                        }

                                        //  Collision of the knight guard with normal hunter

                                        if (knight_guard[guardNum].getLayoutY() + Y + 33 == normal_hunter[normalHunterNum].getLayoutY() && (knight_guard[guardNum].getLayoutX() + X + 60 <= normal_hunter[normalHunterNum].getLayoutX() && knight_guard[guardNum].getLayoutX() + X + 110 >= normal_hunter[normalHunterNum].getLayoutX())){
                                            if (opacityKnightGuard[guardNum] >= 0){
                                                normal_hunter[normalHunterNum].setLayoutX(normal_hunter[normalHunterNum].getLayoutX() + 2);
                                                opacityKnightGuard[guardNum] -= destruction;
                                                knight_guard[guardNum].setOpacity(opacityKnightGuard[guardNum]);
                                            }
                                            else {
                                                selectKnightGuard[guardNum] = false;
                                                knight_guard[guardNum].setOpacity(1);
                                                knight_arrow[guardNum].setLayoutX(77);
                                                knight_guard[guardNum].setVisible(false);
                                                opacityKnightGuard[guardNum] = 1;
                                            }
                                        }
                                    }

                                    //  Suicide Hunter section in the Knight guard

                                    for (suicideHunterNum = 0 ; suicideHunterNum < 3 ; suicideHunterNum++) {

                                        //  Collision of the knight guard arrow with suicide hunter

                                        if (knight_arrow[guardNum].getLayoutY() + Y + 3 == suicide_hunter[suicideHunterNum].getLayoutY() && (knight_arrow[guardNum].getLayoutX() + X <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_arrow[guardNum].getLayoutX() + X + 50 >= suicide_hunter[suicideHunterNum].getLayoutX()) && hideKnightArrow[guardNum] == true && knight_arrow[guardNum].getLayoutX() <= arrowEffectRange) {
                                            collisionSuicideHunterNum[suicideHunterNum]++;
                                            opacitySuicideHunter[suicideHunterNum] -= 0.25;
                                            if (opacitySuicideHunter[suicideHunterNum] > 0) {
                                                suicide_hunter[suicideHunterNum].setOpacity(opacitySuicideHunter[suicideHunterNum]);
                                            }
                                            if (collisionSuicideHunterNum[suicideHunterNum] == 4) {
                                                score += 15;
                                                score_text.setText(String.valueOf(score));
                                                reproductionSuicideHunter[suicideHunterNum] = RandHunter();
                                                suicide_hunter[suicideHunterNum].setLayoutX(1700);
                                                suicide_hunter[suicideHunterNum].setLayoutY(RandHunterY());
                                                collisionSuicideHunterNum[suicideHunterNum] = 0;
                                                opacitySuicideHunter[suicideHunterNum] = 1;
                                                suicide_hunter[suicideHunterNum].setOpacity(1);
                                            }
                                            knight_arrow[guardNum].setVisible(false);
                                            hideKnightArrow[guardNum] = false;
                                        }

                                        //  Collision of the knight guard with suicide hunter

                                        if (knight_guard[guardNum].getLayoutY() + Y + 33 == suicide_hunter[suicideHunterNum].getLayoutY() && (knight_guard[guardNum].getLayoutX() + X + 60 <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_guard[guardNum].getLayoutX() + X + 110 >= suicide_hunter[suicideHunterNum].getLayoutX())) {

                                            //  Remove simple guard , maine , knight guard and mother guard around

                                            for (anchorPaneNum = 0; anchorPaneNum < 36; anchorPaneNum++) {
                                                if ((anchor_pane[anchorPaneNum].getLayoutY() - 200 + 185 <= suicide_hunter[suicideHunterNum].getLayoutY() && anchor_pane[anchorPaneNum].getLayoutY() + 200 + 185 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (anchor_pane[anchorPaneNum].getLayoutX() - 200 + 161 <= suicide_hunter[suicideHunterNum].getLayoutX() && anchor_pane[anchorPaneNum].getLayoutX() + 200 + 161 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    selectSimpleGuard[anchorPaneNum] = false;
                                                    simple_guard[anchorPaneNum].setOpacity(1);
                                                    arrow[anchorPaneNum].setLayoutX(77);
                                                    simple_guard[anchorPaneNum].setVisible(false);
                                                    opacitySimpleGuard[anchorPaneNum] = 1;
                                                    arrow[anchorPaneNum].setVisible(false);
                                                    selectMaine[anchorPaneNum] = false;
                                                    Maine[anchorPaneNum].setVisible(false);
                                                    selectKnightGuard[anchorPaneNum] = false;
                                                    knight_guard[anchorPaneNum].setOpacity(1);
                                                    knight_arrow[anchorPaneNum].setLayoutX(77);
                                                    knight_guard[anchorPaneNum].setVisible(false);
                                                    opacityKnightGuard[anchorPaneNum] = 1;
                                                    knight_arrow[anchorPaneNum].setVisible(false);
                                                    selectMotherGuard[anchorPaneNum] = false;
                                                    mother_guard[anchorPaneNum].setOpacity(1);
                                                    mother_guard[anchorPaneNum].setVisible(false);
                                                    opacityMotherGuard[anchorPaneNum] = 1;
                                                    reproductionMoneyPocketGuard[anchorPaneNum] = 0;
                                                }
                                            }

                                            //  Remove normal hunter around

                                            for (normalHunterNum = 0; normalHunterNum < 12; normalHunterNum++) {
                                                if ((normal_hunter[normalHunterNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && normal_hunter[normalHunterNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (normal_hunter[normalHunterNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && normal_hunter[normalHunterNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                    normal_hunter[normalHunterNum].setLayoutX(1700);
                                                    normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                    normal_hunter[normalHunterNum].setOpacity(1);
                                                    opacityNormalHunter[normalHunterNum] = 1;
                                                }
                                            }

                                            //  Remove suicide hunter around

                                            for (suicideHunterAroundNum = 0; suicideHunterAroundNum < 3; suicideHunterAroundNum++) {
                                                if ((suicide_hunter[suicideHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && suicide_hunter[suicideHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (suicide_hunter[suicideHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && suicide_hunter[suicideHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionSuicideHunter[suicideHunterAroundNum] = RandHunter();
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutX(1700);
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutY(RandHunterY());
                                                    suicide_hunter[suicideHunterAroundNum].setOpacity(1);
                                                    opacitySuicideHunter[suicideHunterAroundNum] = 1;
                                                }
                                            }

                                            //  Remove knight hunter around

                                            for (knightHunterAroundNum = 0; knightHunterAroundNum < 3; knightHunterAroundNum++) {
                                                if ((knight_hunter[knightHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && knight_hunter[knightHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (knight_hunter[knightHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_hunter[knightHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionKnightHunter[knightHunterAroundNum] = RandHunter();
                                                    knight_hunter[knightHunterAroundNum].setLayoutX(1700);
                                                    knight_hunter[knightHunterAroundNum].setLayoutY(RandHunterY());
                                                    knight_hunter[knightHunterAroundNum].setOpacity(1);
                                                    opacityKnightHunter[knightHunterAroundNum] = 1;
                                                    opacityKnightHunterArmor[knightHunterNum] = 1;
                                                    knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                                }
                                            }
                                        }
                                    }
                                    //  Knight Hunter section in the Knight guard

                                    for (knightHunterNum = 0 ; knightHunterNum < 3 ; knightHunterNum++) {

                                        //  Collision of the knight guard arrow with knight hunter

                                        if (knight_arrow[guardNum].getLayoutY() + Y + 3 == knight_hunter[knightHunterNum].getLayoutY() && (knight_arrow[guardNum].getLayoutX() + X <= knight_hunter[knightHunterNum].getLayoutX() && knight_arrow[guardNum].getLayoutX() + X + 50 >= knight_hunter[knightHunterNum].getLayoutX()) && hideKnightArrow[guardNum] == true && knight_arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionKnightHunterNum[knightHunterNum]++;
                                            if (collisionKnightHunterNum[knightHunterNum] <= 4){
                                                opacityKnightHunterArmor[knightHunterNum] -= 0.2;
                                                if (opacityKnightHunterArmor[knightHunterNum] > 0){
                                                    knight_hunter[knightHunterNum].setOpacity(opacityKnightHunterArmor[knightHunterNum]);
                                                }
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] == 5){
                                                knight_hunter[knightHunterNum].setOpacity(opacityKnightHunter[knightHunterNum]);
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#e2ff1f"));
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] >= 6){
                                                opacityKnightHunter[knightHunterNum] -= 0.1;
                                                if (opacityKnightHunter[knightHunterNum] > 0){
                                                    knight_hunter[knightHunterNum].setOpacity(opacityKnightHunter[knightHunterNum]);
                                                }
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] == 15){
                                                score += 25;
                                                score_text.setText(String.valueOf(score));
                                                reproductionKnightHunter[knightHunterNum] = RandHunter();
                                                knight_hunter[knightHunterNum].setLayoutX(1700);
                                                knight_hunter[knightHunterNum].setLayoutY(RandHunterY());
                                                collisionKnightHunterNum[knightHunterNum] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                opacityKnightHunter[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setOpacity(1);
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            knight_arrow[guardNum].setVisible(false);
                                            hideKnightArrow[guardNum] = false;
                                        }

                                        //  Collision of the knight guard with knight hunter

                                        if (knight_guard[guardNum].getLayoutY() + Y + 33 == knight_hunter[knightHunterNum].getLayoutY() && (knight_guard[guardNum].getLayoutX() + X + 60 <= knight_hunter[knightHunterNum].getLayoutX() && knight_guard[guardNum].getLayoutX() + X + 110 >= knight_hunter[knightHunterNum].getLayoutX())){
                                            if (opacityKnightGuard[guardNum] >= 0){
                                                knight_hunter[knightHunterNum].setLayoutX(knight_hunter[knightHunterNum].getLayoutX() + 2);
                                                opacityKnightGuard[guardNum] -= destruction;
                                                knight_guard[guardNum].setOpacity(opacityKnightGuard[guardNum]);
                                            }
                                            else {
                                                selectKnightGuard[guardNum] = false;
                                                knight_guard[guardNum].setOpacity(1);
                                                knight_arrow[guardNum].setLayoutX(77);
                                                knight_guard[guardNum].setVisible(false);
                                                opacityKnightGuard[guardNum] = 1;
                                            }
                                        }
                                    }
                                }

                                //  Mother guard section

                                if (selectMotherGuard[guardNum] == true) {
                                    mother_guard[guardNum].setVisible(true);
                                    reproductionMoneyPocketGuard[guardNum]++;
                                    if (reproductionMoneyPocketGuard[guardNum] == 1200){
                                        money_pocket_guard[guardNum].setVisible(true);
                                        reproductionMoneyPocketGuard[guardNum] = 0;
                                    }

                                    //  Normal Hunter section in the Mother guard

                                    for (normalHunterNum = 0 ; normalHunterNum < 12 ; normalHunterNum++) {

                                        //  Collision of the mother guard with normal hunter

                                        if (mother_guard[guardNum].getLayoutY() + Y + 33 == normal_hunter[normalHunterNum].getLayoutY() && (mother_guard[guardNum].getLayoutX() + X + 60 <= normal_hunter[normalHunterNum].getLayoutX() && mother_guard[guardNum].getLayoutX() + X + 110 >= normal_hunter[normalHunterNum].getLayoutX())){
                                            if (opacityMotherGuard[guardNum] >= 0){
                                                normal_hunter[normalHunterNum].setLayoutX(normal_hunter[normalHunterNum].getLayoutX() + 2);
                                                opacityMotherGuard[guardNum] -= destruction;
                                                mother_guard[guardNum].setOpacity(opacityMotherGuard[guardNum]);
                                            }
                                            else {
                                                selectMotherGuard[guardNum] = false;
                                                mother_guard[guardNum].setOpacity(1);
                                                mother_guard[guardNum].setVisible(false);
                                                opacityMotherGuard[guardNum] = 1;
                                            }
                                        }
                                    }

                                    //  Suicide Hunter section in the mother guard

                                    for (suicideHunterNum = 0 ; suicideHunterNum < 3 ; suicideHunterNum++) {

                                        //  Collision of the mother guard with suicide hunter

                                        if (mother_guard[guardNum].getLayoutY() + Y + 33 == suicide_hunter[suicideHunterNum].getLayoutY() && (mother_guard[guardNum].getLayoutX() + X + 60 <= suicide_hunter[suicideHunterNum].getLayoutX() && mother_guard[guardNum].getLayoutX() + X + 110 >= suicide_hunter[suicideHunterNum].getLayoutX())) {

                                            //  Remove simple guard , maine , knight guard and mother guard around

                                            for (anchorPaneNum = 0; anchorPaneNum < 36; anchorPaneNum++) {
                                                if ((anchor_pane[anchorPaneNum].getLayoutY() - 200 + 185 <= suicide_hunter[suicideHunterNum].getLayoutY() && anchor_pane[anchorPaneNum].getLayoutY() + 200 + 185 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (anchor_pane[anchorPaneNum].getLayoutX() - 200 + 161 <= suicide_hunter[suicideHunterNum].getLayoutX() && anchor_pane[anchorPaneNum].getLayoutX() + 200 + 161 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    selectSimpleGuard[anchorPaneNum] = false;
                                                    simple_guard[anchorPaneNum].setOpacity(1);
                                                    arrow[anchorPaneNum].setLayoutX(77);
                                                    simple_guard[anchorPaneNum].setVisible(false);
                                                    opacitySimpleGuard[anchorPaneNum] = 1;
                                                    arrow[anchorPaneNum].setVisible(false);
                                                    selectMaine[anchorPaneNum] = false;
                                                    Maine[anchorPaneNum].setVisible(false);
                                                    selectKnightGuard[anchorPaneNum] = false;
                                                    knight_guard[anchorPaneNum].setOpacity(1);
                                                    knight_arrow[anchorPaneNum].setLayoutX(77);
                                                    knight_guard[anchorPaneNum].setVisible(false);
                                                    opacityKnightGuard[anchorPaneNum] = 1;
                                                    knight_arrow[anchorPaneNum].setVisible(false);
                                                    selectMotherGuard[anchorPaneNum] = false;
                                                    mother_guard[anchorPaneNum].setOpacity(1);
                                                    mother_guard[anchorPaneNum].setVisible(false);
                                                    opacityMotherGuard[anchorPaneNum] = 1;
                                                    reproductionMoneyPocketGuard[anchorPaneNum] = 0;
                                                }
                                            }

                                            //  Remove normal hunter around

                                            for (normalHunterNum = 0; normalHunterNum < 12; normalHunterNum++) {
                                                if ((normal_hunter[normalHunterNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && normal_hunter[normalHunterNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (normal_hunter[normalHunterNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && normal_hunter[normalHunterNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                    normal_hunter[normalHunterNum].setLayoutX(1700);
                                                    normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                    normal_hunter[normalHunterNum].setOpacity(1);
                                                    opacityNormalHunter[normalHunterNum] = 1;
                                                }
                                            }
                                            //  Remove suicide hunter around

                                            for (suicideHunterAroundNum = 0; suicideHunterAroundNum < 3; suicideHunterAroundNum++) {
                                                if ((suicide_hunter[suicideHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && suicide_hunter[suicideHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (suicide_hunter[suicideHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && suicide_hunter[suicideHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionSuicideHunter[suicideHunterAroundNum] = RandHunter();
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutX(1700);
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutY(RandHunterY());
                                                    suicide_hunter[suicideHunterAroundNum].setOpacity(1);
                                                    opacitySuicideHunter[suicideHunterAroundNum] = 1;
                                                }
                                            }

                                            //  Remove knight hunter around

                                            for (knightHunterAroundNum = 0; knightHunterAroundNum < 3; knightHunterAroundNum++) {
                                                if ((knight_hunter[knightHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && knight_hunter[knightHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (knight_hunter[knightHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_hunter[knightHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionKnightHunter[knightHunterAroundNum] = RandHunter();
                                                    knight_hunter[knightHunterAroundNum].setLayoutX(1700);
                                                    knight_hunter[knightHunterAroundNum].setLayoutY(RandHunterY());
                                                    knight_hunter[knightHunterAroundNum].setOpacity(1);
                                                    opacityKnightHunter[knightHunterAroundNum] = 1;
                                                    opacityKnightHunterArmor[knightHunterNum] = 1;
                                                    knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                                }
                                            }
                                        }
                                    }

                                    //  Knight Hunter section in the mother guard

                                    for (knightHunterNum = 0 ; knightHunterNum < 3 ; knightHunterNum++) {

                                        //  Collision of the mother guard with knight hunter

                                        if (mother_guard[guardNum].getLayoutY() + Y + 33 == knight_hunter[knightHunterNum].getLayoutY() && (mother_guard[guardNum].getLayoutX() + X + 60 <= knight_hunter[knightHunterNum].getLayoutX() && mother_guard[guardNum].getLayoutX() + X + 110 >= knight_hunter[knightHunterNum].getLayoutX())){
                                            if (opacityMotherGuard[guardNum] >= 0){
                                                knight_hunter[knightHunterNum].setLayoutX(knight_hunter[knightHunterNum].getLayoutX() + 2);
                                                opacityMotherGuard[guardNum] -= destruction;
                                                mother_guard[guardNum].setOpacity(opacityMotherGuard[guardNum]);
                                            }
                                            else {
                                                selectMotherGuard[guardNum] = false;
                                                mother_guard[guardNum].setOpacity(1);
                                                mother_guard[guardNum].setVisible(false);
                                                opacityMotherGuard[guardNum] = 1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }
        });
        thread2.start();

        Thread thread3 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    while (stop == 1) {
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    reproductionMoneyPocket++;
                    progress_bar_normal_guard.setProgress(progress_bar_normal_guard.getProgress() + 0.004);
                    progress_bar_Maine.setProgress(progress_bar_Maine.getProgress() + 0.003);
                    progress_bar_knight_guard.setProgress(progress_bar_knight_guard.getProgress() + 0.002);
                    progress_bar_mother_guard.setProgress(progress_bar_mother_guard.getProgress() + 0.004);
                    opacity = money;
                    normal_guard.setOpacity(opacity / 100);
                    progress_bar_normal_guard.setOpacity(opacity / 100);
                    maine.setOpacity(opacity / 120);
                    progress_bar_Maine.setOpacity(opacity / 120);
                    knight_guard.setOpacity(opacity / 170);
                    progress_bar_knight_guard.setOpacity(opacity / 170);
                    mother_guard.setOpacity(opacity / 60);
                    progress_bar_mother_guard.setOpacity(opacity / 60);
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {

                            // Money pocket section

                            if (reproductionMoneyPocket == 300) {
                                reproductionMoneyPocket = 0;
                                switch(RandMoneyPocket()) {
                                    case '0':
                                        money_pocket1.setVisible(true);
                                        break;
                                    case '1':
                                        money_pocket2.setVisible(true);
                                        break;
                                    case '2':
                                        money_pocket3.setVisible(true);
                                        break;
                                    case '3':
                                        money_pocket4.setVisible(true);
                                        break;
                                    case '4':
                                        money_pocket5.setVisible(true);
                                        break;
                                    case '5':
                                        money_pocket6.setVisible(true);
                                        break;
                                    case '6':
                                        money_pocket7.setVisible(true);
                                        break;
                                    case '7':
                                        money_pocket8.setVisible(true);
                                        break;
                                    case '8':
                                        money_pocket9.setVisible(true);
                                        break;
                                    case '9':
                                        money_pocket10.setVisible(true);
                                        break;
                                    case 'A':
                                        money_pocket11.setVisible(true);
                                        break;
                                    case 'B':
                                        money_pocket12.setVisible(true);
                                        break;
                                    case 'C':
                                        money_pocket13.setVisible(true);
                                        break;
                                    case 'D':
                                        money_pocket14.setVisible(true);
                                        break;
                                    case 'E':
                                        money_pocket15.setVisible(true);
                                        break;
                                    case 'F':
                                        money_pocket16.setVisible(true);
                                        break;
                                    case 'G':
                                        money_pocket17.setVisible(true);
                                        break;
                                    case 'H':
                                        money_pocket18.setVisible(true);
                                        break;
                                    case 'I':
                                        money_pocket19.setVisible(true);
                                        break;
                                    case 'J':
                                        money_pocket20.setVisible(true);
                                        break;
                                    case 'K':
                                        money_pocket21.setVisible(true);
                                        break;
                                    case 'L':
                                        money_pocket22.setVisible(true);
                                        break;
                                    case 'M':
                                        money_pocket23.setVisible(true);
                                        break;
                                    case 'N':
                                        money_pocket24.setVisible(true);
                                        break;
                                    case 'O':
                                        money_pocket25.setVisible(true);
                                        break;
                                    case 'P':
                                        money_pocket26.setVisible(true);
                                        break;
                                    case 'Q':
                                        money_pocket27.setVisible(true);
                                        break;
                                    case 'R':
                                        money_pocket28.setVisible(true);
                                        break;
                                    case 'S':
                                        money_pocket29.setVisible(true);
                                        break;
                                    case 'T':
                                        money_pocket30.setVisible(true);
                                        break;
                                    case 'U':
                                        money_pocket31.setVisible(true);
                                        break;
                                    case 'V':
                                        money_pocket32.setVisible(true);
                                        break;
                                    case 'W':
                                        money_pocket33.setVisible(true);
                                        break;
                                    case 'X':
                                        money_pocket34.setVisible(true);
                                        break;
                                    case 'Y':
                                        money_pocket35.setVisible(true);
                                        break;
                                    case 'Z':
                                        money_pocket36.setVisible(true);
                                        break;
                                }
                            }
                        }
                    });
                }
            }
        });
        thread3.start();
    }

    public void Selection(MouseEvent mouseEvent) {
        select = 1;
        select_normal_guard.setVisible(true);
        select_maine.setVisible(false);
        select_knight_guard.setVisible(false);
        select_mother_guard.setVisible(false);
    }

    public void Selection2(MouseEvent mouseEvent) {
        select = 2;
        select_normal_guard.setVisible(false);
        select_knight_guard.setVisible(false);
        select_mother_guard.setVisible(false);
        select_maine.setVisible(true);
    }

    public void Selection3(MouseEvent mouseEvent) {
        select = 3;
        select_normal_guard.setVisible(false);
        select_knight_guard.setVisible(true);
        select_mother_guard.setVisible(false);
        select_maine.setVisible(false);
    }

    public void Selection4(MouseEvent mouseEvent) {
        select = 4;
        select_normal_guard.setVisible(false);
        select_knight_guard.setVisible(false);
        select_mother_guard.setVisible(true);
        select_maine.setVisible(false);
    }

    public void Show1(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[0] == false && selectMaine[0] == false && selectKnightGuard[0] == false && selectMotherGuard[0] == false){
            selectSimpleGuard[0] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[0] == false && selectMaine[0] == false && selectKnightGuard[0] == false && selectMotherGuard[0] == false){
            selectMaine[0] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[0] == false && selectMaine[0] == false && selectKnightGuard[0] == false && selectMotherGuard[0] == false){
            selectKnightGuard[0] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[0] == false && selectMaine[0] == false && selectKnightGuard[0] == false && selectMotherGuard[0] == false){
            selectMotherGuard[0] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show2(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[1] == false && selectMaine[1] == false && selectKnightGuard[1] == false && selectMotherGuard[1] == false){
            selectSimpleGuard[1] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[1] == false && selectMaine[1] == false && selectKnightGuard[1] == false && selectMotherGuard[1] == false){
            selectMaine[1] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[1] == false && selectMaine[1] == false && selectKnightGuard[1] == false && selectMotherGuard[1] == false){
            selectKnightGuard[1] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[1] == false && selectMaine[1] == false && selectKnightGuard[1] == false && selectMotherGuard[1] == false){
            selectMotherGuard[1] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show3(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[2] == false && selectMaine[2] == false && selectKnightGuard[2] == false && selectMotherGuard[2] == false){
            selectSimpleGuard[2] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[2] == false && selectMaine[2] == false && selectKnightGuard[2] == false && selectMotherGuard[2] == false){
            selectMaine[2] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[2] == false && selectMaine[2] == false && selectKnightGuard[2] == false && selectMotherGuard[2] == false){
            selectKnightGuard[2] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[2] == false && selectMaine[2] == false && selectKnightGuard[2] == false && selectMotherGuard[2] == false){
            selectMotherGuard[2] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show4(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[3] == false && selectMaine[3] == false && selectKnightGuard[3] == false && selectMotherGuard[3] == false){
            selectSimpleGuard[3] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[3] == false && selectMaine[3] == false && selectKnightGuard[3] == false && selectMotherGuard[3] == false){
            selectMaine[3] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[3] == false && selectMaine[3] == false && selectKnightGuard[3] == false && selectMotherGuard[3] == false){
            selectKnightGuard[3] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[3] == false && selectMaine[3] == false && selectKnightGuard[3] == false && selectMotherGuard[3] == false){
            selectMotherGuard[3] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show5(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[4] == false && selectMaine[4] == false && selectKnightGuard[4] == false && selectMotherGuard[4] == false){
            selectSimpleGuard[4] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[4] == false && selectMaine[4] == false && selectKnightGuard[4] == false && selectMotherGuard[4] == false){
            selectMaine[4] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[4] == false && selectMaine[4] == false && selectKnightGuard[4] == false && selectMotherGuard[4] == false){
            selectKnightGuard[4] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[4] == false && selectMaine[4] == false && selectKnightGuard[4] == false && selectMotherGuard[4] == false){
            selectMotherGuard[4] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show6(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[5] == false && selectMaine[5] == false && selectKnightGuard[5] == false && selectMotherGuard[5] == false){
            selectSimpleGuard[5] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[5] == false && selectMaine[5] == false && selectKnightGuard[5] == false && selectMotherGuard[5] == false){
            selectMaine[5] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[5] == false && selectMaine[5] == false && selectKnightGuard[5] == false && selectMotherGuard[5] == false){
            selectKnightGuard[5] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[5] == false && selectMaine[5] == false && selectKnightGuard[5] == false && selectMotherGuard[5] == false){
            selectMotherGuard[5] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show7(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[6] == false && selectMaine[6] == false && selectKnightGuard[6] == false && selectMotherGuard[6] == false){
            selectSimpleGuard[6] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[6] == false && selectMaine[6] == false && selectKnightGuard[6] == false && selectMotherGuard[6] == false){
            selectMaine[6] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[6] == false && selectMaine[6] == false && selectKnightGuard[6] == false && selectMotherGuard[6] == false){
            selectKnightGuard[6] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[6] == false && selectMaine[6] == false && selectKnightGuard[6] == false && selectMotherGuard[6] == false){
            selectMotherGuard[6] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show8(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[7] == false && selectMaine[7] == false && selectKnightGuard[7] == false && selectMotherGuard[7] == false){
            selectSimpleGuard[7] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[7] == false && selectMaine[7] == false && selectKnightGuard[7] == false && selectMotherGuard[7] == false){
            selectMaine[7] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[7] == false && selectMaine[7] == false && selectKnightGuard[7] == false && selectMotherGuard[7] == false){
            selectKnightGuard[7] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[7] == false && selectMaine[7] == false && selectKnightGuard[7] == false && selectMotherGuard[7] == false){
            selectMotherGuard[7] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show9(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[8] == false && selectMaine[8] == false && selectKnightGuard[8] == false && selectMotherGuard[8] == false){
            selectSimpleGuard[8] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[8] == false && selectMaine[8] == false && selectKnightGuard[8] == false && selectMotherGuard[8] == false){
            selectMaine[8] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[8] == false && selectMaine[8] == false && selectKnightGuard[8] == false && selectMotherGuard[8] == false){
            selectKnightGuard[8] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[8] == false && selectMaine[8] == false && selectKnightGuard[8] == false && selectMotherGuard[8] == false){
            selectMotherGuard[8] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show10(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[9] == false && selectMaine[9] == false && selectKnightGuard[9] == false && selectMotherGuard[9] == false){
            selectSimpleGuard[9] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[9] == false && selectMaine[9] == false && selectKnightGuard[9] == false && selectMotherGuard[9] == false){
            selectMaine[9] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[9] == false && selectMaine[9] == false && selectKnightGuard[9] == false && selectMotherGuard[9] == false){
            selectKnightGuard[9] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[9] == false && selectMaine[9] == false && selectKnightGuard[9] == false && selectMotherGuard[9] == false){
            selectMotherGuard[9] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show11(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[10] == false && selectMaine[10] == false && selectKnightGuard[10] == false && selectMotherGuard[10] == false){
            selectSimpleGuard[10] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[10] == false && selectMaine[10] == false && selectKnightGuard[10] == false && selectMotherGuard[10] == false){
            selectMaine[10] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[10] == false && selectMaine[10] == false && selectKnightGuard[10] == false && selectMotherGuard[10] == false){
            selectKnightGuard[10] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[10] == false && selectMaine[10] == false && selectKnightGuard[10] == false && selectMotherGuard[10] == false){
            selectMotherGuard[10] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show12(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[11] == false && selectMaine[11] == false && selectKnightGuard[11] == false && selectMotherGuard[11] == false){
            selectSimpleGuard[11] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[11] == false && selectMaine[11] == false && selectKnightGuard[11] == false && selectMotherGuard[11] == false){
            selectMaine[11] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[11] == false && selectMaine[11] == false && selectKnightGuard[11] == false && selectMotherGuard[11] == false){
            selectKnightGuard[11] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[11] == false && selectMaine[11] == false && selectKnightGuard[11] == false && selectMotherGuard[11] == false){
            selectMotherGuard[11] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show13(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[12] == false && selectMaine[12] == false && selectKnightGuard[12] == false && selectMotherGuard[12] == false){
            selectSimpleGuard[12] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[12] == false && selectMaine[12] == false && selectKnightGuard[12] == false && selectMotherGuard[12] == false){
            selectMaine[12] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[12] == false && selectMaine[12] == false && selectKnightGuard[12] == false && selectMotherGuard[12] == false){
            selectKnightGuard[12] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[12] == false && selectMaine[12] == false && selectKnightGuard[12] == false && selectMotherGuard[12] == false){
            selectMotherGuard[12] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show14(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[13] == false && selectMaine[13] == false && selectKnightGuard[13] == false && selectMotherGuard[13] == false){
            selectSimpleGuard[13] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[13] == false && selectMaine[13] == false && selectKnightGuard[13] == false && selectMotherGuard[13] == false){
            selectMaine[13] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[13] == false && selectMaine[13] == false && selectKnightGuard[13] == false && selectMotherGuard[13] == false){
            selectKnightGuard[13] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[13] == false && selectMaine[13] == false && selectKnightGuard[13] == false && selectMotherGuard[13] == false){
            selectMotherGuard[13] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show15(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[14] == false && selectMaine[14] == false && selectKnightGuard[14] == false && selectMotherGuard[14] == false){
            selectSimpleGuard[14] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[14] == false && selectMaine[14] == false && selectKnightGuard[14] == false && selectMotherGuard[14] == false){
            selectMaine[14] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[14] == false && selectMaine[14] == false && selectKnightGuard[14] == false && selectMotherGuard[14] == false){
            selectKnightGuard[14] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[14] == false && selectMaine[14] == false && selectKnightGuard[14] == false && selectMotherGuard[14] == false){
            selectMotherGuard[14] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show16(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[15] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectMaine[15] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectKnightGuard[15] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectMotherGuard[15] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show17(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[16] == false && selectMaine[16] == false && selectKnightGuard[16] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[16] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[16] == false && selectMaine[16] == false && selectKnightGuard[16] == false && selectMotherGuard[15] == false){
            selectMaine[16] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[16] == false && selectMaine[16] == false && selectKnightGuard[16] == false && selectMotherGuard[15] == false){
            selectKnightGuard[16] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[16] == false && selectMaine[16] == false && selectKnightGuard[16] == false && selectMotherGuard[15] == false){
            selectMotherGuard[16] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show18(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[17] == false && selectMaine[17] == false && selectKnightGuard[17] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[17] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[17] == false && selectMaine[17] == false && selectKnightGuard[17] == false && selectMotherGuard[15] == false){
            selectMaine[17] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[17] == false && selectMaine[17] == false && selectKnightGuard[17] == false && selectMotherGuard[15] == false){
            selectKnightGuard[17] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectMotherGuard[17] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show19(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[18] == false && selectMaine[18] == false && selectKnightGuard[18] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[18] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[18] == false && selectMaine[18] == false && selectKnightGuard[18] == false && selectMotherGuard[15] == false){
            selectMaine[18] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[18] == false && selectMaine[18] == false && selectKnightGuard[18] == false && selectMotherGuard[15] == false){
            selectKnightGuard[18] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[18] == false && selectMaine[18] == false && selectKnightGuard[18] == false && selectMotherGuard[15] == false){
            selectMotherGuard[18] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show20(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[19] == false && selectMaine[19] == false && selectKnightGuard[19] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[19] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[19] == false && selectMaine[19] == false && selectKnightGuard[19] == false && selectMotherGuard[15] == false){
            selectMaine[19] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[19] == false && selectMaine[19] == false && selectKnightGuard[19] == false && selectMotherGuard[15] == false){
            selectKnightGuard[19] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[19] == false && selectMaine[19] == false && selectKnightGuard[19] == false && selectMotherGuard[15] == false){
            selectMotherGuard[19] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show21(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[20] == false && selectMaine[20] == false && selectKnightGuard[20] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[20] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[20] == false && selectMaine[20] == false && selectKnightGuard[20] == false && selectMotherGuard[15] == false){
            selectMaine[20] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[20] == false && selectMaine[20] == false && selectKnightGuard[20] == false && selectMotherGuard[15] == false){
            selectKnightGuard[20] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[20] == false && selectMaine[20] == false && selectKnightGuard[20] == false && selectMotherGuard[15] == false){
            selectMotherGuard[20] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show22(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[21] == false && selectMaine[21] == false && selectKnightGuard[21] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[21] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[21] == false && selectMaine[21] == false && selectKnightGuard[21] == false && selectMotherGuard[15] == false){
            selectMaine[21] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[21] == false && selectMaine[21] == false && selectKnightGuard[21] == false && selectMotherGuard[15] == false){
            selectKnightGuard[21] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[21] == false && selectMaine[21] == false && selectKnightGuard[21] == false && selectMotherGuard[15] == false){
            selectMotherGuard[21] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show23(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[22] == false && selectMaine[22] == false && selectKnightGuard[22] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[22] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[22] == false && selectMaine[22] == false && selectKnightGuard[22] == false && selectMotherGuard[15] == false){
            selectMaine[22] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[22] == false && selectMaine[22] == false && selectKnightGuard[22] == false && selectMotherGuard[15] == false){
            selectKnightGuard[22] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[22] == false && selectMaine[22] == false && selectKnightGuard[22] == false && selectMotherGuard[15] == false){
            selectMotherGuard[22] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show24(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[23] == false && selectMaine[23] == false && selectKnightGuard[23] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[23] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[23] == false && selectMaine[23] == false && selectKnightGuard[23] == false && selectMotherGuard[15] == false){
            selectMaine[23] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[23] == false && selectMaine[23] == false && selectKnightGuard[23] == false && selectMotherGuard[15] == false){
            selectKnightGuard[23] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[23] == false && selectMaine[23] == false && selectKnightGuard[23] == false && selectMotherGuard[15] == false){
            selectMotherGuard[23] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show25(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[24] == false && selectMaine[24] == false && selectKnightGuard[24] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[24] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[24] == false && selectMaine[24] == false && selectKnightGuard[24] == false && selectMotherGuard[15] == false){
            selectMaine[24] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[24] == false && selectMaine[24] == false && selectKnightGuard[24] == false && selectMotherGuard[15] == false){
            selectKnightGuard[24] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[24] == false && selectMaine[24] == false && selectKnightGuard[24] == false && selectMotherGuard[15] == false){
            selectMotherGuard[24] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show26(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[25] == false && selectMaine[25] == false && selectKnightGuard[25] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[25] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[25] == false && selectMaine[25] == false && selectKnightGuard[25] == false && selectMotherGuard[15] == false){
            selectMaine[25] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[25] == false && selectMaine[25] == false && selectKnightGuard[25] == false && selectMotherGuard[15] == false){
            selectKnightGuard[25] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[25] == false && selectMaine[25] == false && selectKnightGuard[25] == false && selectMotherGuard[15] == false){
            selectMotherGuard[25] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }
    public void Show27(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[26] == false && selectMaine[26] == false && selectKnightGuard[26] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[26] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[26] == false && selectMaine[26] == false && selectKnightGuard[26] == false && selectMotherGuard[15] == false){
            selectMaine[26] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[26] == false && selectMaine[26] == false && selectKnightGuard[26] == false && selectMotherGuard[15] == false){
            selectKnightGuard[26] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[26] == false && selectMaine[26] == false && selectKnightGuard[26] == false && selectMotherGuard[15] == false){
            selectMotherGuard[26] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }
    public void Show28(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[27] == false && selectMaine[27] == false && selectKnightGuard[27] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[27] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[27] == false && selectMaine[27] == false && selectKnightGuard[27] == false && selectMotherGuard[15] == false){
            selectMaine[27] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[27] == false && selectMaine[27] == false && selectKnightGuard[27] == false && selectMotherGuard[15] == false){
            selectKnightGuard[27] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[27] == false && selectMaine[27] == false && selectKnightGuard[27] == false && selectMotherGuard[15] == false){
            selectMotherGuard[27] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }
    public void Show29(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[28] == false && selectMaine[28] == false && selectKnightGuard[28] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[28] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[28] == false && selectMaine[28] == false && selectKnightGuard[28] == false && selectMotherGuard[15] == false){
            selectMaine[28] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[28] == false && selectMaine[28] == false && selectKnightGuard[28] == false && selectMotherGuard[15] == false){
            selectKnightGuard[28] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[28] == false && selectMaine[28] == false && selectKnightGuard[28] == false && selectMotherGuard[15] == false){
            selectMotherGuard[28] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }
    public void Show30(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[29] == false && selectMaine[29] == false && selectKnightGuard[29] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[29] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[29] == false && selectMaine[29] == false && selectKnightGuard[29] == false && selectMotherGuard[15] == false){
            selectMaine[29] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[29] == false && selectMaine[29] == false && selectKnightGuard[29] == false && selectMotherGuard[15] == false){
            selectKnightGuard[29] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[29] == false && selectMaine[29] == false && selectKnightGuard[29] == false && selectMotherGuard[15] == false){
            selectMotherGuard[29] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }
    public void Show31(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[30] == false && selectMaine[30] == false && selectKnightGuard[30] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[30] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[30] == false && selectMaine[30] == false && selectKnightGuard[30] == false && selectMotherGuard[15] == false){
            selectMaine[30] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[30] == false && selectMaine[30] == false && selectKnightGuard[30] == false && selectMotherGuard[15] == false){
            selectKnightGuard[30] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[30] == false && selectMaine[30] == false && selectKnightGuard[30] == false && selectMotherGuard[15] == false){
            selectMotherGuard[30] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show32(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[31] == false && selectMaine[31] == false && selectKnightGuard[31] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[31] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[31] == false && selectMaine[31] == false && selectKnightGuard[31] == false && selectMotherGuard[15] == false){
            selectMaine[31] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[31] == false && selectMaine[31] == false && selectKnightGuard[31] == false && selectMotherGuard[15] == false){
            selectKnightGuard[31] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[31] == false && selectMaine[31] == false && selectKnightGuard[31] == false && selectMotherGuard[15] == false){
            selectMotherGuard[31] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show33(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[32] == false && selectMaine[32] == false && selectKnightGuard[32] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[32] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[32] == false && selectMaine[32] == false && selectKnightGuard[32] == false && selectMotherGuard[15] == false){
            selectMaine[32] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[32] == false && selectMaine[32] == false && selectKnightGuard[32] == false && selectMotherGuard[15] == false){
            selectKnightGuard[32] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[32] == false && selectMaine[32] == false && selectKnightGuard[32] == false && selectMotherGuard[15] == false){
            selectMotherGuard[32] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show34(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[33] == false && selectMaine[33] == false && selectKnightGuard[33] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[33] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[33] == false && selectMaine[33] == false && selectKnightGuard[33] == false && selectMotherGuard[15] == false){
            selectMaine[33] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[33] == false && selectMaine[33] == false && selectKnightGuard[33] == false && selectMotherGuard[15] == false){
            selectKnightGuard[33] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[33] == false && selectMaine[33] == false && selectKnightGuard[33] == false && selectMotherGuard[15] == false){
            selectMotherGuard[33] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show35(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[34] == false && selectMaine[34] == false && selectKnightGuard[34] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[34] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[34] == false && selectMaine[34] == false && selectKnightGuard[34] == false && selectMotherGuard[15] == false){
            selectMaine[34] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[34] == false && selectMaine[34] == false && selectKnightGuard[34] == false && selectMotherGuard[15] == false){
            selectKnightGuard[34] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[34] == false && selectMaine[34] == false && selectKnightGuard[34] == false && selectMotherGuard[15] == false){
            selectMotherGuard[34] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show36(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[35] == false && selectMaine[35] == false && selectKnightGuard[35] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[35] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[35] == false && selectMaine[35] == false && selectKnightGuard[35] == false && selectMotherGuard[15] == false){
            selectMaine[35] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[35] == false && selectMaine[35] == false && selectKnightGuard[35] == false && selectMotherGuard[15] == false){
            selectKnightGuard[35] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[35] == false && selectMaine[35] == false && selectKnightGuard[35] == false && selectMotherGuard[15] == false){
            selectMotherGuard[35] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void OnClickMoneyPocket1(MouseEvent mouseEvent) {
        money_pocket1.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket2(MouseEvent mouseEvent) {
        money_pocket2.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket3(MouseEvent mouseEvent) {
        money_pocket3.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket4(MouseEvent mouseEvent) {
        money_pocket4.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket5(MouseEvent mouseEvent) {
        money_pocket5.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket6(MouseEvent mouseEvent) {
        money_pocket6.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket7(MouseEvent mouseEvent) {
        money_pocket7.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket8(MouseEvent mouseEvent) {
        money_pocket8.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket9(MouseEvent mouseEvent) {
        money_pocket9.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket10(MouseEvent mouseEvent) {
        money_pocket10.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket11(MouseEvent mouseEvent) {
        money_pocket11.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket12(MouseEvent mouseEvent) {
        money_pocket12.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket13(MouseEvent mouseEvent) {
        money_pocket13.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket14(MouseEvent mouseEvent) {
        money_pocket14.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket15(MouseEvent mouseEvent) {
        money_pocket15.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket16(MouseEvent mouseEvent) {
        money_pocket16.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket17(MouseEvent mouseEvent) {
        money_pocket17.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket18(MouseEvent mouseEvent) {
        money_pocket18.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket19(MouseEvent mouseEvent) {
        money_pocket19.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket20(MouseEvent mouseEvent) {
        money_pocket20.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket21(MouseEvent mouseEvent) {
        money_pocket21.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket22(MouseEvent mouseEvent) {
        money_pocket22.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket23(MouseEvent mouseEvent) {
        money_pocket23.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket24(MouseEvent mouseEvent) {
        money_pocket24.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket25(MouseEvent mouseEvent) {
        money_pocket25.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket26(MouseEvent mouseEvent) {
        money_pocket26.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket27(MouseEvent mouseEvent) {
        money_pocket27.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket28(MouseEvent mouseEvent) {
        money_pocket28.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket29(MouseEvent mouseEvent) {
        money_pocket29.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket30(MouseEvent mouseEvent) {
        money_pocket30.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket31(MouseEvent mouseEvent) {
        money_pocket31.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket32(MouseEvent mouseEvent) {
        money_pocket32.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket33(MouseEvent mouseEvent) {
        money_pocket33.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket34(MouseEvent mouseEvent) {
        money_pocket34.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket35(MouseEvent mouseEvent) {
        money_pocket35.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket36(MouseEvent mouseEvent) {
        money_pocket36.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public static char RandMoneyPocket () {
        String num = "0123456789ABCDEFGHJKLMNOPQRSTUVWXYZ";
        Random rand = new Random();
        char n;
        n = num.charAt(rand.nextInt(num.length()));
        return n;
    }

    public static int RandHunter () {
        String num = "12345";
        Random rand = new Random();
        char n;
        n = num.charAt(rand.nextInt(num.length()));
        if (n == '1')
            return 50;

        else if (n == '2')
            return 100;

        else if (n == '3')
            return 150;

        else if (n == '4')
            return 200;

        else
            return 250;
    }

    public static int RandHunterY () {
        String num = "123456";
        Random rand = new Random();
        char n;
        n = num.charAt(rand.nextInt(num.length()));
        if (n == '1')
            return 189;

        else if (n == '2')
            return 297;

        else if (n == '3')
            return 405;

        else if (n == '4')
            return 513;

        else if (n == '5')
            return 621;

        else
            return 729;
    }

    public void OnClickPause(ActionEvent actionEvent) {
        AnchorPane[] anchor_pane = {anchor_pane1 , anchor_pane2 , anchor_pane3 , anchor_pane4 , anchor_pane5 , anchor_pane6 , anchor_pane7 , anchor_pane8 , anchor_pane9 ,
                anchor_pane10 , anchor_pane11 , anchor_pane12 , anchor_pane13 , anchor_pane14 , anchor_pane15 , anchor_pane16 , anchor_pane17 , anchor_pane18 ,
                anchor_pane19 , anchor_pane20 , anchor_pane21 , anchor_pane22 , anchor_pane23 , anchor_pane24 , anchor_pane25 , anchor_pane26 , anchor_pane27 ,
                anchor_pane28 , anchor_pane29 , anchor_pane30 , anchor_pane31 , anchor_pane32 , anchor_pane33 , anchor_pane34 , anchor_pane35 , anchor_pane36};
        stop = 1;
        normal_guard.setDisable(true);
        maine.setDisable(true);
        knight_guard.setDisable(true);
        mother_guard.setDisable(true);
        for (stopAnchorPaneNum = 0 ; stopAnchorPaneNum < 36 ; stopAnchorPaneNum++){
            anchor_pane[stopAnchorPaneNum].setDisable(true);
        }
        money_pocket1.setDisable(true);
        money_pocket2.setDisable(true);
        money_pocket3.setDisable(true);
        money_pocket4.setDisable(true);
        money_pocket5.setDisable(true);
        money_pocket6.setDisable(true);
        money_pocket7.setDisable(true);
        money_pocket8.setDisable(true);
        money_pocket9.setDisable(true);
        money_pocket10.setDisable(true);
        money_pocket11.setDisable(true);
        money_pocket12.setDisable(true);
        money_pocket13.setDisable(true);
        money_pocket14.setDisable(true);
        money_pocket15.setDisable(true);
        money_pocket16.setDisable(true);
        money_pocket17.setDisable(true);
        money_pocket18.setDisable(true);
        money_pocket19.setDisable(true);
        money_pocket20.setDisable(true);
        money_pocket21.setDisable(true);
        money_pocket22.setDisable(true);
        money_pocket23.setDisable(true);
        money_pocket24.setDisable(true);
        money_pocket25.setDisable(true);
        money_pocket26.setDisable(true);
        money_pocket27.setDisable(true);
        money_pocket28.setDisable(true);
        money_pocket29.setDisable(true);
        money_pocket30.setDisable(true);
        money_pocket31.setDisable(true);
        money_pocket32.setDisable(true);
        money_pocket33.setDisable(true);
        money_pocket34.setDisable(true);
        money_pocket35.setDisable(true);
        money_pocket36.setDisable(true);
    }

    public void OnClickStart(ActionEvent actionEvent) {
        AnchorPane[] anchor_pane = {anchor_pane1 , anchor_pane2 , anchor_pane3 , anchor_pane4 , anchor_pane5 , anchor_pane6 , anchor_pane7 , anchor_pane8 , anchor_pane9 ,
                anchor_pane10 , anchor_pane11 , anchor_pane12 , anchor_pane13 , anchor_pane14 , anchor_pane15 , anchor_pane16 , anchor_pane17 , anchor_pane18 ,
                anchor_pane19 , anchor_pane20 , anchor_pane21 , anchor_pane22 , anchor_pane23 , anchor_pane24 , anchor_pane25 , anchor_pane26 , anchor_pane27 ,
                anchor_pane28 , anchor_pane29 , anchor_pane30 , anchor_pane31 , anchor_pane32 , anchor_pane33 , anchor_pane34 , anchor_pane35 , anchor_pane36};
        stop = 0;
        normal_guard.setDisable(false);
        maine.setDisable(false);
        knight_guard.setDisable(false);
        mother_guard.setDisable(false);
        for (stopAnchorPaneNum = 0 ; stopAnchorPaneNum < 36 ; stopAnchorPaneNum++){
            anchor_pane[stopAnchorPaneNum].setDisable(false);
        }
        money_pocket1.setDisable(false);
        money_pocket2.setDisable(false);
        money_pocket3.setDisable(false);
        money_pocket4.setDisable(false);
        money_pocket5.setDisable(false);
        money_pocket6.setDisable(false);
        money_pocket7.setDisable(false);
        money_pocket8.setDisable(false);
        money_pocket9.setDisable(false);
        money_pocket10.setDisable(false);
        money_pocket11.setDisable(false);
        money_pocket12.setDisable(false);
        money_pocket13.setDisable(false);
        money_pocket14.setDisable(false);
        money_pocket15.setDisable(false);
        money_pocket16.setDisable(false);
        money_pocket17.setDisable(false);
        money_pocket18.setDisable(false);
        money_pocket19.setDisable(false);
        money_pocket20.setDisable(false);
        money_pocket21.setDisable(false);
        money_pocket22.setDisable(false);
        money_pocket23.setDisable(false);
        money_pocket24.setDisable(false);
        money_pocket25.setDisable(false);
        money_pocket26.setDisable(false);
        money_pocket27.setDisable(false);
        money_pocket28.setDisable(false);
        money_pocket29.setDisable(false);
        money_pocket30.setDisable(false);
        money_pocket31.setDisable(false);
        money_pocket32.setDisable(false);
        money_pocket33.setDisable(false);
        money_pocket34.setDisable(false);
        money_pocket35.setDisable(false);
        money_pocket36.setDisable(false);
    }

    public void darkMode(){
        darkMode = true;
        background.setStyle("-fx-background-color: #464445");
        box.setStroke(Paint.valueOf("#ffffff"));
        line.setStroke(Paint.valueOf("#ffffff"));
        money_text.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 10 ; -fx-border-radius : 10");
        start.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 30 ; -fx-border-radius : 30");
        pause.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 30 ; -fx-border-radius : 30");
        Score.setStyle("-fx-background-color : #464445 ; -fx-text-fill: #ffffff");
        score_text.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 10 ; -fx-border-radius : 10");
    }

    public void OnClickMoneyPocketGuard1(MouseEvent mouseEvent) {
        money_pocket_guard1.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard2(MouseEvent mouseEvent) {
        money_pocket_guard2.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard3(MouseEvent mouseEvent) {
        money_pocket_guard3.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard4(MouseEvent mouseEvent) {
        money_pocket_guard4.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard5(MouseEvent mouseEvent) {
        money_pocket_guard5.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard6(MouseEvent mouseEvent) {
        money_pocket_guard6.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard7(MouseEvent mouseEvent) {
        money_pocket_guard7.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard8(MouseEvent mouseEvent) {
        money_pocket_guard8.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard9(MouseEvent mouseEvent) {
        money_pocket_guard9.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard10(MouseEvent mouseEvent) {
        money_pocket_guard10.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard11(MouseEvent mouseEvent) {
        money_pocket_guard11.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard12(MouseEvent mouseEvent) {
        money_pocket_guard12.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard13(MouseEvent mouseEvent) {
        money_pocket_guard13.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard14(MouseEvent mouseEvent) {
        money_pocket_guard14.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard15(MouseEvent mouseEvent) {
        money_pocket_guard15.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard16(MouseEvent mouseEvent) {
        money_pocket_guard16.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard17(MouseEvent mouseEvent) {
        money_pocket_guard17.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard18(MouseEvent mouseEvent) {
        money_pocket_guard18.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard19(MouseEvent mouseEvent) {
        money_pocket_guard19.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard20(MouseEvent mouseEvent) {
        money_pocket_guard20.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard21(MouseEvent mouseEvent) {
        money_pocket_guard21.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard22(MouseEvent mouseEvent) {
        money_pocket_guard22.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard23(MouseEvent mouseEvent) {
        money_pocket_guard23.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard24(MouseEvent mouseEvent) {
        money_pocket_guard24.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard25(MouseEvent mouseEvent) {
        money_pocket_guard25.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard26(MouseEvent mouseEvent) {
        money_pocket_guard26.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard27(MouseEvent mouseEvent) {
        money_pocket_guard27.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard28(MouseEvent mouseEvent) {
        money_pocket_guard28.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard29(MouseEvent mouseEvent) {
        money_pocket_guard29.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard30(MouseEvent mouseEvent) {
        money_pocket_guard30.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard31(MouseEvent mouseEvent) {
        money_pocket_guard31.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard32(MouseEvent mouseEvent) {
        money_pocket_guard32.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard33(MouseEvent mouseEvent) {
        money_pocket_guard33.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard34(MouseEvent mouseEvent) {
        money_pocket_guard34.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard35(MouseEvent mouseEvent) {
        money_pocket_guard35.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard36(MouseEvent mouseEvent) {
        money_pocket_guard36.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickEnteredStart(MouseEvent mouseEvent) {
        start.setStyle("-fx-background-radius : 30 ; -fx-background-color : #E8B1F7 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickExitedStart(MouseEvent mouseEvent) {
        start.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #F2D7F9 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickPressedStart(MouseEvent mouseEvent) {
        start.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #DD84F4 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickEnteredPause(MouseEvent mouseEvent) {
        pause.setStyle("-fx-background-radius : 30 ; -fx-background-color : #E8B1F7 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickExitedPause(MouseEvent mouseEvent) {
        pause.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #F2D7F9 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickPressedPause(MouseEvent mouseEvent) {
        pause.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #DD84F4 ; -fx-border-color : black ; -fx-border-radius : 30");
    }
}
