package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class RecordsController implements Initializable {
    public ListView easy;
    public ListView normal;
    public ListView hard;
    public Button back;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            File myObj = new File("RecordEasy.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                easy.getItems().add(Integer.parseInt(myReader.nextLine()));
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            File myObj = new File("RecordNormal.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                normal.getItems().add(Integer.parseInt(myReader.nextLine()));
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            File myObj = new File("RecordHard.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                hard.getItems().add(Integer.parseInt(myReader.nextLine()));
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void OnClickBack(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
        Stage primaryStage = (Stage) back.getScene().getWindow();
        primaryStage.setTitle("GUARDS vs Hunters");
        primaryStage.setScene(new Scene(root, 1533, 797));
        primaryStage.show();
    }

    public void OnClickEnteredBack(MouseEvent mouseEvent) {
        back.setStyle("-fx-background-radius : 20 ; -fx-background-color : #E8B1F7");
    }

    public void OnClickExitedBack(MouseEvent mouseEvent) {
        back.setStyle("-fx-background-radius : 20 ; -fx-background-color :  #F2D7F9");
    }

    public void OnClickPressedBack(MouseEvent mouseEvent) {
        back.setStyle("-fx-background-radius : 20 ; -fx-background-color :  #DD84F4");
    }
}
