package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;
import java.io.IOException;

public class GameLevelController {
    public Button easy_button;
    public Button normal_button;
    public Button hard_button;
    public CheckBox dark_mode;

    public void OnClickEasy(ActionEvent actionEvent) throws IOException {
        if (dark_mode.isSelected()){
            Stage primaryStage = (Stage) easy_button.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("game_page_easy.fxml"));
            Parent root = loader.load();
            GamePageEasy gamePageEasy = loader.getController();
            gamePageEasy.darkMode();
            primaryStage.setTitle("GUARDS vs Hunters");
            primaryStage.setScene(new Scene(root, 1533, 797));
            primaryStage.show();
        }
        else {
            Parent root = FXMLLoader.load(getClass().getResource("game_page_easy.fxml"));
            Stage primaryStage = (Stage) easy_button.getScene().getWindow();
            primaryStage.setTitle("GUARDS vs Hunters");
            primaryStage.setScene(new Scene(root, 1533, 797));
            primaryStage.show();
        }
    }

    public void OnClickNormal(ActionEvent actionEvent) throws IOException {
        if (dark_mode.isSelected()){
            Stage primaryStage = (Stage) normal_button.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("game_page_normal.fxml"));
            Parent root = loader.load();
            GamePageNormal gamePageNormal = loader.getController();
            gamePageNormal.darkMode();
            primaryStage.setTitle("GUARDS vs Hunters");
            primaryStage.setScene(new Scene(root, 1533, 797));
            primaryStage.show();
        }
        else {
            Parent root = FXMLLoader.load(getClass().getResource("game_page_normal.fxml"));
            Stage primaryStage = (Stage) normal_button.getScene().getWindow();
            primaryStage.setTitle("GUARDS vs Hunters");
            primaryStage.setScene(new Scene(root, 1533, 797));
            primaryStage.show();
        }
    }

    public void OnClickHard(ActionEvent actionEvent) throws IOException {
        if (dark_mode.isSelected()){
            Stage primaryStage = (Stage) hard_button.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("game_page_hard.fxml"));
            Parent root = loader.load();
            GamePageHard gamePageHard = loader.getController();
            gamePageHard.darkMode();
            primaryStage.setTitle("GUARDS vs Hunters");
            primaryStage.setScene(new Scene(root, 1533, 797));
            primaryStage.show();
        }
        else {
            Parent root = FXMLLoader.load(getClass().getResource("game_page_hard.fxml"));
            Stage primaryStage = (Stage) hard_button.getScene().getWindow();
            primaryStage.setTitle("GUARDS vs Hunters");
            primaryStage.setScene(new Scene(root, 1533, 797));
            primaryStage.show();
        }
    }
    public void OnClickEnteredEasyButton(MouseEvent mouseEvent) {
        easy_button.setStyle("-fx-background-radius : 40 ; -fx-background-color : #E8B1F7");
    }

    public void OnClickExitedEasyButton(MouseEvent mouseEvent) {
        easy_button.setStyle("-fx-background-radius : 40 ; -fx-background-color :  #F2D7F9");
    }

    public void OnClickPressedEasyButton(MouseEvent mouseEvent) {
        easy_button.setStyle("-fx-background-radius : 40 ; -fx-background-color :  #DD84F4");
    }

    public void OnClickEnteredNormalButton(MouseEvent mouseEvent) {
        normal_button.setStyle("-fx-background-radius : 40 ; -fx-background-color : #E8B1F7");
    }

    public void OnClickExitedNormalButton(MouseEvent mouseEvent) {
        normal_button.setStyle("-fx-background-radius : 40 ; -fx-background-color :  #F2D7F9");
    }

    public void OnClickPressedNormalButton(MouseEvent mouseEvent) {
        normal_button.setStyle("-fx-background-radius : 40 ; -fx-background-color :  #DD84F4");
    }

    public void OnClickEnteredHardButton(MouseEvent mouseEvent) {
        hard_button.setStyle("-fx-background-radius : 40 ; -fx-background-color : #E8B1F7");
    }

    public void OnClickExitedHardButton(MouseEvent mouseEvent) {
        hard_button.setStyle("-fx-background-radius : 40 ; -fx-background-color :  #F2D7F9");
    }

    public void OnClickPressedHardButton(MouseEvent mouseEvent) {
        hard_button.setStyle("-fx-background-radius : 40 ; -fx-background-color :  #DD84F4");
    }
}
