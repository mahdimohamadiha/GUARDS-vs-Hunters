package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import java.io.*;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;

public class GamePageEasy implements Initializable {

    public AnchorPane background , anchor_pane1 , anchor_pane2 , anchor_pane3 , anchor_pane4 , anchor_pane5 , anchor_pane6 , anchor_pane7 , anchor_pane8 ,
            anchor_pane9 , anchor_pane10 , anchor_pane11 , anchor_pane12 , anchor_pane13 , anchor_pane14 , anchor_pane15 , anchor_pane16;

    public Rectangle simple_guard1 , simple_guard2 , simple_guard3 , simple_guard4 , simple_guard5 , simple_guard6 , simple_guard7 , simple_guard8 ,
            simple_guard9 , simple_guard10 , simple_guard11 , simple_guard12 , simple_guard13 , simple_guard14 , simple_guard15 , simple_guard16;

    public Rectangle arrow1 , arrow2 , arrow3 , arrow4 , arrow5 , arrow6 , arrow7 , arrow8 ,
            arrow9 , arrow10 , arrow11 , arrow12 , arrow13 , arrow14 , arrow15 , arrow16;

    public Rectangle Maine1 , Maine2 , Maine3 , Maine4 , Maine5 , Maine6 , Maine7 , Maine8 ,
            Maine9 , Maine10 , Maine11 , Maine12 , Maine13 , Maine14 , Maine15 , Maine16;

    public Rectangle knight_guard1 , knight_guard2 , knight_guard3 , knight_guard4 , knight_guard5 , knight_guard6 , knight_guard7 , knight_guard8 ,
            knight_guard9 , knight_guard10 , knight_guard11 , knight_guard12 , knight_guard13 , knight_guard14 , knight_guard15 , knight_guard16;

    public Rectangle knight_arrow1 , knight_arrow2 , knight_arrow3 , knight_arrow4 , knight_arrow5 , knight_arrow6 , knight_arrow7 , knight_arrow8 ,
            knight_arrow9 , knight_arrow10 , knight_arrow11 , knight_arrow12 , knight_arrow13 , knight_arrow14 , knight_arrow15 , knight_arrow16;

    public Rectangle mother_guard1 , mother_guard2 , mother_guard3 , mother_guard4 , mother_guard5 , mother_guard6 , mother_guard7 , mother_guard8 ,
            mother_guard9 , mother_guard10 , mother_guard11 , mother_guard12 , mother_guard13 , mother_guard14 , mother_guard15 , mother_guard16;

    public Polygon money_pocket_guard1 , money_pocket_guard2 , money_pocket_guard3 , money_pocket_guard4 , money_pocket_guard5 , money_pocket_guard6 ,
            money_pocket_guard7 , money_pocket_guard8 , money_pocket_guard9 , money_pocket_guard10 , money_pocket_guard11 , money_pocket_guard12 , money_pocket_guard13 ,
            money_pocket_guard14 , money_pocket_guard15 , money_pocket_guard16;

    public Polygon money_pocket1 , money_pocket2 , money_pocket3 , money_pocket4 , money_pocket5 , money_pocket6 , money_pocket7 , money_pocket8 ,
            money_pocket9 , money_pocket10 , money_pocket11 , money_pocket12 , money_pocket13 , money_pocket14 , money_pocket15 , money_pocket16;

    public Circle normal_hunter1 , normal_hunter2 , normal_hunter3 , normal_hunter4 , normal_hunter5 , normal_hunter6 , normal_hunter7 , normal_hunter8;

    public Circle suicide_hunter1 , suicide_hunter2;

    public Circle knight_hunter1;

    public Rectangle box;

    public Rectangle normal_guard , maine , knight_guard , mother_guard;

    public Rectangle select_normal_guard , select_maine , select_knight_guard , select_mother_guard;

    public Line delete_line1 , delete_line2 , delete_line3 , delete_line4 , line ,
            line1 , line2 , line3 , line4 , line5 , line6 , line7 , line8;

    public TextField money_text , score_text;

    public ProgressBar progress_bar_normal_guard , progress_bar_Maine , progress_bar_knight_guard , progress_bar_mother_guard;

    public GridPane grid_pane;

    public Button start , pause;

    public Label Score;

    int guardNum , rowCoefficient , arrowEffectRange , suicideHunter , normalHunterNum , anchorPaneNum , normalHunterAroundNum , knightHunter ,
            suicideHunterAroundNum , suicideHunterNum , normalHunter , stopAnchorPaneNum , pastScores , decelerationNum = 0 , knightHunterNum ,
            reproductionMoneyPocket = 0 , speedAndDestructionNum = 0 , deleteRowNum = 0 , select = 0 , Y , X , knightHunterAroundNum ,
            money = 60 , score = 0 , stop = 0 , speed = 100 , music = 10000;

    double destruction = 0.005 , opacity = 60;

    Boolean highScore = true , darkMode = false;

    int[] reproductionNormalHunter = {300 , 100 , -100 , -300 , -500 , -700 , -900 , -1100};
    int[] reproductionSuicideHunter = {-100 , -900};
    int[] reproductionKnightHunter = {-300};
    int[] collisionNormalHunterNum = {0 , 0 , 0 , 0 , 0 , 0 , 0 , 0};
    int[] collisionSuicideHunterNum = {0 , 0};
    int[] collisionKnightHunterNum = {0};
    int[] shootAgain = {0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0};
    int[] shootAgainKnightArrow = {0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0};
    int[] reproductionMoneyPocketGuard = {0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0};
    double[] opacityNormalHunter = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};
    double[] opacitySuicideHunter = {1 , 1};
    double[] opacityKnightHunterArmor = {1};
    double[] opacityKnightHunter = {1};
    double[] opacitySimpleGuard = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};
    double[] opacityKnightGuard = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};
    double[] opacityMotherGuard = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};
    Boolean[] selectSimpleGuard = {false ,false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false};
    Boolean[] selectMaine = {false ,false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false};
    Boolean[] selectKnightGuard = {false ,false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false};
    Boolean[] selectMotherGuard = {false ,false , false , false , false , false , false ,false , false , false , false , false , false ,false , false , false};
    Boolean[] visibleArrow = {true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true};
    Boolean[] visibleKnightArrow = {true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true};
    Boolean[] hideArrow = {true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true};
    Boolean[] hideKnightArrow = {true , true , true , true , true , true , true , true , true , true , true , true , true , true , true , true};
    Boolean[] deleteRow = {false , false , false , false};

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        progress_bar_Maine.setStyle("-fx-accent: #1dea28");
        progress_bar_knight_guard.setStyle("-fx-accent: #541ee8");
        progress_bar_mother_guard.setStyle("-fx-accent: #1ff7ff");

        AudioClip note = new AudioClip(this.getClass().getResource("music.wav").toString());
        note.play();

        Thread thread = new Thread(new Runnable() {
            Circle[] normal_hunter = {normal_hunter1 , normal_hunter2 , normal_hunter3 , normal_hunter4 , normal_hunter5 , normal_hunter6 , normal_hunter7 , normal_hunter8};
            Circle[] suicide_hunter = {suicide_hunter1 , suicide_hunter2};
            Circle[] knight_hunter = {knight_hunter1};
            @Override
            public void run() {
                try {
                    Thread.sleep(20000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                normal_hunter[0].setLayoutY(RandHunterY());
                normal_hunter[1].setLayoutY(RandHunterY());
                normal_hunter[2].setLayoutY(RandHunterY());
                normal_hunter[3].setLayoutY(RandHunterY());
                normal_hunter[4].setLayoutY(RandHunterY());
                normal_hunter[5].setLayoutY(RandHunterY());
                normal_hunter[6].setLayoutY(RandHunterY());
                normal_hunter[7].setLayoutY(RandHunterY());
                suicide_hunter[0].setLayoutY(RandHunterY());
                suicide_hunter[1].setLayoutY(RandHunterY());
                knight_hunter[0].setLayoutY(RandHunterY());
                while (true) {
                    music += speed;
                    if (music >= 77000){
                        note.play();
                        music = 0;
                    }
                    while (stop == 1) {
                        try {
                            music+=21;
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    speedAndDestructionNum++;
                    if (speedAndDestructionNum == 500 && decelerationNum < 5) {
                        speed -= 10;
                        destruction += 0.002;
                        speedAndDestructionNum = 0;
                        decelerationNum++;
                    }
                    reproductionNormalHunter[0]++;
                    reproductionNormalHunter[1]++;
                    reproductionNormalHunter[2]++;
                    reproductionNormalHunter[3]++;
                    reproductionNormalHunter[4]++;
                    reproductionNormalHunter[5]++;
                    reproductionNormalHunter[6]++;
                    reproductionNormalHunter[7]++;
                    reproductionSuicideHunter[0]++;
                    reproductionSuicideHunter[1]++;
                    reproductionKnightHunter[0]++;
                    try {
                        Thread.sleep(speed);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {

                            //  Move normal hunter and delete row

                            for (normalHunter = 0; normalHunter < 8; normalHunter++) {
                                if (reproductionNormalHunter[normalHunter] >= 300) {
                                    if (normal_hunter[normalHunter].getLayoutX() <= 30) {
                                        reproductionNormalHunter[normalHunter] = RandHunter();
                                        normal_hunter[normalHunter].setLayoutX(1700);
                                        normal_hunter[normalHunter].setOpacity(1);
                                        opacityNormalHunter[normalHunter] = 1;
                                        collisionNormalHunterNum[normalHunter] = 0;
                                        switch ((int) normal_hunter[normalHunter].getLayoutY()){
                                            case 215:
                                                if (deleteRow[0] == false){
                                                    deleteRowNum++;
                                                    line1.setVisible(true);
                                                    line2.setVisible(true);
                                                    delete_line1.setVisible(true);
                                                    deleteRow[0] = true;
                                                }
                                                break;
                                            case 377:
                                                if (deleteRow[1] == false){
                                                    deleteRowNum++;
                                                    line3.setVisible(true);
                                                    line4.setVisible(true);
                                                    delete_line2.setVisible(true);
                                                    deleteRow[1] = true;
                                                }
                                                break;
                                            case 539:
                                                if (deleteRow[2] == false){
                                                    deleteRowNum++;
                                                    line5.setVisible(true);
                                                    line6.setVisible(true);
                                                    delete_line3.setVisible(true);
                                                    deleteRow[2] = true;
                                                }
                                                break;
                                            case 701:
                                                if (deleteRow[3] == false){
                                                    deleteRowNum++;
                                                    line7.setVisible(true);
                                                    line8.setVisible(true);
                                                    delete_line4.setVisible(true);
                                                    deleteRow[3] = true;
                                                }
                                                break;
                                        }
                                        if (deleteRowNum == 4){
                                            try {
                                                File myObj = new File("RecordEasy.txt");
                                                Scanner myReader = new Scanner(myObj);
                                                while (myReader.hasNextLine()) {
                                                    pastScores = Integer.parseInt(myReader.nextLine());
                                                    if (pastScores >= score) {
                                                        highScore = false;
                                                    }
                                                }
                                                myReader.close();
                                            } catch (FileNotFoundException e) {
                                                System.out.println("An error occurred.");
                                                e.printStackTrace();
                                            }
                                            if (highScore == true) {
                                                try {
                                                    FileWriter myWriter = new FileWriter("RecordEasy.txt", true);
                                                    PrintWriter pw = new PrintWriter(myWriter);
                                                    pw.println(score);
                                                    myWriter.close();
                                                } catch (IOException e) {
                                                    System.out.println("An error occurred.");
                                                    e.printStackTrace();
                                                }
                                            }
                                            Stage primaryStage = (Stage) score_text.getScene().getWindow();
                                            FXMLLoader loader = new FXMLLoader(getClass().getResource("end_game.fxml"));
                                            Parent root = null;
                                            try {
                                                root = loader.load();
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                            if (darkMode == true){
                                                EndGameController endGameController = loader.getController();
                                                endGameController.darkMode();
                                            }
                                            EndGameController controller = loader.getController();
                                            controller.setScore(score);
                                            primaryStage.setTitle("GUARDS vs Hunters");
                                            primaryStage.setScene(new Scene(root, 1533, 797));
                                            primaryStage.show();
                                        }
                                        normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                    }
                                    switch ((int) normal_hunter[normalHunter].getLayoutY()){
                                        case 215:
                                            if (deleteRow[0] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                        case 377:
                                            if (deleteRow[1] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                        case 539:
                                            if (deleteRow[2] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                        case 701:
                                            if (deleteRow[3] == true){
                                                normal_hunter[normalHunter].setLayoutX(1700);
                                                normal_hunter[normalHunter].setLayoutY(RandHunterY());
                                                normal_hunter[normalHunter].setOpacity(1);
                                                opacityNormalHunter[normalHunter] = 1;
                                                collisionNormalHunterNum[normalHunter] = 0;
                                            }
                                            break;
                                    }
                                    normal_hunter[normalHunter].setLayoutX(normal_hunter[normalHunter].getLayoutX() - 2);
                                }
                            }

                            //  Move suicide hunter and delete row

                            for (suicideHunter = 0; suicideHunter < 2; suicideHunter++) {
                                if (reproductionSuicideHunter[suicideHunter] >= 700) {
                                    if (suicide_hunter[suicideHunter].getLayoutX() <= 30) {
                                        reproductionSuicideHunter[suicideHunter] = RandHunter();
                                        suicide_hunter[suicideHunter].setLayoutX(1700);
                                        suicide_hunter[suicideHunter].setOpacity(1);
                                        opacitySuicideHunter[suicideHunter] = 1;
                                        collisionSuicideHunterNum[suicideHunter] = 0;
                                        switch ((int) suicide_hunter[suicideHunter].getLayoutY()){
                                            case 215:
                                                if (deleteRow[0] == false){
                                                    deleteRowNum++;
                                                    line1.setVisible(true);
                                                    line2.setVisible(true);
                                                    delete_line1.setVisible(true);
                                                    deleteRow[0] = true;
                                                }
                                                break;
                                            case 377:
                                                if (deleteRow[1] == false){
                                                    deleteRowNum++;
                                                    line3.setVisible(true);
                                                    line4.setVisible(true);
                                                    delete_line2.setVisible(true);
                                                    deleteRow[1] = true;
                                                }
                                                break;
                                            case 539:
                                                if (deleteRow[2] == false){
                                                    deleteRowNum++;
                                                    line5.setVisible(true);
                                                    line6.setVisible(true);
                                                    delete_line3.setVisible(true);
                                                    deleteRow[2] = true;
                                                }
                                                break;
                                            case 701:
                                                if (deleteRow[3] == false){
                                                    deleteRowNum++;
                                                    line7.setVisible(true);
                                                    line8.setVisible(true);
                                                    delete_line4.setVisible(true);
                                                    deleteRow[3] = true;
                                                }
                                                break;
                                        }
                                        if (deleteRowNum == 4){
                                            try {
                                                File myObj = new File("RecordEasy.txt");
                                                Scanner myReader = new Scanner(myObj);
                                                while (myReader.hasNextLine()) {
                                                    pastScores = Integer.parseInt(myReader.nextLine());
                                                    if (pastScores >= score) {
                                                        highScore = false;
                                                    }
                                                }
                                                myReader.close();
                                            } catch (FileNotFoundException e) {
                                                System.out.println("An error occurred.");
                                                e.printStackTrace();
                                            }
                                            if (highScore == true) {
                                                try {
                                                    FileWriter myWriter = new FileWriter("RecordEasy.txt", true);
                                                    PrintWriter pw = new PrintWriter(myWriter);
                                                    pw.println(score);
                                                    myWriter.close();
                                                } catch (IOException e) {
                                                    System.out.println("An error occurred.");
                                                    e.printStackTrace();
                                                }
                                            }
                                            Stage primaryStage = (Stage) score_text.getScene().getWindow();
                                            FXMLLoader loader = new FXMLLoader(getClass().getResource("end_game.fxml"));
                                            Parent root = null;
                                            try {
                                                root = loader.load();
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                            EndGameController controller = loader.getController();
                                            controller.setScore(score);
                                            primaryStage.setTitle("GUARDS vs Hunters");
                                            primaryStage.setScene(new Scene(root, 1533, 797));
                                            primaryStage.show();
                                        }
                                        suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                    }
                                    switch ((int) suicide_hunter[suicideHunter].getLayoutY()){
                                        case 215:
                                            if (deleteRow[0] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                        case 377:
                                            if (deleteRow[1] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                        case 539:
                                            if (deleteRow[2] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                        case 701:
                                            if (deleteRow[3] == true){
                                                suicide_hunter[suicideHunter].setLayoutX(1700);
                                                suicide_hunter[suicideHunter].setLayoutY(RandHunterY());
                                                suicide_hunter[suicideHunter].setOpacity(1);
                                                opacitySuicideHunter[suicideHunter] = 1;
                                                collisionSuicideHunterNum[suicideHunter] = 0;
                                            }
                                            break;
                                    }
                                    suicide_hunter[suicideHunter].setLayoutX(suicide_hunter[suicideHunter].getLayoutX() - 5);
                                }
                            }

                            //  Move knight hunter and delete row

                            for (knightHunter = 0; knightHunter < 1; knightHunter++) {
                                if (reproductionKnightHunter[knightHunter] >= 400) {
                                    if (knight_hunter[knightHunter].getLayoutX() <= 30) {
                                        reproductionKnightHunter[knightHunter] = RandHunter();
                                        knight_hunter[knightHunter].setLayoutX(1700);
                                        knight_hunter[knightHunter].setOpacity(1);
                                        opacityKnightHunter[knightHunter] = 1;
                                        collisionKnightHunterNum[knightHunter] = 0;
                                        switch ((int) knight_hunter[knightHunter].getLayoutY()){
                                            case 215:
                                                if (deleteRow[0] == false){
                                                    deleteRowNum++;
                                                    line1.setVisible(true);
                                                    line2.setVisible(true);
                                                    delete_line1.setVisible(true);
                                                    deleteRow[0] = true;
                                                }
                                                break;
                                            case 377:
                                                if (deleteRow[1] == false){
                                                    deleteRowNum++;
                                                    line3.setVisible(true);
                                                    line4.setVisible(true);
                                                    delete_line2.setVisible(true);
                                                    deleteRow[1] = true;
                                                }
                                                break;
                                            case 539:
                                                if (deleteRow[2] == false){
                                                    deleteRowNum++;
                                                    line5.setVisible(true);
                                                    line6.setVisible(true);
                                                    delete_line3.setVisible(true);
                                                    deleteRow[2] = true;
                                                }
                                                break;
                                            case 701:
                                                if (deleteRow[3] == false){
                                                    deleteRowNum++;
                                                    line7.setVisible(true);
                                                    line8.setVisible(true);
                                                    delete_line4.setVisible(true);
                                                    deleteRow[3] = true;
                                                }
                                                break;
                                        }
                                        if (deleteRowNum == 4){
                                            try {
                                                File myObj = new File("RecordEasy.txt");
                                                Scanner myReader = new Scanner(myObj);
                                                while (myReader.hasNextLine()) {
                                                    pastScores = Integer.parseInt(myReader.nextLine());
                                                    if (pastScores >= score) {
                                                        highScore = false;
                                                    }
                                                }
                                                myReader.close();
                                            } catch (FileNotFoundException e) {
                                                System.out.println("An error occurred.");
                                                e.printStackTrace();
                                            }
                                            if (highScore == true) {
                                                try {
                                                    FileWriter myWriter = new FileWriter("RecordEasy.txt", true);
                                                    PrintWriter pw = new PrintWriter(myWriter);
                                                    pw.println(score);
                                                    myWriter.close();
                                                } catch (IOException e) {
                                                    System.out.println("An error occurred.");
                                                    e.printStackTrace();
                                                }
                                            }
                                            Stage primaryStage = (Stage) score_text.getScene().getWindow();
                                            FXMLLoader loader = new FXMLLoader(getClass().getResource("end_game.fxml"));
                                            Parent root = null;
                                            try {
                                                root = loader.load();
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                            if (darkMode == true){
                                                EndGameController endGameController = loader.getController();
                                                endGameController.darkMode();
                                            }
                                            EndGameController controller = loader.getController();
                                            controller.setScore(score);
                                            primaryStage.setTitle("GUARDS vs Hunters");
                                            primaryStage.setScene(new Scene(root, 1533, 797));
                                            primaryStage.show();
                                        }
                                        knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                    }
                                    switch ((int) knight_hunter[knightHunter].getLayoutY()){
                                        case 215:
                                            if (deleteRow[0] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                        case 377:
                                            if (deleteRow[1] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                        case 539:
                                            if (deleteRow[2] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                        case 701:
                                            if (deleteRow[3] == true){
                                                knight_hunter[knightHunter].setLayoutX(1700);
                                                knight_hunter[knightHunter].setLayoutY(RandHunterY());
                                                knight_hunter[knightHunter].setOpacity(1);
                                                opacityKnightHunter[knightHunter] = 1;
                                                collisionKnightHunterNum[knightHunter] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            break;
                                    }
                                    knight_hunter[knightHunter].setLayoutX(knight_hunter[knightHunter].getLayoutX() - 2);
                                }
                            }
                        }
                    });
                }
            }
        });
        thread.start();

        Thread thread2 = new Thread(new Runnable() {

            Circle[] normal_hunter = {normal_hunter1 , normal_hunter2 , normal_hunter3 , normal_hunter4 , normal_hunter5 , normal_hunter6 , normal_hunter7 , normal_hunter8};
            Circle[] suicide_hunter = {suicide_hunter1 , suicide_hunter2};
            Circle[] knight_hunter = {knight_hunter1};

            Rectangle[] simple_guard = {simple_guard1 , simple_guard2 , simple_guard3 , simple_guard4 , simple_guard5 , simple_guard6 , simple_guard7 , simple_guard8
                    , simple_guard9 , simple_guard10 , simple_guard11 , simple_guard12 , simple_guard13 , simple_guard14 , simple_guard15 , simple_guard16} ;

            Rectangle[] Maine = {Maine1 , Maine2 , Maine3 , Maine4 , Maine5 , Maine6 , Maine7 , Maine8 , Maine9 , Maine10 , Maine11 , Maine12 , Maine13 , Maine14 , Maine15 ,
                    Maine16};

            Rectangle[] arrow = {arrow1 , arrow2 , arrow3 , arrow4 , arrow5 , arrow6 , arrow7 , arrow8 , arrow9 , arrow10 , arrow11 , arrow12 , arrow13 , arrow14 , arrow15 ,
                    arrow16};

            Rectangle[] knight_guard = {knight_guard1 , knight_guard2 , knight_guard3 , knight_guard4 , knight_guard5 , knight_guard6 , knight_guard7 , knight_guard8 ,
                    knight_guard9 , knight_guard10 , knight_guard11 , knight_guard12 , knight_guard13 , knight_guard14 , knight_guard15 , knight_guard16};

            Rectangle[] knight_arrow = {knight_arrow1 , knight_arrow2 , knight_arrow3 , knight_arrow4 , knight_arrow5 , knight_arrow6 , knight_arrow7 , knight_arrow8 ,
                    knight_arrow9 , knight_arrow10 , knight_arrow11 , knight_arrow12 , knight_arrow13 , knight_arrow14 , knight_arrow15 , knight_arrow16};

            Rectangle[] mother_guard = {mother_guard1 , mother_guard2 , mother_guard3 , mother_guard4 , mother_guard5 , mother_guard6 , mother_guard7 , mother_guard8 ,
                    mother_guard9 , mother_guard10 , mother_guard11 , mother_guard12 , mother_guard13 , mother_guard14 , mother_guard15 , mother_guard16};

            Polygon[] money_pocket_guard = {money_pocket_guard1 , money_pocket_guard2 , money_pocket_guard3 , money_pocket_guard4 , money_pocket_guard5 , money_pocket_guard6 ,
                    money_pocket_guard7 , money_pocket_guard8 , money_pocket_guard9 , money_pocket_guard10 , money_pocket_guard11 , money_pocket_guard12 , money_pocket_guard13 ,
                    money_pocket_guard14 , money_pocket_guard15 , money_pocket_guard16};

            AnchorPane[] anchor_pane = {anchor_pane1 , anchor_pane2 , anchor_pane3 , anchor_pane4 , anchor_pane5 , anchor_pane6 , anchor_pane7 , anchor_pane8
                    , anchor_pane9 , anchor_pane10 , anchor_pane11 , anchor_pane12 , anchor_pane13 , anchor_pane14 , anchor_pane15 , anchor_pane16};

            @Override
            public void run() {
                while (true) {
                    while (stop == 1) {
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            for (guardNum = 0 ; guardNum < 16 ; guardNum++) {
                                for (rowCoefficient = 0 ; rowCoefficient < 4 ; rowCoefficient++) {
                                    if (4 * rowCoefficient == guardNum){
                                        Y = 165;
                                    }
                                    if (4 * rowCoefficient + 1 == guardNum){
                                        Y = 327;
                                    }
                                    if (4 * rowCoefficient + 2 == guardNum){
                                        Y = 489;
                                    }
                                    if (4 * rowCoefficient + 3 == guardNum){
                                        Y = 651;
                                    }
                                }
                                if (0 <= guardNum && guardNum < 4) {
                                    arrowEffectRange = 1367;
                                    X = 150;
                                }
                                if (4 <= guardNum && guardNum < 8) {
                                    arrowEffectRange = 1017;
                                    X = 500;
                                }
                                if (8 <= guardNum && guardNum < 12) {
                                    arrowEffectRange = 667;
                                    X = 850;
                                }
                                if (12 <= guardNum && guardNum < 16) {
                                    arrowEffectRange = 317;
                                    X = 1200;
                                }

                                //  Simple guard section

                                if (selectSimpleGuard[guardNum] == true) {
                                    simple_guard[guardNum].setVisible(true);
                                    if (visibleArrow[guardNum] == true){
                                        arrow[guardNum].setVisible(true);
                                        visibleArrow[guardNum] = false;
                                    }

                                    //  Arrow move

                                    arrow[guardNum].setLayoutX(arrow[guardNum].getLayoutX() + 5);

                                    //  Shoot again

                                    shootAgain[guardNum]++;
                                    if (shootAgain[guardNum] == 260){
                                        arrow[guardNum].setVisible(true);
                                        shootAgain[guardNum] = 0;
                                        arrow[guardNum].setLayoutX(77);
                                        hideArrow[guardNum] = true;
                                    }

                                    //  Normal Hunter section in the simple guard

                                    for (normalHunterNum = 0 ; normalHunterNum < 8 ; normalHunterNum++) {

                                        //  Collision of the simple guard arrow with normal hunter

                                        if (arrow[guardNum].getLayoutY() + Y + 3 == normal_hunter[normalHunterNum].getLayoutY() && (arrow[guardNum].getLayoutX() + X <= normal_hunter[normalHunterNum].getLayoutX() && arrow[guardNum].getLayoutX() + X + 50 >= normal_hunter[normalHunterNum].getLayoutX()) && hideArrow[guardNum] == true && arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionNormalHunterNum[normalHunterNum]++;
                                            opacityNormalHunter[normalHunterNum] -= 0.1;
                                            if (opacityNormalHunter[normalHunterNum] > 0){
                                                normal_hunter[normalHunterNum].setOpacity(opacityNormalHunter[normalHunterNum]);
                                            }
                                            if (collisionNormalHunterNum[normalHunterNum] == 10){
                                                score += 5;
                                                score_text.setText(String.valueOf(score));
                                                reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                normal_hunter[normalHunterNum].setLayoutX(1700);
                                                normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                collisionNormalHunterNum[normalHunterNum] = 0;
                                                opacityNormalHunter[normalHunterNum] = 1;
                                                normal_hunter[normalHunterNum].setOpacity(1);
                                            }
                                            arrow[guardNum].setVisible(false);
                                            hideArrow[guardNum] = false;
                                        }

                                        //  Collision of the simple guard with normal hunter

                                        if (simple_guard[guardNum].getLayoutY() + Y + 33 == normal_hunter[normalHunterNum].getLayoutY() && (simple_guard[guardNum].getLayoutX() + X + 60 <= normal_hunter[normalHunterNum].getLayoutX() && simple_guard[guardNum].getLayoutX() + X + 110 >= normal_hunter[normalHunterNum].getLayoutX())){
                                            if (opacitySimpleGuard[guardNum] >= 0){
                                                normal_hunter[normalHunterNum].setLayoutX(normal_hunter[normalHunterNum].getLayoutX() + 2);
                                                opacitySimpleGuard[guardNum] -= destruction;
                                                simple_guard[guardNum].setOpacity(opacitySimpleGuard[guardNum]);
                                            }
                                            else {
                                                selectSimpleGuard[guardNum] = false;
                                                simple_guard[guardNum].setOpacity(1);
                                                arrow[guardNum].setLayoutX(77);
                                                simple_guard[guardNum].setVisible(false);
                                                opacitySimpleGuard[guardNum] = 1;
                                            }
                                        }
                                    }

                                    //  Suicide Hunter section in the simple guard

                                    for (suicideHunterNum = 0 ; suicideHunterNum < 2 ; suicideHunterNum++){

                                        //  Collision of the simple guard arrow with suicide hunter

                                        if (arrow[guardNum].getLayoutY() + Y + 3 == suicide_hunter[suicideHunterNum].getLayoutY() && (arrow[guardNum].getLayoutX() + X <= suicide_hunter[suicideHunterNum].getLayoutX() && arrow[guardNum].getLayoutX() + X + 50 >= suicide_hunter[suicideHunterNum].getLayoutX()) && hideArrow[guardNum] == true && arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionSuicideHunterNum[suicideHunterNum]++;
                                            opacitySuicideHunter[suicideHunterNum] -= 0.25;
                                            if (opacitySuicideHunter[suicideHunterNum] > 0){
                                                suicide_hunter[suicideHunterNum].setOpacity(opacitySuicideHunter[suicideHunterNum]);
                                            }
                                            if (collisionSuicideHunterNum[suicideHunterNum] == 4){
                                                score += 15;
                                                score_text.setText(String.valueOf(score));
                                                reproductionSuicideHunter[suicideHunterNum] = RandHunter();
                                                suicide_hunter[suicideHunterNum].setLayoutX(1700);
                                                suicide_hunter[suicideHunterNum].setLayoutY(RandHunterY());
                                                collisionSuicideHunterNum[suicideHunterNum] = 0;
                                                opacitySuicideHunter[suicideHunterNum] = 1;
                                                suicide_hunter[suicideHunterNum].setOpacity(1);
                                            }
                                            arrow[guardNum].setVisible(false);
                                            hideArrow[guardNum] = false;
                                        }

                                        //  Collision of the simple guard with suicide hunter

                                        if (simple_guard[guardNum].getLayoutY() + Y + 33 == suicide_hunter[suicideHunterNum].getLayoutY() && (simple_guard[guardNum].getLayoutX() + X + 60 <= suicide_hunter[suicideHunterNum].getLayoutX() && simple_guard[guardNum].getLayoutX() + X + 110 >= suicide_hunter[suicideHunterNum].getLayoutX())){

                                            //  Remove simple guard , maine , knight guard and mother guard around

                                            for (anchorPaneNum = 0 ; anchorPaneNum < 16 ; anchorPaneNum++){
                                                if ((anchor_pane[anchorPaneNum].getLayoutY() - 200 + 185 <= suicide_hunter[suicideHunterNum].getLayoutY() && anchor_pane[anchorPaneNum].getLayoutY() + 200 + 185 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (anchor_pane[anchorPaneNum].getLayoutX() - 200 + 161 <= suicide_hunter[suicideHunterNum].getLayoutX() && anchor_pane[anchorPaneNum].getLayoutX() + 200 + 161 >= suicide_hunter[suicideHunterNum].getLayoutX())){
                                                    selectSimpleGuard[anchorPaneNum] = false;
                                                    simple_guard[anchorPaneNum].setOpacity(1);
                                                    arrow[anchorPaneNum].setLayoutX(77);
                                                    simple_guard[anchorPaneNum].setVisible(false);
                                                    opacitySimpleGuard[anchorPaneNum] = 1;
                                                    arrow[anchorPaneNum].setVisible(false);
                                                    selectMaine[anchorPaneNum] = false;
                                                    Maine[anchorPaneNum].setVisible(false);
                                                    selectKnightGuard[anchorPaneNum] = false;
                                                    knight_guard[anchorPaneNum].setOpacity(1);
                                                    knight_arrow[anchorPaneNum].setLayoutX(77);
                                                    knight_guard[anchorPaneNum].setVisible(false);
                                                    opacityKnightGuard[anchorPaneNum] = 1;
                                                    knight_arrow[anchorPaneNum].setVisible(false);
                                                    selectMotherGuard[anchorPaneNum] = false;
                                                    mother_guard[anchorPaneNum].setOpacity(1);
                                                    mother_guard[anchorPaneNum].setVisible(false);
                                                    opacityMotherGuard[anchorPaneNum] = 1;
                                                    reproductionMoneyPocketGuard[anchorPaneNum] = 0;
                                                }
                                            }

                                            //  Remove normal hunter around

                                            for (normalHunterNum = 0 ; normalHunterNum < 8 ; normalHunterNum++){
                                                if ((normal_hunter[normalHunterNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && normal_hunter[normalHunterNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (normal_hunter[normalHunterNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && normal_hunter[normalHunterNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())){
                                                    reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                    normal_hunter[normalHunterNum].setLayoutX(1700);
                                                    normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                    normal_hunter[normalHunterNum].setOpacity(1);
                                                    opacityNormalHunter[normalHunterNum] = 1;
                                                }
                                            }

                                            //  Remove suicide hunter

                                            for (suicideHunterAroundNum = 0 ; suicideHunterAroundNum < 2 ; suicideHunterAroundNum++){
                                                if ((suicide_hunter[suicideHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && suicide_hunter[suicideHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (suicide_hunter[suicideHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && suicide_hunter[suicideHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())){
                                                    reproductionSuicideHunter[suicideHunterAroundNum] = RandHunter();
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutX(1700);
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutY(RandHunterY());
                                                    suicide_hunter[suicideHunterAroundNum].setOpacity(1);
                                                    opacitySuicideHunter[suicideHunterAroundNum] = 1;
                                                }
                                            }

                                            //  Remove knight hunter

                                            for (knightHunterAroundNum = 0 ; knightHunterAroundNum < 1 ; knightHunterAroundNum++){
                                                if ((knight_hunter[knightHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && knight_hunter[knightHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (knight_hunter[knightHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_hunter[knightHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())){
                                                    reproductionKnightHunter[knightHunterAroundNum] = RandHunter();
                                                    knight_hunter[knightHunterAroundNum].setLayoutX(1700);
                                                    knight_hunter[knightHunterAroundNum].setLayoutY(RandHunterY());
                                                    knight_hunter[knightHunterAroundNum].setOpacity(1);
                                                    opacityKnightHunter[knightHunterAroundNum] = 1;
                                                    opacityKnightHunterArmor[knightHunterNum] = 1;
                                                    knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                                }
                                            }
                                        }
                                    }

                                    //  Knight Hunter section in the simple guard

                                    for (knightHunterNum = 0 ; knightHunterNum < 1 ; knightHunterNum++) {

                                        //  Collision of the simple guard arrow with knight hunter

                                        if (arrow[guardNum].getLayoutY() + Y + 3 == knight_hunter[knightHunterNum].getLayoutY() && (arrow[guardNum].getLayoutX() + X <= knight_hunter[knightHunterNum].getLayoutX() && arrow[guardNum].getLayoutX() + X + 50 >= knight_hunter[knightHunterNum].getLayoutX()) && hideArrow[guardNum] == true && arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionKnightHunterNum[knightHunterNum]++;
                                            if (collisionKnightHunterNum[knightHunterNum] <= 4){
                                                opacityKnightHunterArmor[knightHunterNum] -= 0.2;
                                                if (opacityKnightHunterArmor[knightHunterNum] > 0){
                                                    knight_hunter[knightHunterNum].setOpacity(opacityKnightHunterArmor[knightHunterNum]);
                                                }
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] == 5){
                                                knight_hunter[knightHunterNum].setOpacity(opacityKnightHunter[knightHunterNum]);
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#e2ff1f"));
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] >= 6){
                                                opacityKnightHunter[knightHunterNum] -= 0.1;
                                                if (opacityKnightHunter[knightHunterNum] > 0){
                                                    knight_hunter[knightHunterNum].setOpacity(opacityKnightHunter[knightHunterNum]);
                                                }
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] == 15){
                                                score += 25;
                                                score_text.setText(String.valueOf(score));
                                                reproductionKnightHunter[knightHunterNum] = RandHunter();
                                                knight_hunter[knightHunterNum].setLayoutX(1700);
                                                knight_hunter[knightHunterNum].setLayoutY(RandHunterY());
                                                collisionKnightHunterNum[knightHunterNum] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                opacityKnightHunter[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setOpacity(1);
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            arrow[guardNum].setVisible(false);
                                            hideArrow[guardNum] = false;
                                        }

                                        //  Collision of the simple guard with knight hunter

                                        if (simple_guard[guardNum].getLayoutY() + Y + 33 == knight_hunter[knightHunterNum].getLayoutY() && (simple_guard[guardNum].getLayoutX() + X + 60 <= knight_hunter[knightHunterNum].getLayoutX() && simple_guard[guardNum].getLayoutX() + X + 110 >= knight_hunter[knightHunterNum].getLayoutX())){
                                            if (opacitySimpleGuard[guardNum] >= 0){
                                                knight_hunter[knightHunterNum].setLayoutX(knight_hunter[knightHunterNum].getLayoutX() + 2);
                                                opacitySimpleGuard[guardNum] -= destruction;
                                                simple_guard[guardNum].setOpacity(opacitySimpleGuard[guardNum]);
                                            }
                                            else {
                                                selectSimpleGuard[guardNum] = false;
                                                simple_guard[guardNum].setOpacity(1);
                                                arrow[guardNum].setLayoutX(77);
                                                simple_guard[guardNum].setVisible(false);
                                                opacitySimpleGuard[guardNum] = 1;
                                            }
                                        }
                                    }
                                }

                                //  Maine section

                                if (selectMaine[guardNum] == true){
                                    Maine[guardNum].setVisible(true);

                                    //  Normal Hunter , suicide hunter and knight hunter section in the Maine

                                    for (normalHunterNum = 0 ; normalHunterNum < 8 ; normalHunterNum++){
                                        for (suicideHunterNum = 0 ; suicideHunterNum < 2 ; suicideHunterNum++){
                                            for (knightHunterNum = 0 ; knightHunterNum < 1 ; knightHunterNum++){

                                                //  Collision of the maine with normal hunter , suicide hunter and knight hunter

                                                if (Maine[guardNum].getLayoutY() + Y + 33 == normal_hunter[normalHunterNum].getLayoutY() && (Maine[guardNum].getLayoutX() + X + 60 <= normal_hunter[normalHunterNum].getLayoutX() && Maine[guardNum].getLayoutX() + X + 110 >= normal_hunter[normalHunterNum].getLayoutX()) || Maine[guardNum].getLayoutY() + Y + 33 == suicide_hunter[suicideHunterNum].getLayoutY() && (Maine[guardNum].getLayoutX() + X + 60 <= suicide_hunter[suicideHunterNum].getLayoutX() && Maine[guardNum].getLayoutX() + X + 110 >= suicide_hunter[suicideHunterNum].getLayoutX()) || Maine[guardNum].getLayoutY() + Y + 33 == knight_hunter[knightHunterNum].getLayoutY() && (Maine[guardNum].getLayoutX() + X + 60 <= knight_hunter[knightHunterNum].getLayoutX() && Maine[guardNum].getLayoutX() + X + 110 >= knight_hunter[knightHunterNum].getLayoutX())){

                                                    //  Remove simple guard , maine , knight guard and mother guard around

                                                    for (anchorPaneNum = 0 ; anchorPaneNum < 16 ; anchorPaneNum++){
                                                        if ((anchor_pane[anchorPaneNum].getLayoutY() - 200 + 152 - Y  <= Maine[guardNum].getLayoutY() && anchor_pane[anchorPaneNum].getLayoutY() + 200 + 152 - Y >= Maine[guardNum].getLayoutY()) && (anchor_pane[anchorPaneNum].getLayoutX() - 200 + 51 - X <= Maine[guardNum].getLayoutX() && anchor_pane[anchorPaneNum].getLayoutX() + 200 + 51 - X >= Maine[guardNum].getLayoutX())){
                                                            selectSimpleGuard[anchorPaneNum] = false;
                                                            simple_guard[anchorPaneNum].setOpacity(1);
                                                            arrow[anchorPaneNum].setLayoutX(77);
                                                            simple_guard[anchorPaneNum].setVisible(false);
                                                            opacitySimpleGuard[anchorPaneNum] = 1;
                                                            arrow[anchorPaneNum].setVisible(false);
                                                            selectMaine[anchorPaneNum] = false;
                                                            Maine[anchorPaneNum].setVisible(false);
                                                            selectKnightGuard[anchorPaneNum] = false;
                                                            knight_guard[anchorPaneNum].setOpacity(1);
                                                            knight_arrow[anchorPaneNum].setLayoutX(77);
                                                            knight_guard[anchorPaneNum].setVisible(false);
                                                            opacityKnightGuard[anchorPaneNum] = 1;
                                                            knight_arrow[anchorPaneNum].setVisible(false);
                                                            selectMotherGuard[anchorPaneNum] = false;
                                                            mother_guard[anchorPaneNum].setOpacity(1);
                                                            mother_guard[anchorPaneNum].setVisible(false);
                                                            opacityMotherGuard[anchorPaneNum] = 1;
                                                            reproductionMoneyPocketGuard[anchorPaneNum] = 0;
                                                        }
                                                    }

                                                    //  Remove normal hunter around

                                                    for (normalHunterAroundNum = 0 ; normalHunterAroundNum < 8 ; normalHunterAroundNum++){
                                                        if ((normal_hunter[normalHunterAroundNum].getLayoutY() - 200 - Y - 33 <= Maine[guardNum].getLayoutY() && normal_hunter[normalHunterAroundNum].getLayoutY() + 200 - Y - 33 >= Maine[guardNum].getLayoutY()) && (normal_hunter[normalHunterAroundNum].getLayoutX() - 200 - X - 110 <= Maine[guardNum].getLayoutX() && normal_hunter[normalHunterAroundNum].getLayoutX() + 200 - X - 110 >= Maine[guardNum].getLayoutX())){
                                                            score += 5;
                                                            score_text.setText(String.valueOf(score));
                                                            reproductionNormalHunter[normalHunterAroundNum] = RandHunter();
                                                            normal_hunter[normalHunterAroundNum].setLayoutX(1700);
                                                            normal_hunter[normalHunterAroundNum].setLayoutY(RandHunterY());
                                                            normal_hunter[normalHunterAroundNum].setOpacity(1);
                                                            opacityNormalHunter[normalHunterAroundNum] = 1;
                                                        }
                                                    }

                                                    //  Remove suicide hunter around

                                                    for (suicideHunterAroundNum = 0 ; suicideHunterAroundNum < 2 ; suicideHunterAroundNum++){
                                                        if ((suicide_hunter[suicideHunterAroundNum].getLayoutY() - 200 - Y - 33 <= Maine[guardNum].getLayoutY() && suicide_hunter[suicideHunterAroundNum].getLayoutY() + 200 - Y - 33 >= Maine[guardNum].getLayoutY()) && (suicide_hunter[suicideHunterAroundNum].getLayoutX() - 200 - X - 110 <= Maine[guardNum].getLayoutX() && suicide_hunter[suicideHunterAroundNum].getLayoutX() + 200 - X - 110 >= Maine[guardNum].getLayoutX())){
                                                            score += 15;
                                                            score_text.setText(String.valueOf(score));
                                                            reproductionSuicideHunter[suicideHunterAroundNum] = RandHunter();
                                                            suicide_hunter[suicideHunterAroundNum].setLayoutX(1700);
                                                            suicide_hunter[suicideHunterAroundNum].setLayoutY(RandHunterY());
                                                            suicide_hunter[suicideHunterAroundNum].setOpacity(1);
                                                            opacitySuicideHunter[suicideHunterAroundNum] = 1;
                                                        }
                                                    }

                                                    //  Remove knight hunter around

                                                    for (knightHunterAroundNum = 0 ; knightHunterAroundNum < 1 ; knightHunterAroundNum++){
                                                        if ((knight_hunter[knightHunterAroundNum].getLayoutY() - 200 - Y - 33 <= Maine[guardNum].getLayoutY() && knight_hunter[knightHunterAroundNum].getLayoutY() + 200 - Y - 33 >= Maine[guardNum].getLayoutY()) && (knight_hunter[knightHunterAroundNum].getLayoutX() - 200 - X - 110 <= Maine[guardNum].getLayoutX() && knight_hunter[knightHunterAroundNum].getLayoutX() + 200 - X - 110 >= Maine[guardNum].getLayoutX())){
                                                            score += 25;
                                                            score_text.setText(String.valueOf(score));
                                                            reproductionKnightHunter[knightHunterAroundNum] = RandHunter();
                                                            knight_hunter[knightHunterAroundNum].setLayoutX(1700);
                                                            knight_hunter[knightHunterAroundNum].setLayoutY(RandHunterY());
                                                            knight_hunter[knightHunterAroundNum].setOpacity(1);
                                                            opacityKnightHunter[knightHunterAroundNum] = 1;
                                                            opacityKnightHunterArmor[knightHunterAroundNum] = 1;
                                                            knight_hunter[knightHunterAroundNum].setFill(Paint.valueOf("#f27913"));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                //  Knight guard section

                                if (selectKnightGuard[guardNum] == true) {
                                    knight_guard[guardNum].setVisible(true);
                                    if (visibleKnightArrow[guardNum] == true){
                                        knight_arrow[guardNum].setVisible(true);
                                        visibleKnightArrow[guardNum] = false;
                                    }

                                    //  Arrow move

                                    knight_arrow[guardNum].setLayoutX(knight_arrow[guardNum].getLayoutX() + 10);


                                    //  Shoot again

                                    shootAgainKnightArrow[guardNum]++;
                                    if (shootAgainKnightArrow[guardNum] == 130){
                                        knight_arrow[guardNum].setVisible(true);
                                        shootAgainKnightArrow[guardNum] = 0;
                                        knight_arrow[guardNum].setLayoutX(77);
                                        hideKnightArrow[guardNum] = true;
                                    }

                                    //  Normal Hunter section in the Knight guard

                                    for (normalHunterNum = 0 ; normalHunterNum < 8 ; normalHunterNum++) {

                                        //  Collision of the knight guard arrow with normal hunter

                                        if (knight_arrow[guardNum].getLayoutY() + Y + 3 == normal_hunter[normalHunterNum].getLayoutY() && (knight_arrow[guardNum].getLayoutX() + X <= normal_hunter[normalHunterNum].getLayoutX() && knight_arrow[guardNum].getLayoutX() + X + 50 >= normal_hunter[normalHunterNum].getLayoutX()) && hideKnightArrow[guardNum] == true && knight_arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionNormalHunterNum[normalHunterNum]++;
                                            opacityNormalHunter[normalHunterNum] -= 0.1;
                                            if (opacityNormalHunter[normalHunterNum] > 0){
                                                normal_hunter[normalHunterNum].setOpacity(opacityNormalHunter[normalHunterNum]);
                                            }
                                            if (collisionNormalHunterNum[normalHunterNum] == 10){
                                                score += 5;
                                                score_text.setText(String.valueOf(score));
                                                reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                normal_hunter[normalHunterNum].setLayoutX(1700);
                                                normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                collisionNormalHunterNum[normalHunterNum] = 0;
                                                opacityNormalHunter[normalHunterNum] = 1;
                                                normal_hunter[normalHunterNum].setOpacity(1);
                                            }
                                            knight_arrow[guardNum].setVisible(false);
                                            hideKnightArrow[guardNum] = false;
                                        }

                                        //  Collision of the knight guard with normal hunter

                                        if (knight_guard[guardNum].getLayoutY() + Y + 33 == normal_hunter[normalHunterNum].getLayoutY() && (knight_guard[guardNum].getLayoutX() + X + 60 <= normal_hunter[normalHunterNum].getLayoutX() && knight_guard[guardNum].getLayoutX() + X + 110 >= normal_hunter[normalHunterNum].getLayoutX())){
                                            if (opacityKnightGuard[guardNum] >= 0){
                                                normal_hunter[normalHunterNum].setLayoutX(normal_hunter[normalHunterNum].getLayoutX() + 2);
                                                opacityKnightGuard[guardNum] -= destruction;
                                                knight_guard[guardNum].setOpacity(opacityKnightGuard[guardNum]);
                                            }
                                            else {
                                                selectKnightGuard[guardNum] = false;
                                                knight_guard[guardNum].setOpacity(1);
                                                knight_arrow[guardNum].setLayoutX(77);
                                                knight_guard[guardNum].setVisible(false);
                                                opacityKnightGuard[guardNum] = 1;
                                            }
                                        }
                                    }

                                    //  Suicide Hunter section in the Knight guard

                                    for (suicideHunterNum = 0 ; suicideHunterNum < 2 ; suicideHunterNum++) {

                                        //  Collision of the knight guard arrow with suicide hunter

                                        if (knight_arrow[guardNum].getLayoutY() + Y + 3 == suicide_hunter[suicideHunterNum].getLayoutY() && (knight_arrow[guardNum].getLayoutX() + X <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_arrow[guardNum].getLayoutX() + X + 50 >= suicide_hunter[suicideHunterNum].getLayoutX()) && hideKnightArrow[guardNum] == true && knight_arrow[guardNum].getLayoutX() <= arrowEffectRange) {
                                            collisionSuicideHunterNum[suicideHunterNum]++;
                                            opacitySuicideHunter[suicideHunterNum] -= 0.25;
                                            if (opacitySuicideHunter[suicideHunterNum] > 0) {
                                                suicide_hunter[suicideHunterNum].setOpacity(opacitySuicideHunter[suicideHunterNum]);
                                            }
                                            if (collisionSuicideHunterNum[suicideHunterNum] == 4) {
                                                score += 15;
                                                score_text.setText(String.valueOf(score));
                                                reproductionSuicideHunter[suicideHunterNum] = RandHunter();
                                                suicide_hunter[suicideHunterNum].setLayoutX(1700);
                                                suicide_hunter[suicideHunterNum].setLayoutY(RandHunterY());
                                                collisionSuicideHunterNum[suicideHunterNum] = 0;
                                                opacitySuicideHunter[suicideHunterNum] = 1;
                                                suicide_hunter[suicideHunterNum].setOpacity(1);
                                            }
                                            knight_arrow[guardNum].setVisible(false);
                                            hideKnightArrow[guardNum] = false;
                                        }

                                        //  Collision of the knight guard with suicide hunter

                                        if (knight_guard[guardNum].getLayoutY() + Y + 33 == suicide_hunter[suicideHunterNum].getLayoutY() && (knight_guard[guardNum].getLayoutX() + X + 60 <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_guard[guardNum].getLayoutX() + X + 110 >= suicide_hunter[suicideHunterNum].getLayoutX())) {

                                            //  Remove simple guard , maine , knight guard and mother guard around

                                            for (anchorPaneNum = 0; anchorPaneNum < 16; anchorPaneNum++) {
                                                if ((anchor_pane[anchorPaneNum].getLayoutY() - 200 + 185 <= suicide_hunter[suicideHunterNum].getLayoutY() && anchor_pane[anchorPaneNum].getLayoutY() + 200 + 185 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (anchor_pane[anchorPaneNum].getLayoutX() - 200 + 161 <= suicide_hunter[suicideHunterNum].getLayoutX() && anchor_pane[anchorPaneNum].getLayoutX() + 200 + 161 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    selectSimpleGuard[anchorPaneNum] = false;
                                                    simple_guard[anchorPaneNum].setOpacity(1);
                                                    arrow[anchorPaneNum].setLayoutX(77);
                                                    simple_guard[anchorPaneNum].setVisible(false);
                                                    opacitySimpleGuard[anchorPaneNum] = 1;
                                                    arrow[anchorPaneNum].setVisible(false);
                                                    selectMaine[anchorPaneNum] = false;
                                                    Maine[anchorPaneNum].setVisible(false);
                                                    selectKnightGuard[anchorPaneNum] = false;
                                                    knight_guard[anchorPaneNum].setOpacity(1);
                                                    knight_arrow[anchorPaneNum].setLayoutX(77);
                                                    knight_guard[anchorPaneNum].setVisible(false);
                                                    opacityKnightGuard[anchorPaneNum] = 1;
                                                    knight_arrow[anchorPaneNum].setVisible(false);
                                                    selectMotherGuard[anchorPaneNum] = false;
                                                    mother_guard[anchorPaneNum].setOpacity(1);
                                                    mother_guard[anchorPaneNum].setVisible(false);
                                                    opacityMotherGuard[anchorPaneNum] = 1;
                                                    reproductionMoneyPocketGuard[anchorPaneNum] = 0;
                                                }
                                            }

                                            //  Remove normal hunter around

                                            for (normalHunterNum = 0; normalHunterNum < 8; normalHunterNum++) {
                                                if ((normal_hunter[normalHunterNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && normal_hunter[normalHunterNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (normal_hunter[normalHunterNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && normal_hunter[normalHunterNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                    normal_hunter[normalHunterNum].setLayoutX(1700);
                                                    normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                    normal_hunter[normalHunterNum].setOpacity(1);
                                                    opacityNormalHunter[normalHunterNum] = 1;
                                                }
                                            }

                                            //  Remove suicide hunter around

                                            for (suicideHunterAroundNum = 0; suicideHunterAroundNum < 2; suicideHunterAroundNum++) {
                                                if ((suicide_hunter[suicideHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && suicide_hunter[suicideHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (suicide_hunter[suicideHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && suicide_hunter[suicideHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionSuicideHunter[suicideHunterAroundNum] = RandHunter();
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutX(1700);
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutY(RandHunterY());
                                                    suicide_hunter[suicideHunterAroundNum].setOpacity(1);
                                                    opacitySuicideHunter[suicideHunterAroundNum] = 1;
                                                }
                                            }

                                            //  Remove knight hunter around

                                            for (knightHunterAroundNum = 0; knightHunterAroundNum < 1; knightHunterAroundNum++) {
                                                if ((knight_hunter[knightHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && knight_hunter[knightHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (knight_hunter[knightHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_hunter[knightHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionKnightHunter[knightHunterAroundNum] = RandHunter();
                                                    knight_hunter[knightHunterAroundNum].setLayoutX(1700);
                                                    knight_hunter[knightHunterAroundNum].setLayoutY(RandHunterY());
                                                    knight_hunter[knightHunterAroundNum].setOpacity(1);
                                                    opacityKnightHunter[knightHunterAroundNum] = 1;
                                                    opacityKnightHunterArmor[knightHunterNum] = 1;
                                                    knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                                }
                                            }
                                        }
                                    }
                                    //  Knight Hunter section in the Knight guard

                                    for (knightHunterNum = 0 ; knightHunterNum < 1 ; knightHunterNum++) {

                                        //  Collision of the knight guard arrow with knight hunter

                                        if (knight_arrow[guardNum].getLayoutY() + Y + 3 == knight_hunter[knightHunterNum].getLayoutY() && (knight_arrow[guardNum].getLayoutX() + X <= knight_hunter[knightHunterNum].getLayoutX() && knight_arrow[guardNum].getLayoutX() + X + 50 >= knight_hunter[knightHunterNum].getLayoutX()) && hideKnightArrow[guardNum] == true && knight_arrow[guardNum].getLayoutX() <= arrowEffectRange){
                                            collisionKnightHunterNum[knightHunterNum]++;
                                            if (collisionKnightHunterNum[knightHunterNum] <= 4){
                                                opacityKnightHunterArmor[knightHunterNum] -= 0.2;
                                                if (opacityKnightHunterArmor[knightHunterNum] > 0){
                                                    knight_hunter[knightHunterNum].setOpacity(opacityKnightHunterArmor[knightHunterNum]);
                                                }
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] == 5){
                                                knight_hunter[knightHunterNum].setOpacity(opacityKnightHunter[knightHunterNum]);
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#e2ff1f"));
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] >= 6){
                                                opacityKnightHunter[knightHunterNum] -= 0.1;
                                                if (opacityKnightHunter[knightHunterNum] > 0){
                                                    knight_hunter[knightHunterNum].setOpacity(opacityKnightHunter[knightHunterNum]);
                                                }
                                            }
                                            if (collisionKnightHunterNum[knightHunterNum] == 15){
                                                score += 25;
                                                score_text.setText(String.valueOf(score));
                                                reproductionKnightHunter[knightHunterNum] = RandHunter();
                                                knight_hunter[knightHunterNum].setLayoutX(1700);
                                                knight_hunter[knightHunterNum].setLayoutY(RandHunterY());
                                                collisionKnightHunterNum[knightHunterNum] = 0;
                                                opacityKnightHunterArmor[knightHunterNum] = 1;
                                                opacityKnightHunter[knightHunterNum] = 1;
                                                knight_hunter[knightHunterNum].setOpacity(1);
                                                knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                            }
                                            knight_arrow[guardNum].setVisible(false);
                                            hideKnightArrow[guardNum] = false;
                                        }

                                        //  Collision of the knight guard with knight hunter

                                        if (knight_guard[guardNum].getLayoutY() + Y + 33 == knight_hunter[knightHunterNum].getLayoutY() && (knight_guard[guardNum].getLayoutX() + X + 60 <= knight_hunter[knightHunterNum].getLayoutX() && knight_guard[guardNum].getLayoutX() + X + 110 >= knight_hunter[knightHunterNum].getLayoutX())){
                                            if (opacityKnightGuard[guardNum] >= 0){
                                                knight_hunter[knightHunterNum].setLayoutX(knight_hunter[knightHunterNum].getLayoutX() + 2);
                                                opacityKnightGuard[guardNum] -= destruction;
                                                knight_guard[guardNum].setOpacity(opacityKnightGuard[guardNum]);
                                            }
                                            else {
                                                selectKnightGuard[guardNum] = false;
                                                knight_guard[guardNum].setOpacity(1);
                                                knight_arrow[guardNum].setLayoutX(77);
                                                knight_guard[guardNum].setVisible(false);
                                                opacityKnightGuard[guardNum] = 1;
                                            }
                                        }
                                    }
                                }

                                //  Mother guard section

                                if (selectMotherGuard[guardNum] == true) {
                                    mother_guard[guardNum].setVisible(true);
                                    reproductionMoneyPocketGuard[guardNum]++;
                                    if (reproductionMoneyPocketGuard[guardNum] == 1200){
                                        money_pocket_guard[guardNum].setVisible(true);
                                        reproductionMoneyPocketGuard[guardNum] = 0;
                                    }

                                    //  Normal Hunter section in the Mother guard

                                    for (normalHunterNum = 0 ; normalHunterNum < 8 ; normalHunterNum++) {

                                        //  Collision of the mother guard with normal hunter

                                        if (mother_guard[guardNum].getLayoutY() + Y + 33 == normal_hunter[normalHunterNum].getLayoutY() && (mother_guard[guardNum].getLayoutX() + X + 60 <= normal_hunter[normalHunterNum].getLayoutX() && mother_guard[guardNum].getLayoutX() + X + 110 >= normal_hunter[normalHunterNum].getLayoutX())){
                                            if (opacityMotherGuard[guardNum] >= 0){
                                                normal_hunter[normalHunterNum].setLayoutX(normal_hunter[normalHunterNum].getLayoutX() + 2);
                                                opacityMotherGuard[guardNum] -= destruction;
                                                mother_guard[guardNum].setOpacity(opacityMotherGuard[guardNum]);
                                            }
                                            else {
                                                selectMotherGuard[guardNum] = false;
                                                mother_guard[guardNum].setOpacity(1);
                                                mother_guard[guardNum].setVisible(false);
                                                opacityMotherGuard[guardNum] = 1;
                                            }
                                        }
                                    }

                                    //  Suicide Hunter section in the mother guard

                                    for (suicideHunterNum = 0 ; suicideHunterNum < 2 ; suicideHunterNum++) {

                                        //  Collision of the mother guard with suicide hunter

                                        if (mother_guard[guardNum].getLayoutY() + Y + 33 == suicide_hunter[suicideHunterNum].getLayoutY() && (mother_guard[guardNum].getLayoutX() + X + 60 <= suicide_hunter[suicideHunterNum].getLayoutX() && mother_guard[guardNum].getLayoutX() + X + 110 >= suicide_hunter[suicideHunterNum].getLayoutX())) {

                                            //  Remove simple guard , maine , knight guard and mother guard around

                                            for (anchorPaneNum = 0; anchorPaneNum < 16; anchorPaneNum++) {
                                                if ((anchor_pane[anchorPaneNum].getLayoutY() - 200 + 185 <= suicide_hunter[suicideHunterNum].getLayoutY() && anchor_pane[anchorPaneNum].getLayoutY() + 200 + 185 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (anchor_pane[anchorPaneNum].getLayoutX() - 200 + 161 <= suicide_hunter[suicideHunterNum].getLayoutX() && anchor_pane[anchorPaneNum].getLayoutX() + 200 + 161 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    selectSimpleGuard[anchorPaneNum] = false;
                                                    simple_guard[anchorPaneNum].setOpacity(1);
                                                    arrow[anchorPaneNum].setLayoutX(77);
                                                    simple_guard[anchorPaneNum].setVisible(false);
                                                    opacitySimpleGuard[anchorPaneNum] = 1;
                                                    arrow[anchorPaneNum].setVisible(false);
                                                    selectMaine[anchorPaneNum] = false;
                                                    Maine[anchorPaneNum].setVisible(false);
                                                    selectKnightGuard[anchorPaneNum] = false;
                                                    knight_guard[anchorPaneNum].setOpacity(1);
                                                    knight_arrow[anchorPaneNum].setLayoutX(77);
                                                    knight_guard[anchorPaneNum].setVisible(false);
                                                    opacityKnightGuard[anchorPaneNum] = 1;
                                                    knight_arrow[anchorPaneNum].setVisible(false);
                                                    selectMotherGuard[anchorPaneNum] = false;
                                                    mother_guard[anchorPaneNum].setOpacity(1);
                                                    mother_guard[anchorPaneNum].setVisible(false);
                                                    opacityMotherGuard[anchorPaneNum] = 1;
                                                    reproductionMoneyPocketGuard[anchorPaneNum] = 0;
                                                }
                                            }

                                            //  Remove normal hunter around

                                            for (normalHunterNum = 0; normalHunterNum < 8; normalHunterNum++) {
                                                if ((normal_hunter[normalHunterNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && normal_hunter[normalHunterNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (normal_hunter[normalHunterNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && normal_hunter[normalHunterNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionNormalHunter[normalHunterNum] = RandHunter();
                                                    normal_hunter[normalHunterNum].setLayoutX(1700);
                                                    normal_hunter[normalHunterNum].setLayoutY(RandHunterY());
                                                    normal_hunter[normalHunterNum].setOpacity(1);
                                                    opacityNormalHunter[normalHunterNum] = 1;
                                                }
                                            }
                                            //  Remove suicide hunter around

                                            for (suicideHunterAroundNum = 0; suicideHunterAroundNum < 2; suicideHunterAroundNum++) {
                                                if ((suicide_hunter[suicideHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && suicide_hunter[suicideHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (suicide_hunter[suicideHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && suicide_hunter[suicideHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionSuicideHunter[suicideHunterAroundNum] = RandHunter();
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutX(1700);
                                                    suicide_hunter[suicideHunterAroundNum].setLayoutY(RandHunterY());
                                                    suicide_hunter[suicideHunterAroundNum].setOpacity(1);
                                                    opacitySuicideHunter[suicideHunterAroundNum] = 1;
                                                }
                                            }

                                            //  Remove knight hunter around

                                            for (knightHunterAroundNum = 0; knightHunterAroundNum < 1; knightHunterAroundNum++) {
                                                if ((knight_hunter[knightHunterAroundNum].getLayoutY() - 200 <= suicide_hunter[suicideHunterNum].getLayoutY() && knight_hunter[knightHunterAroundNum].getLayoutY() + 200 >= suicide_hunter[suicideHunterNum].getLayoutY()) && (knight_hunter[knightHunterAroundNum].getLayoutX() - 200 <= suicide_hunter[suicideHunterNum].getLayoutX() && knight_hunter[knightHunterAroundNum].getLayoutX() + 200 >= suicide_hunter[suicideHunterNum].getLayoutX())) {
                                                    reproductionKnightHunter[knightHunterAroundNum] = RandHunter();
                                                    knight_hunter[knightHunterAroundNum].setLayoutX(1700);
                                                    knight_hunter[knightHunterAroundNum].setLayoutY(RandHunterY());
                                                    knight_hunter[knightHunterAroundNum].setOpacity(1);
                                                    opacityKnightHunter[knightHunterAroundNum] = 1;
                                                    opacityKnightHunterArmor[knightHunterNum] = 1;
                                                    knight_hunter[knightHunterNum].setFill(Paint.valueOf("#f27913"));
                                                }
                                            }
                                        }
                                    }

                                    //  Knight Hunter section in the mother guard

                                    for (knightHunterNum = 0 ; knightHunterNum < 1 ; knightHunterNum++) {

                                        //  Collision of the mother guard with knight hunter

                                        if (mother_guard[guardNum].getLayoutY() + Y + 33 == knight_hunter[knightHunterNum].getLayoutY() && (mother_guard[guardNum].getLayoutX() + X + 60 <= knight_hunter[knightHunterNum].getLayoutX() && mother_guard[guardNum].getLayoutX() + X + 110 >= knight_hunter[knightHunterNum].getLayoutX())){
                                            if (opacityMotherGuard[guardNum] >= 0){
                                                knight_hunter[knightHunterNum].setLayoutX(knight_hunter[knightHunterNum].getLayoutX() + 2);
                                                opacityMotherGuard[guardNum] -= destruction;
                                                mother_guard[guardNum].setOpacity(opacityMotherGuard[guardNum]);
                                            }
                                            else {
                                                selectMotherGuard[guardNum] = false;
                                                mother_guard[guardNum].setOpacity(1);
                                                mother_guard[guardNum].setVisible(false);
                                                opacityMotherGuard[guardNum] = 1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }
        });
        thread2.start();

        Thread thread3 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    while (stop == 1) {
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    reproductionMoneyPocket++;
                    progress_bar_normal_guard.setProgress(progress_bar_normal_guard.getProgress() + 0.004);
                    progress_bar_Maine.setProgress(progress_bar_Maine.getProgress() + 0.003);
                    progress_bar_knight_guard.setProgress(progress_bar_knight_guard.getProgress() + 0.002);
                    progress_bar_mother_guard.setProgress(progress_bar_mother_guard.getProgress() + 0.004);
                    opacity = money;
                    normal_guard.setOpacity(opacity / 100);
                    progress_bar_normal_guard.setOpacity(opacity / 100);
                    maine.setOpacity(opacity / 120);
                    progress_bar_Maine.setOpacity(opacity / 120);
                    knight_guard.setOpacity(opacity / 170);
                    progress_bar_knight_guard.setOpacity(opacity / 170);
                    mother_guard.setOpacity(opacity / 60);
                    progress_bar_mother_guard.setOpacity(opacity / 60);
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {

                            // Money pocket section

                            if (reproductionMoneyPocket == 300) {
                                reproductionMoneyPocket = 0;
                                switch(RandMoneyPocket()) {
                                    case '0':
                                        money_pocket1.setVisible(true);
                                        break;
                                    case '1':
                                        money_pocket2.setVisible(true);
                                        break;
                                    case '2':
                                        money_pocket3.setVisible(true);
                                        break;
                                    case '3':
                                        money_pocket4.setVisible(true);
                                        break;
                                    case '4':
                                        money_pocket5.setVisible(true);
                                        break;
                                    case '5':
                                        money_pocket6.setVisible(true);
                                        break;
                                    case '6':
                                        money_pocket7.setVisible(true);
                                        break;
                                    case '7':
                                        money_pocket8.setVisible(true);
                                        break;
                                    case '8':
                                        money_pocket9.setVisible(true);
                                        break;
                                    case '9':
                                        money_pocket10.setVisible(true);
                                        break;
                                    case 'A':
                                        money_pocket11.setVisible(true);
                                        break;
                                    case 'B':
                                        money_pocket12.setVisible(true);
                                        break;
                                    case 'C':
                                        money_pocket13.setVisible(true);
                                        break;
                                    case 'D':
                                        money_pocket14.setVisible(true);
                                        break;
                                    case 'E':
                                        money_pocket15.setVisible(true);
                                        break;
                                    case 'F':
                                        money_pocket16.setVisible(true);
                                        break;
                                }
                            }
                        }
                    });
                }
            }
        });
        thread3.start();
    }

    public void Selection(MouseEvent mouseEvent) {
        select = 1;
        select_normal_guard.setVisible(true);
        select_maine.setVisible(false);
        select_knight_guard.setVisible(false);
        select_mother_guard.setVisible(false);
    }

    public void Selection2(MouseEvent mouseEvent) {
        select = 2;
        select_normal_guard.setVisible(false);
        select_knight_guard.setVisible(false);
        select_mother_guard.setVisible(false);
        select_maine.setVisible(true);
    }

    public void Selection3(MouseEvent mouseEvent) {
        select = 3;
        select_normal_guard.setVisible(false);
        select_knight_guard.setVisible(true);
        select_mother_guard.setVisible(false);
        select_maine.setVisible(false);
    }

    public void Selection4(MouseEvent mouseEvent) {
        select = 4;
        select_normal_guard.setVisible(false);
        select_knight_guard.setVisible(false);
        select_mother_guard.setVisible(true);
        select_maine.setVisible(false);
    }

    public void Show1(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[0] == false && selectMaine[0] == false && selectKnightGuard[0] == false && selectMotherGuard[0] == false){
            selectSimpleGuard[0] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[0] == false && selectMaine[0] == false && selectKnightGuard[0] == false && selectMotherGuard[0] == false){
            selectMaine[0] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[0] == false && selectMaine[0] == false && selectKnightGuard[0] == false && selectMotherGuard[0] == false){
            selectKnightGuard[0] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[0] == false && selectMaine[0] == false && selectKnightGuard[0] == false && selectMotherGuard[0] == false){
            selectMotherGuard[0] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show2(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[1] == false && selectMaine[1] == false && selectKnightGuard[1] == false && selectMotherGuard[1] == false){
            selectSimpleGuard[1] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[1] == false && selectMaine[1] == false && selectKnightGuard[1] == false && selectMotherGuard[1] == false){
            selectMaine[1] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[1] == false && selectMaine[1] == false && selectKnightGuard[1] == false && selectMotherGuard[1] == false){
            selectKnightGuard[1] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[1] == false && selectMaine[1] == false && selectKnightGuard[1] == false && selectMotherGuard[1] == false){
            selectMotherGuard[1] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show3(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[2] == false && selectMaine[2] == false && selectKnightGuard[2] == false && selectMotherGuard[2] == false){
            selectSimpleGuard[2] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[2] == false && selectMaine[2] == false && selectKnightGuard[2] == false && selectMotherGuard[2] == false){
            selectMaine[2] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[2] == false && selectMaine[2] == false && selectKnightGuard[2] == false && selectMotherGuard[2] == false){
            selectKnightGuard[2] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[2] == false && selectMaine[2] == false && selectKnightGuard[2] == false && selectMotherGuard[2] == false){
            selectMotherGuard[2] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show4(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[3] == false && selectMaine[3] == false && selectKnightGuard[3] == false && selectMotherGuard[3] == false){
            selectSimpleGuard[3] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[3] == false && selectMaine[3] == false && selectKnightGuard[3] == false && selectMotherGuard[3] == false){
            selectMaine[3] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[3] == false && selectMaine[3] == false && selectKnightGuard[3] == false && selectMotherGuard[3] == false){
            selectKnightGuard[3] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[3] == false && selectMaine[3] == false && selectKnightGuard[3] == false && selectMotherGuard[3] == false){
            selectMotherGuard[3] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show5(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[4] == false && selectMaine[4] == false && selectKnightGuard[4] == false && selectMotherGuard[4] == false){
            selectSimpleGuard[4] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[4] == false && selectMaine[4] == false && selectKnightGuard[4] == false && selectMotherGuard[4] == false){
            selectMaine[4] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[4] == false && selectMaine[4] == false && selectKnightGuard[4] == false && selectMotherGuard[4] == false){
            selectKnightGuard[4] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[4] == false && selectMaine[4] == false && selectKnightGuard[4] == false && selectMotherGuard[4] == false){
            selectMotherGuard[4] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show6(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[5] == false && selectMaine[5] == false && selectKnightGuard[5] == false && selectMotherGuard[5] == false){
            selectSimpleGuard[5] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[5] == false && selectMaine[5] == false && selectKnightGuard[5] == false && selectMotherGuard[5] == false){
            selectMaine[5] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[5] == false && selectMaine[5] == false && selectKnightGuard[5] == false && selectMotherGuard[5] == false){
            selectKnightGuard[5] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[5] == false && selectMaine[5] == false && selectKnightGuard[5] == false && selectMotherGuard[5] == false){
            selectMotherGuard[5] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show7(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[6] == false && selectMaine[6] == false && selectKnightGuard[6] == false && selectMotherGuard[6] == false){
            selectSimpleGuard[6] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[6] == false && selectMaine[6] == false && selectKnightGuard[6] == false && selectMotherGuard[6] == false){
            selectMaine[6] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[6] == false && selectMaine[6] == false && selectKnightGuard[6] == false && selectMotherGuard[6] == false){
            selectKnightGuard[6] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[6] == false && selectMaine[6] == false && selectKnightGuard[6] == false && selectMotherGuard[6] == false){
            selectMotherGuard[6] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show8(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[7] == false && selectMaine[7] == false && selectKnightGuard[7] == false && selectMotherGuard[7] == false){
            selectSimpleGuard[7] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[7] == false && selectMaine[7] == false && selectKnightGuard[7] == false && selectMotherGuard[7] == false){
            selectMaine[7] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[7] == false && selectMaine[7] == false && selectKnightGuard[7] == false && selectMotherGuard[7] == false){
            selectKnightGuard[7] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[7] == false && selectMaine[7] == false && selectKnightGuard[7] == false && selectMotherGuard[7] == false){
            selectMotherGuard[7] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show9(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[8] == false && selectMaine[8] == false && selectKnightGuard[8] == false && selectMotherGuard[8] == false){
            selectSimpleGuard[8] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[8] == false && selectMaine[8] == false && selectKnightGuard[8] == false && selectMotherGuard[8] == false){
            selectMaine[8] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[8] == false && selectMaine[8] == false && selectKnightGuard[8] == false && selectMotherGuard[8] == false){
            selectKnightGuard[8] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[8] == false && selectMaine[8] == false && selectKnightGuard[8] == false && selectMotherGuard[8] == false){
            selectMotherGuard[8] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show10(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[9] == false && selectMaine[9] == false && selectKnightGuard[9] == false && selectMotherGuard[9] == false){
            selectSimpleGuard[9] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[9] == false && selectMaine[9] == false && selectKnightGuard[9] == false && selectMotherGuard[9] == false){
            selectMaine[9] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[9] == false && selectMaine[9] == false && selectKnightGuard[9] == false && selectMotherGuard[9] == false){
            selectKnightGuard[9] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[9] == false && selectMaine[9] == false && selectKnightGuard[9] == false && selectMotherGuard[9] == false){
            selectMotherGuard[9] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show11(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[10] == false && selectMaine[10] == false && selectKnightGuard[10] == false && selectMotherGuard[10] == false){
            selectSimpleGuard[10] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[10] == false && selectMaine[10] == false && selectKnightGuard[10] == false && selectMotherGuard[10] == false){
            selectMaine[10] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[10] == false && selectMaine[10] == false && selectKnightGuard[10] == false && selectMotherGuard[10] == false){
            selectKnightGuard[10] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[10] == false && selectMaine[10] == false && selectKnightGuard[10] == false && selectMotherGuard[10] == false){
            selectMotherGuard[10] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show12(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[11] == false && selectMaine[11] == false && selectKnightGuard[11] == false && selectMotherGuard[11] == false){
            selectSimpleGuard[11] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[11] == false && selectMaine[11] == false && selectKnightGuard[11] == false && selectMotherGuard[11] == false){
            selectMaine[11] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[11] == false && selectMaine[11] == false && selectKnightGuard[11] == false && selectMotherGuard[11] == false){
            selectKnightGuard[11] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[11] == false && selectMaine[11] == false && selectKnightGuard[11] == false && selectMotherGuard[11] == false){
            selectMotherGuard[11] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show13(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[12] == false && selectMaine[12] == false && selectKnightGuard[12] == false && selectMotherGuard[12] == false){
            selectSimpleGuard[12] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[12] == false && selectMaine[12] == false && selectKnightGuard[12] == false && selectMotherGuard[12] == false){
            selectMaine[12] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[12] == false && selectMaine[12] == false && selectKnightGuard[12] == false && selectMotherGuard[12] == false){
            selectKnightGuard[12] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[12] == false && selectMaine[12] == false && selectKnightGuard[12] == false && selectMotherGuard[12] == false){
            selectMotherGuard[12] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show14(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[13] == false && selectMaine[13] == false && selectKnightGuard[13] == false && selectMotherGuard[13] == false){
            selectSimpleGuard[13] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[13] == false && selectMaine[13] == false && selectKnightGuard[13] == false && selectMotherGuard[13] == false){
            selectMaine[13] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[13] == false && selectMaine[13] == false && selectKnightGuard[13] == false && selectMotherGuard[13] == false){
            selectKnightGuard[13] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[13] == false && selectMaine[13] == false && selectKnightGuard[13] == false && selectMotherGuard[13] == false){
            selectMotherGuard[13] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show15(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[14] == false && selectMaine[14] == false && selectKnightGuard[14] == false && selectMotherGuard[14] == false){
            selectSimpleGuard[14] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[14] == false && selectMaine[14] == false && selectKnightGuard[14] == false && selectMotherGuard[14] == false){
            selectMaine[14] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[14] == false && selectMaine[14] == false && selectKnightGuard[14] == false && selectMotherGuard[14] == false){
            selectKnightGuard[14] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[14] == false && selectMaine[14] == false && selectKnightGuard[14] == false && selectMotherGuard[14] == false){
            selectMotherGuard[14] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void Show16(MouseEvent mouseEvent) {
        if (select == 1 && progress_bar_normal_guard.getProgress() >= 1 && money >= 100 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectSimpleGuard[15] = true;
            money -= 100;
            money_text.setText(String.valueOf(money));
            progress_bar_normal_guard.setProgress(0);
        }
        if (select == 2 && progress_bar_Maine.getProgress() >= 1 && money >= 120 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectMaine[15] = true;
            money -= 120;
            money_text.setText(String.valueOf(money));
            progress_bar_Maine.setProgress(0);
        }
        if (select == 3 && progress_bar_knight_guard.getProgress() >= 1 && money >= 170 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectKnightGuard[15] = true;
            money -= 170;
            money_text.setText(String.valueOf(money));
            progress_bar_knight_guard.setProgress(0);
        }
        if (select == 4 && progress_bar_mother_guard.getProgress() >= 1 && money >= 60 && selectSimpleGuard[15] == false && selectMaine[15] == false && selectKnightGuard[15] == false && selectMotherGuard[15] == false){
            selectMotherGuard[15] = true;
            money -= 60;
            money_text.setText(String.valueOf(money));
            progress_bar_mother_guard.setProgress(0);
        }
    }

    public void OnClickMoneyPocket1(MouseEvent mouseEvent) {
        money_pocket1.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket2(MouseEvent mouseEvent) {
        money_pocket2.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket3(MouseEvent mouseEvent) {
        money_pocket3.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket4(MouseEvent mouseEvent) {
        money_pocket4.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket5(MouseEvent mouseEvent) {
        money_pocket5.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket6(MouseEvent mouseEvent) {
        money_pocket6.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket7(MouseEvent mouseEvent) {
        money_pocket7.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket8(MouseEvent mouseEvent) {
        money_pocket8.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket9(MouseEvent mouseEvent) {
        money_pocket9.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket10(MouseEvent mouseEvent) {
        money_pocket10.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket11(MouseEvent mouseEvent) {
        money_pocket11.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket12(MouseEvent mouseEvent) {
        money_pocket12.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket13(MouseEvent mouseEvent) {
        money_pocket13.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket14(MouseEvent mouseEvent) {
        money_pocket14.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket15(MouseEvent mouseEvent) {
        money_pocket15.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickMoneyPocket16(MouseEvent mouseEvent) {
        money_pocket16.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public static char RandMoneyPocket () {
        String num = "0123456789ABCDEF";
        Random rand = new Random();
        char n;
        n = num.charAt(rand.nextInt(num.length()));
        return n;
    }

    public static int RandHunter () {
        String num = "12345";
        Random rand = new Random();
        char n;
        n = num.charAt(rand.nextInt(num.length()));
        if (n == '1')
            return 50;

        else if (n == '2')
            return 100;

        else if (n == '3')
            return 150;

        else if (n == '4')
            return 200;

        else
            return 250;
    }

    public static int RandHunterY () {
        String num = "1234";
        Random rand = new Random();
        char n;
        n = num.charAt(rand.nextInt(num.length()));
        if (n == '1')
            return 215;

        else if (n == '2')
            return 377;

        else if (n == '3')
            return 539;

        else
            return 701;
    }

    public void OnClickPause(ActionEvent actionEvent) {
        AnchorPane[] anchor_pane = {anchor_pane1 , anchor_pane2 , anchor_pane3 , anchor_pane4 , anchor_pane5 , anchor_pane6 , anchor_pane7 , anchor_pane8
                , anchor_pane9 , anchor_pane10 , anchor_pane11 , anchor_pane12 , anchor_pane13 , anchor_pane14 , anchor_pane15 , anchor_pane16};
        stop = 1;
        normal_guard.setDisable(true);
        maine.setDisable(true);
        knight_guard.setDisable(true);
        mother_guard.setDisable(true);
        for (stopAnchorPaneNum = 0 ; stopAnchorPaneNum < 16 ; stopAnchorPaneNum++){
            anchor_pane[stopAnchorPaneNum].setDisable(true);
        }
        money_pocket1.setDisable(true);
        money_pocket2.setDisable(true);
        money_pocket3.setDisable(true);
        money_pocket4.setDisable(true);
        money_pocket5.setDisable(true);
        money_pocket6.setDisable(true);
        money_pocket7.setDisable(true);
        money_pocket8.setDisable(true);
        money_pocket9.setDisable(true);
        money_pocket10.setDisable(true);
        money_pocket11.setDisable(true);
        money_pocket12.setDisable(true);
        money_pocket13.setDisable(true);
        money_pocket14.setDisable(true);
        money_pocket15.setDisable(true);
        money_pocket16.setDisable(true);
    }

    public void OnClickStart(ActionEvent actionEvent) {
        AnchorPane[] anchor_pane = {anchor_pane1 , anchor_pane2 , anchor_pane3 , anchor_pane4 , anchor_pane5 , anchor_pane6 , anchor_pane7 , anchor_pane8
                , anchor_pane9 , anchor_pane10 , anchor_pane11 , anchor_pane12 , anchor_pane13 , anchor_pane14 , anchor_pane15 , anchor_pane16};
        stop = 0;
        normal_guard.setDisable(false);
        maine.setDisable(false);
        knight_guard.setDisable(false);
        mother_guard.setDisable(false);
        for (stopAnchorPaneNum = 0 ; stopAnchorPaneNum < 16 ; stopAnchorPaneNum++){
            anchor_pane[stopAnchorPaneNum].setDisable(false);
        }
        money_pocket1.setDisable(false);
        money_pocket2.setDisable(false);
        money_pocket3.setDisable(false);
        money_pocket4.setDisable(false);
        money_pocket5.setDisable(false);
        money_pocket6.setDisable(false);
        money_pocket7.setDisable(false);
        money_pocket8.setDisable(false);
        money_pocket9.setDisable(false);
        money_pocket10.setDisable(false);
        money_pocket11.setDisable(false);
        money_pocket12.setDisable(false);
        money_pocket13.setDisable(false);
        money_pocket14.setDisable(false);
        money_pocket15.setDisable(false);
        money_pocket16.setDisable(false);
    }

    public void darkMode(){
        darkMode = true;
        background.setStyle("-fx-background-color: #464445");
        box.setStroke(Paint.valueOf("#ffffff"));
        line.setStroke(Paint.valueOf("#ffffff"));
        money_text.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 10 ; -fx-border-radius : 10");
        start.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 30 ; -fx-border-radius : 30");
        pause.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 30 ; -fx-border-radius : 30");
        Score.setStyle("-fx-background-color : #464445 ; -fx-text-fill: #ffffff");
        score_text.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 10 ; -fx-border-radius : 10");
    }

    public void OnClickMoneyPocketGuard1(MouseEvent mouseEvent) {
        money_pocket_guard1.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard2(MouseEvent mouseEvent) {
        money_pocket_guard2.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard3(MouseEvent mouseEvent) {
        money_pocket_guard3.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard4(MouseEvent mouseEvent) {
        money_pocket_guard4.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard5(MouseEvent mouseEvent) {
        money_pocket_guard5.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard6(MouseEvent mouseEvent) {
        money_pocket_guard6.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard7(MouseEvent mouseEvent) {
        money_pocket_guard7.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard8(MouseEvent mouseEvent) {
        money_pocket_guard8.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard9(MouseEvent mouseEvent) {
        money_pocket_guard9.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard10(MouseEvent mouseEvent) {
        money_pocket_guard10.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard11(MouseEvent mouseEvent) {
        money_pocket_guard11.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard12(MouseEvent mouseEvent) {
        money_pocket_guard12.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard13(MouseEvent mouseEvent) {
        money_pocket_guard13.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard14(MouseEvent mouseEvent) {
        money_pocket_guard14.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard15(MouseEvent mouseEvent) {
        money_pocket_guard15.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }
    public void OnClickMoneyPocketGuard16(MouseEvent mouseEvent) {
        money_pocket_guard16.setVisible(false);
        money +=20;
        money_text.setText(String.valueOf(money));
    }

    public void OnClickEnteredStart(MouseEvent mouseEvent) {
        start.setStyle("-fx-background-radius : 30 ; -fx-background-color : #E8B1F7 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickExitedStart(MouseEvent mouseEvent) {
        start.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #F2D7F9 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickPressedStart(MouseEvent mouseEvent) {
        start.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #DD84F4 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickEnteredPause(MouseEvent mouseEvent) {
        pause.setStyle("-fx-background-radius : 30 ; -fx-background-color : #E8B1F7 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickExitedPause(MouseEvent mouseEvent) {
        pause.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #F2D7F9 ; -fx-border-color : black ; -fx-border-radius : 30");
    }

    public void OnClickPressedPause(MouseEvent mouseEvent) {
        pause.setStyle("-fx-background-radius : 30 ; -fx-background-color :  #DD84F4 ; -fx-border-color : black ; -fx-border-radius : 30");
    }
}

