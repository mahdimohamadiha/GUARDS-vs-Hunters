package sample;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

public class EndGameController{
    public Label score_text;
    public Button exit;
    public Label end_game;
    public Label Score;
    public AnchorPane background;

    public void setScore(int score){
        score_text.setText(String.valueOf(score));
    }

    public void OnClickExit(ActionEvent actionEvent) {
        Stage stage = (Stage) exit.getScene().getWindow();
        stage.close();
    }

    public void darkMode(){
        background.setStyle("-fx-background-color: #464445");
        Score.setStyle("-fx-background-color : #464445 ; -fx-text-fill: #ffffff");
        score_text.setStyle("-fx-background-color : #464445 ; -fx-text-fill: #ffffff");
        exit.setStyle("-fx-background-color : #F2D7F9 ; -fx-border-color : dark ; -fx-text-fill: dark ; -fx-background-radius : 20 ; -fx-border-radius : 20");
    }

    public void OnClickEnteredExit(MouseEvent mouseEvent) {
        exit.setStyle("-fx-background-radius : 20 ; -fx-background-color : #E8B1F7 ; -fx-border-color : black ; -fx-border-radius : 20");
    }

    public void OnClickExitedExit(MouseEvent mouseEvent) {
        exit.setStyle("-fx-background-radius : 20 ; -fx-background-color :  #F2D7F9 ; -fx-border-color : black ; -fx-border-radius : 20");
    }

    public void OnClickPressedExit(MouseEvent mouseEvent) {
        exit.setStyle("-fx-background-radius : 20 ; -fx-background-color :  #DD84F4 ; -fx-border-color : black ; -fx-border-radius : 20");
    }
}
